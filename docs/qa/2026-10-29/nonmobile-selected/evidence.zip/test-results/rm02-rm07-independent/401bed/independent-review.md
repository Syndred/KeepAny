# 401bed 布局补缺独立复核

候选源码 401bed775901b8403fc9828beea3601bfcfbdb9f；ZIP KeepAny-0.1.0-preview.401bed775901-portable.zip；SHA256 e540101ab1a659b637cdf54dd3a2cd62c5d5da05a9ff639d07043562b5bcbba2；sourceDirty=false。核对实际ZIP、内置RELEASE和web文件哈希后，经包内服务启动，未使用源码服务器。

## 本候选实际执行

- 4427，原PDF removal两语言 + project simplification两语言共4例，首轮全部通过，0失败、0重试，1.6m。新增真实expense夹具的顺序/空胶囊/无溢出断言通过，原取消不变、保存刷新、KA1旧字段/原图摘要/关系/旧vault/submission及expense保留断言仍通过。
- 4428，同一ZIP，复用已有忽略目录截图脚本，真实UI恢复带expense且category为空的合成KA1，编辑取消、编辑保存并刷新。实际逐张打开20张稳定截图：zh-CN/en × 390/768/1280/1920/2560 × 取消后/保存刷新后。
- 各图均见hero及基本资料在前，费用账本在末尾且占满内容宽度；空分类不再出现空胶囊；基本资料取消/保存后的值、普通原图及原expense可见。窄屏正常换行，没有遮挡或横向裁切。
- 白盒核对两处产品变化：project专属finance选择器明确grid-column:1 / -1和order:11；category span有非空渲染条件。未扩展其他产品代码审查。

## 修前失败与版本边界

已实际打开并核对主控真实失败图及修前带expense回归图，二者原位保留，SHA256列于本目录independent-review.json：

- test-results/nonmobile-integration-20261029/owner/restored-project-final.png
- test-results/nonmobile-integration-20261029/owner-project-layout-before/project-simplification-en--41c73-reserves-legacy-backup-data/project-expense-layout.png

原d9项目视觉夹具没有expense，因此原结论不覆盖带账单的布局组合；主控后来实际发现该组合失败。本轮已以真实expense夹具独立重放并逐图确认修复。旧d9报告/图不改写为401bed成功。

401bed的PDF功能已重新执行通过。后续RM02补验已在同一401bed ZIP重新生成并实际打开中英五宽稳定PDF图，最终RM02视觉已绑定本候选，不再依赖d9。补验详情见下节；旧d9证据原样保留。

Node合成KA1只是准备，解密下载KA1只是辅助回读，不伪称用户操作。Line reporter没有持久化body-only附件，只记录实际断言通过，不声称已落盘原始下载证据。详细机读事实见independent-review.json，截图候选摘要见visual/visual-receipt.json。

本独立范围判定：功能通过；两处变化白盒通过；带费用/空分类项目中英五宽取消后和保存刷新后的视觉复核通过。全局验收和主控本人正常入口体验仍单独记录。本轮未改产品/测试、未构建/提交/部署，4427/4428服务已结束；不触用户4180及主控环境。

## RM02 最终候选视觉补验

按主控追加的最终版本合同要求，先实际逐张打开401bed原功能运行产出的10张PDF截图：中英768/1280/1920/2560正文、错误提示及禁用态正常；两张390图仍捕获侧栏收起过渡中帧，不能用于无遮挡通过，原图完整保留。

复用现成忽略目录capture脚本，仅设置合成AI模型和选择被拒绝的PDF，通过KEEPANY_SKIP_PROJECT_CAPTURE=1跳过整个项目恢复/编辑/截图段，不重跑功能，也不重拍已通过的20张项目图。4428实际运行401bed同一精确ZIP，输出到pdf-visual/，等侧栏真实right≤0或桌面布局稳定再截图。

已实际逐张打开pdf-visual/pdf-error-settled-{zh-CN,en}-{390,768,1280,1920,2560}.png全部10张：PDF拒绝文案完整可读，生成与确认导入的禁用态可辨，390侧栏完全收起，所有尺寸没有遮挡、重叠或横向裁切。收据pdf-visual/visual-receipt.json的源码为401bed775901b8403fc9828beea3601bfcfbdb9f，sourceDirty=false，ZIP SHA256为e540101ab1a659b637cdf54dd3a2cd62c5d5da05a9ff639d07043562b5bcbba2。

RM02最终像素判定：通过，明确绑定401bed。本轮功能运行仍是此前原4例一次，不增加或冒报新功能通过数量。脚本历史控制台标签含project字样，但项目段被显式跳过，十张输出均为PDF图。项目20图及其收据未覆盖。补验后4428已停止，未改产品或测试。
