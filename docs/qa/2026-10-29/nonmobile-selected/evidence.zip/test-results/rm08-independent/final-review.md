# RM08 独立复核：受委派关键保留范围通过

复核者 `/root/completion_regressions`。本记录独立复核 B8/B9/B10 产品删减，以及主控的 views/search/MCP/sample 边界；不将本人实现的 PDF 移除作为独立通过范围，也不替代主控本人体验。

候选：`d9eace67b06614f23a0c8d1b505064051d807be7`。显式 ZIP `dist/preview/KeepAny-0.1.0-preview.d9eace67b066-portable.zip`，实际 SHA256 `43b19bf482213871bd0894cb1fb2709d2a58637097eb2fb63c299b7fa7e84b3d`。本轮通过结果均消费该 ZIP，HTTP index.html 另与该包 manifest SHA 核对一致。

## 分项判定

|维度|受委派范围与事实|判定|
|---|---|---|
|源码|实际基线 diff、活动调用边界、MCP 三层 vault 排除、旧路由只读/账号映射、无远端连接依赖；local-db/password-vault/contracts 对基线无差异；来源夹具符合 validateDatasetBinding；混合测试保留核心断言|通过，范围见 source-review.json|
|运行|原四份 spec 共12例：账号/KDBX 4、统一UI 4、集合恢复 2、旧来源本地恢复 2；178.738935秒，12 passed / 0 skipped / 0 flaky，exit0；无增加重试或预算|通过|
|独立公开UI补观测|zh-CN/en × 390/1280：旧 settings#connections + 合成旧连接偏好重入/刷新；旧 vault 列表深链；真实新建KDBX及样例登录；账号展开；项目列表/卡片切换；图库；真实改分类名称并刷新回读。另按两套语言库逐一resize，补768/1920/2560账号展开/收起|通过|
|网络/副作用|四组补观测的跨源请求、Vite源码请求、pageerror均为空；旧偏好仅明确标记的准备，其余资产/KDBX/分类操作从真实UI完成|通过|
|视觉|实际打开四组账号展开、设置旧深链、图库、分类改名刷新、项目稳定卡片截图；另看最终错密码→成功提示中英390/1280图，以及中英768/1920/2560的12张展开/收起稳定截图。展开仅自身变高，另7卡高度原值不变；无横向溢出/外部引用/远端操作入口|通过上述截图状态|

账号展开高度原始值位于 `runtime/final/supplemental-after-preparation-fix/observation.json`：相邻七卡逐一完全保持原高度；当前展开卡由154变630–762，或由154变690/785.8125。正常项目卡片仍按普通卡片布局等高，未受到账号展开影响。

追加 `runtime/final/account-resize/observation.json`：768×1024、1920×1080、2560×1440各中英一组，共6组。所选账号均由154展开至762.015625或785.8125，其他七卡高度保持原值；收起后八卡逐项恢复原高度。12张图已实际打开检查，768下字段/操作可滚动触达，宽屏邻卡不随展开拉高。该JSON SHA256为`0314192ee74a5ac137d0b1f8fae4994e7d60cc04fc2fe59e81ef1edab42f449a`。

运行报告 `runtime/final/report-tests.json`；自动化产物 `runtime/final/artifacts/`。稳定视觉采用 `runtime/final/supplemental-after-preparation-fix/` 以及 `runtime/final/project-cards-stable/`。账号/KDBX用例保留了正常保存、解绑/删除/改密弹窗取消、错密码、成功解锁、锁定、KDBX导出及干净导入、刷新；恢复用例保留跨来源拒绝无改动、超预算拒绝、同来源恢复及重复恢复、精确下载回读。

## 首轮事实与准备问题均保留

- 旧 dba0c6a93036 首轮 `runtime/report-first.json`：10 passed / 2 failed，105.656091秒。两失败是恢复fixture确认后未等真实成功反馈就导航下载；失败下载均为0条/无来源，合法fixture为1条/有来源。`runtime/download-inspection-first.json` 保留解密对照。原断言未删除，实施者补成功反馈等待后在新候选两例均过。
- 旧候选成功解锁后仍显示上一错误“保持锁定”toast的截图保留；主控修复成功通知替换旧错误，新候选原错密码断言与新增成功后无旧错误断言均过，实际截图也相符。
- 新候选首次4428已有另一会话服务，启动严格拒绝复用，0测试准备失败保存在 `runtime/final/report.json`；按主控指示改4432执行，不杀未知进程。
- 自写补观测首轮漏了“补示例登录完成”等待，5秒时仍在逐条创建，4/8，不当作产品失败。首轮 `runtime/final/supplemental/` 保留；补既有正式合同相同的按钮消失完成步骤（原30秒操作预算），然后保留原确切8条断言，四组均过。
- 第一次项目卡片截图处于150ms按钮背景过渡中；语义和布局断言已过，但最终视觉另等真实动画结束并移开鼠标，稳定截图位于 project-cards-stable，未覆盖早图。

## 边界与收尾

本次独立通过只覆盖上述 RM08 关键保留范围。账号展开/收起包含中英390/768/1280/1920/2560；旧深链、图库、普通项目列表/卡片和分类回读为中英390/1280。完整项目功能、原生手机、全部hover/focus状态、PDF/B1/B2完整验收以及主控本人体验不由此记录代替；旧P3等历史未闭环项不得据此改写为已完成。最终全合同判定由主控整合各范围证据。

主控后续明确的旧P3为“项目category为空时hero显示空胶囊”（A在RM02/RM07报告），另发现有账单项目的费用卡order0排在hero前。它们属于项目详情范围，不由本RM08关键保留复核消除；主控已安排原实现者修复。上述d9eace67结果保留原候选标签，新产品包完成后须另记同合同复测，不把本报告改写成新SHA成功。

所有独立浏览器上下文已关闭；本人显式启动的4432候选服务均通过该包stop命令正常停止，wrapper exit0；4428由所属A会话处理。未操作4180或用户真实资料，未stage/commit/push。
