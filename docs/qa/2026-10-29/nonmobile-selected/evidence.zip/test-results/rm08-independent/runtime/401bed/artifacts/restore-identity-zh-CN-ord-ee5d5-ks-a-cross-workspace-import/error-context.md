# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: restore-identity.spec.ts >> zh-CN ordinary restore preserves source identity and blocks a cross-workspace import
- Location: tests\e2e\restore-identity.spec.ts:61:42

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('link', { name: '保存备份文件' })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('link', { name: '保存备份文件' }) with timeout 5000ms
  - waiting for getByRole('link', { name: '保存备份文件' })

```

```yaml
- complementary:
  - strong: KeepAny
  - text: 个人资产工作台
  - button "关闭"
  - button "个人工作区":
    - strong: 个人工作区
  - text: 工作空间
  - navigation "导航":
    - button "概览 按住拖动排序"
    - link "概览":
      - /url: /
    - button "待办 按住拖动排序"
    - link "待办":
      - /url: /tasks
    - button "资产 按住拖动排序"
    - link "资产":
      - /url: /assets
    - button "账号 按住拖动排序"
    - link "账号":
      - /url: /accounts
    - status
  - link "回收站":
    - /url: /trash
  - text: 我的分类
  - link "自定义侧边栏":
    - /url: /collections
  - button "我 我的工作区 仅自己可见":
    - text: 我
    - strong: 我的工作区
    - text: 仅自己可见
- banner:
  - button "导航"
  - link "返回概览":
    - /url: /
  - button "搜索全部资料"
  - link "待办提醒":
    - /url: /tasks
  - button "AI 助手与授权"
  - link "收录与备份":
    - /url: /intake
- main:
  - text: 收录与备份
  - heading "随手收录，慢慢整理。" [level=1]
  - paragraph: 从链接、图片或表格开始，也可以只记一个名字。
  - heading "AI 整理导入" [level=2]
  - paragraph: 本次文字或文件会发给所选模型。请先检查内容；结果需逐项核对后入库。
  - paragraph:
    - text: 尚未配置 AI 模型，请先选择模型服务。
    - link "配置模型":
      - /url: /settings#assistant
  - text: 文字或表格内容
  - textbox "文字或表格内容"
  - text: CSV、文字或图片
  - button "选择文件"
  - text: 未选择文件
  - button "生成待审核资料" [disabled]
  - heading "快速收录" [level=2]
  - group "收录方式":
    - text: 收录方式
    - button "网址" [disabled] [pressed]
    - button "图片 / 收据" [disabled]
    - button "表格" [disabled]
    - button "手动" [disabled]
  - text: 网址
  - textbox "网址" [disabled]:
    - /placeholder: https://your-project.com
  - button "预览资料" [disabled]
  - heading "资料与备份" [level=2]
  - paragraph: 备份包含资料、关系、原图、历史、收录审核记录与加密密码库。
  - text: 资产资料 关系图 原图与附件 收录审核记录 备份密码（至少 12 位）
  - textbox "备份密码（至少 12 位）" [disabled]: synthetic-restore-identity-password
  - text: 请妥善保存密码，无法代为找回。
  - button "创建备份" [disabled]
  - status: 本次打开后尚未生成备份文件。
  - group: 恢复备份
  - heading "最近收录" [level=2]
  - list:
    - listitem:
      - link "Synthetic target item":
        - /url: /assets/item/1de61605-8776-49fb-904c-84e3414e71de
      - text: 实物
  - heading "导入审核" [level=2]
  - paragraph: 导入后逐条核对资料，再决定确认或忽略。
```

# Test source

```ts
  1   | import { readFileSync } from 'node:fs';
  2   | import { createHash } from 'node:crypto';
  3   | import { resolve } from 'node:path';
  4   | import { newAsset, type Asset } from '../../packages/domain/src';
  5   | import { prepareCompletionArchive, recordDevelopmentRequests } from './helpers/completion-archive';
  6   | import { openBackupRestorePanel } from './helpers/backup-restore';
  7   | import { open } from 'node:fs/promises';
  8   | import { expect, test, type BrowserContext, type Page } from '@playwright/test';
  9   | import { strFromU8, unzipSync } from 'fflate';
  10  | import { BACKUP_CONTAINER_MAX_BYTES, decryptBackup } from '../../packages/local-db/src/backup-crypto';
  11  | import type { DatasetBinding, RecordRow } from '../../packages/local-db/src';
  12  | 
  13  | const password = 'synthetic-restore-identity-password';
  14  | test.use({ actionTimeout: 15_000 });
  15  | 
  16  | // Synthetic legacy provenance is prepared only in Node. Both candidate stores
  17  | // become bound solely through their real KA1 restore UI; no browser DB writes.
  18  | type LegacyFixture = { asset: Asset; binding: DatasetBinding };
  19  | const sourceDirectory = resolve("test-results/restore-identity-legacy-source");
  20  | const targetDirectory = resolve("test-results/restore-identity-legacy-target");
  21  | let sourceFixture: LegacyFixture;
  22  | let targetFixture: LegacyFixture;
  23  | test.beforeAll(async () => {
  24  |   async function prepare(directory: string, kind: "project" | "item", name: string, endpoint: string) {
  25  |     return prepareCompletionArchive(directory, password, async repository => {
  26  |       const asset = { ...newAsset(kind), name };
  27  |       await repository.saveBatch([{ type: "asset", value: asset }]);
  28  |       const accountId = "legacy-synthetic-owner", workspaceId = crypto.randomUUID();
  29  |       const digest = createHash("sha256").update(JSON.stringify([endpoint, accountId])).digest("hex");
  30  |       const binding: DatasetBinding = { endpoint, accountId, workspaceId, scope: digest + ":" + workspaceId };
  31  |       await repository.claimDatasetBinding(binding);
  32  |       return { asset, binding };
  33  |     });
  34  |   }
  35  |   sourceFixture = await prepare(sourceDirectory, "project", "Synthetic source project", "https://source-legacy.example.test");
  36  |   targetFixture = await prepare(targetDirectory, "item", "Synthetic target item", "https://target-legacy.example.test");
  37  | });
  38  | 
  39  | async function download(page: Page, zh: boolean, filename: string) {
  40  |   await page.goto('/intake'); await page.locator('#backup-password').fill(password);
  41  |   await page.getByRole('button', { name: zh ? '创建备份' : 'Create backup', exact: true }).click();
  42  |   const link = page.getByRole('link', { name: zh ? '保存备份文件' : 'Save backup file' });
> 43  |   await expect(link).toBeVisible();
      |                      ^ Error: expect(locator).toBeVisible() failed
  44  |   const downloading = page.waitForEvent('download'); await link.click();
  45  |   const path = test.info().outputPath(filename); await (await downloading).saveAs(path);
  46  |   const entries = unzipSync(await decryptBackup(new Uint8Array(readFileSync(path)), password));
  47  |   return { path, rows: JSON.parse(strFromU8(entries['records.json'])) as RecordRow[],
  48  |     manifest: JSON.parse(strFromU8(entries['manifest.json'])) as { sourceBinding?: DatasetBinding } };
  49  | }
  50  | 
  51  | async function restore(page: Page, file: string, zh: boolean, expectSuccess = true) {
  52  |   await page.goto('/intake'); await page.locator('#backup-password').fill(password);
  53  |   await openBackupRestorePanel(page);
  54  |   await page.locator('#restore-file').setInputFiles(file);
  55  |   await page.getByRole('button', { name: zh ? '预览' : 'Preview', exact: true }).first().click();
  56  |   const confirm = page.getByRole('button', { name: zh ? '确认 · 1' : 'Confirm · 1', exact: true });
  57  |   await expect(confirm).toBeVisible(); await confirm.click();
  58  |   if (expectSuccess) await expect(page.getByRole('status').filter({ hasText: zh ? '已恢复 1 条记录' : 'Restored 1 records' })).toBeVisible();
  59  | }
  60  | 
  61  | for (const locale of ['zh-CN', 'en-US']) test(`${locale} ordinary restore preserves source identity and blocks a cross-workspace import`, async ({ browser }) => {
  62  |   test.setTimeout(90_000);
  63  |   const zh = locale === 'zh-CN';
  64  |   const contexts: BrowserContext[] = [];
  65  |   const errors: string[] = [];
  66  |   const developmentRequests: string[][] = [];
  67  |   async function isolated() {
  68  |     const context = await browser.newContext({ locale, viewport: { width: 390, height: 844 }, acceptDownloads: true });
  69  |     contexts.push(context);
  70  |     developmentRequests.push(recordDevelopmentRequests(context));
  71  |     const page = await context.newPage(); page.on('pageerror', error => errors.push(error.message));
  72  |     return { context, page };
  73  |   }
  74  |   try {
  75  |     const source = await isolated(), target = await isolated(), clean = await isolated();
  76  |     const sourceWorkspace = sourceFixture.binding.workspaceId, targetWorkspace = targetFixture.binding.workspaceId;
  77  |     await restore(source.page, resolve(sourceDirectory, 'fixture.ka1'), zh);
  78  |     const sourceBackup = await download(source.page, zh, 'source.ka1');
  79  |     expect(sourceBackup.manifest.sourceBinding?.workspaceId).toBe(sourceWorkspace);
  80  |     await restore(target.page, resolve(targetDirectory, 'fixture.ka1'), zh);
  81  |     const before = await download(target.page, zh, 'target-before.ka1');
  82  |     expect(before.manifest.sourceBinding?.workspaceId).toBe(targetWorkspace);
  83  |     await restore(target.page, sourceBackup.path, zh, false);
  84  |     const refusal = target.page.getByRole('status').filter({ hasText: zh
  85  |       ? '备份来源与当前同步身份不一致，或没有来源标识，未恢复资料。'
  86  |       : 'The backup has a different or unknown sync identity. No records were restored.' });
  87  |     await expect(refusal).toBeVisible();
  88  |     expect(await target.page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  89  |     await target.page.screenshot({ path: test.info().outputPath(`restore-refused-${locale}.png`), fullPage: true });
  90  |     const after = await download(target.page, zh, 'target-after.ka1');
  91  |     expect(after.rows).toEqual(before.rows); expect(after.manifest.sourceBinding).toEqual(before.manifest.sourceBinding);
  92  |     await target.page.reload();
  93  |     const reloaded = await download(target.page, zh, 'target-reloaded.ka1');
  94  |     expect(reloaded.rows).toEqual(before.rows);
  95  |     const oversized = test.info().outputPath('synthetic-oversized.ka1');
  96  |     const sparse = await open(oversized, 'w');
  97  |     try { await sparse.truncate(BACKUP_CONTAINER_MAX_BYTES + 1); } finally { await sparse.close(); }
  98  |     await clean.page.goto('/intake'); await clean.page.locator('#backup-password').fill(password);
  99  |     await openBackupRestorePanel(clean.page);
  100 |     await clean.page.locator('#restore-file').setInputFiles(oversized);
  101 |     await clean.page.getByRole('button', { name: zh ? '预览' : 'Preview', exact: true }).first().click();
  102 |     await expect(clean.page.getByRole('status').filter({ hasText: zh ? '备份超过恢复大小上限' : 'This backup exceeds the restore limit' })).toBeVisible();
  103 |     await expect(clean.page.getByRole('button', { name: /^(确认|Confirm) ·/ })).toHaveCount(0);
  104 |     await restore(clean.page, sourceBackup.path, zh);
  105 |     await expect(clean.page.getByRole('status').filter({ hasText: zh ? '已恢复 1 条记录' : 'Restored 1 records' })).toBeVisible();
  106 |     await clean.page.reload();
  107 |     const restored = await download(clean.page, zh, 'restored.ka1');
  108 |     expect(restored.rows).toEqual(sourceBackup.rows);
  109 |     expect(restored.manifest.sourceBinding).toEqual(sourceBackup.manifest.sourceBinding);
  110 |     await restore(clean.page, sourceBackup.path, zh);
  111 |     await expect(clean.page.getByRole('status').filter({ hasText: zh ? '已恢复 1 条记录' : 'Restored 1 records' })).toBeVisible();
  112 |     expect(await clean.page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  113 |     await clean.page.screenshot({ path: test.info().outputPath(`restore-same-source-${locale}.png`), fullPage: true });
  114 |     expect(errors).toEqual([]);
  115 |     expect(developmentRequests.flat()).toEqual([]);
  116 |   } finally { for (const context of contexts) await context.close(); }
  117 | });
  118 | 
```