# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: project-simplification.spec.ts >> en 1280: removed project UI preserves legacy backup data
- Location: tests\e2e\project-simplification.spec.ts:42:72

# Error details

```
Error: Project title and hero precede its ordinary expense ledger

expect(received).toBeLessThanOrEqual(expected)

Expected: <= 81
Received:    421.984375
```

```
Error: An empty category must not render an empty capsule

expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 1
```

# Page snapshot

```yaml
- generic [ref=f6e3]:
  - complementary [ref=f6e4]:
    - generic [ref=f6e5]:
      - generic [aria-hidden] [ref=f6e6]: K
      - generic [ref=f6e7]:
        - strong [ref=f6e8]: KeepAny
        - generic [ref=f6e9]: Personal asset workspace
    - button [ref=f6e10] [cursor=pointer]:
      - strong [ref=f6e15]: Personal workspace
    - generic [ref=f6e18]: Workspace
    - navigation "Navigation" [ref=f6e19]:
      - generic [ref=f6e20]:
        - button "Overview Drag to reorder" [ref=f6e21]
        - link "Overview" [ref=f6e29] [cursor=pointer]:
          - /url: /
      - generic [ref=f6e36]:
        - button "Tasks Drag to reorder" [ref=f6e37]
        - link "Tasks" [ref=f6e45] [cursor=pointer]:
          - /url: /tasks
      - generic [ref=f6e50]:
        - button "Assets Drag to reorder" [ref=f6e51]
        - link "Assets" [ref=f6e59] [cursor=pointer]:
          - /url: /assets
      - generic [ref=f6e65]:
        - button "Accounts Drag to reorder" [ref=f6e66]
        - link "Accounts" [ref=f6e74] [cursor=pointer]:
          - /url: /accounts
      - status [ref=f6e79]
    - link "Trash" [ref=f6e80] [cursor=pointer]:
      - /url: /trash
    - generic [ref=f6e84]:
      - generic [ref=f6e85]: Collections
      - link "Customize sidebar" [ref=f6e86] [cursor=pointer]:
        - /url: /collections
    - button "Me My workspace Only visible here" [ref=f6e89] [cursor=pointer]:
      - generic [ref=f6e90]: Me
      - generic [ref=f6e91]:
        - strong [ref=f6e92]: My workspace
        - generic [ref=f6e93]: Only visible here
  - generic [ref=f6e96]:
    - banner [ref=f6e97]:
      - link "Back to overview" [ref=f6e98] [cursor=pointer]:
        - /url: /
      - button "Search all records" [ref=f6e101] [cursor=pointer]:
        - generic [ref=f6e106]: ⌘ K
      - generic [ref=f6e107]:
        - link "Task reminders" [ref=f6e108] [cursor=pointer]:
          - /url: /tasks
        - button "AI assistant and access" [ref=f6e112] [cursor=pointer]
        - link "Import & backup" [ref=f6e116] [cursor=pointer]:
          - /url: /intake
    - main [ref=f6e118]:
      - generic [ref=f6e120]:
        - generic [ref=f6e121]: Import & backup
        - heading "Collect now, organize later." [level=1] [ref=f6e122]
        - paragraph [ref=f6e123]: Start with a link, photo or spreadsheet, or just a name.
      - generic [ref=f6e124]:
        - heading "Organize with AI" [level=2] [ref=f6e125]
        - paragraph [ref=f6e126]: This text or file goes to the selected model. Check its contents first; review each result before saving.
        - paragraph [ref=f6e127]:
          - text: No AI model is configured. Choose a model service first.
          - link "Configure model" [ref=f6e128] [cursor=pointer]:
            - /url: /settings#assistant
        - generic [ref=f6e129]:
          - generic [ref=f6e130]: Text or spreadsheet content
          - textbox "Text or spreadsheet content" [ref=f6e131]
        - generic [ref=f6e132]:
          - generic [ref=f6e133]: CSV, text or image
          - generic [ref=f6e134]:
            - button "Choose file" [ref=f6e135] [cursor=pointer]
            - generic [ref=f6e136]: No file selected
        - button "Generate records to review" [disabled] [ref=f6e138]
      - generic [ref=f6e139]:
        - generic [ref=f6e140]:
          - generic [ref=f6e141]:
            - heading "Quick capture" [level=2] [ref=f6e143]
            - group "Capture method" [ref=f6e144]:
              - button "Website" [pressed] [ref=f6e146] [cursor=pointer]
              - button "Photo or receipt" [ref=f6e147] [cursor=pointer]
              - button "Spreadsheet" [ref=f6e148] [cursor=pointer]
              - button "Manual" [ref=f6e149] [cursor=pointer]
            - generic [ref=f6e150]:
              - generic [ref=f6e151]: URL
              - textbox "URL" [ref=f6e152]:
                - /placeholder: https://your-project.com
            - button "Preview records" [disabled] [ref=f6e153]
          - generic [ref=f6e157]:
            - generic [ref=f6e158]:
              - heading "Records & backup" [level=2] [ref=f6e159]
              - paragraph [ref=f6e160]: Includes records, connections, original images, history, intake reviews and the encrypted password vault.
            - generic [ref=f6e161]:
              - generic [ref=f6e162]: Records
              - generic [ref=f6e163]: Connections
              - generic [ref=f6e164]: Original images & files
              - generic [ref=f6e165]: Intake reviews
            - generic [ref=f6e166]:
              - generic [ref=f6e167]: Backup password (at least 12 characters)
              - textbox "Backup password (at least 12 characters)" [ref=f6e168]
              - generic [ref=f6e169]: Keep the password safe. It cannot be recovered for you.
            - button "Create backup" [disabled] [ref=f6e171]
            - status [ref=f6e175]: No backup file has been created in this session.
            - group [ref=f6e176]:
              - generic "Restore backup" [ref=f6e177] [cursor=pointer]
        - generic [ref=f6e178]:
          - heading "Recent captures" [level=2] [ref=f6e179]
          - list [ref=f6e180]:
            - listitem [ref=f6e181]:
              - link "Updated basic project" [ref=f6e182] [cursor=pointer]:
                - /url: /assets/project/1139cd52-01fc-4c71-9401-676b46a1596d
              - generic [ref=f6e183]: Projects
      - generic [ref=f6e184]:
        - heading "Import review" [level=2] [ref=f6e185]
        - paragraph [ref=f6e187]: Review each imported record before confirming or ignoring it.
```

# Test source

```ts
  1   | // 2026-10-29 user scope: B1/B2/B8 retired; historical schema/KA1 data stays lossless.
  2   | // Node preparation is synthetic, not user interaction. Mutations and readback use
  3   | // the compiled candidate's visible UI and downloaded encrypted backup only.
  4   | import { expect, test } from "@playwright/test";
  5   | import { createHash } from "node:crypto";
  6   | import { readFileSync } from "node:fs";
  7   | import { resolve } from "node:path";
  8   | import { strFromU8, unzipSync } from "fflate";
  9   | import { assetSchema, historySchema, newAsset, submissionSchema, type Asset } from "../../packages/domain/src";
  10  | import { decryptBackup } from "../../packages/local-db/src/backup-crypto";
  11  | import { resources } from "../../apps/web/src/i18n";
  12  | import { openBackupRestorePanel } from "./helpers/backup-restore";
  13  | import { prepareCompletionArchive, recordDevelopmentRequests } from "./helpers/completion-archive";
  14  | 
  15  | const password = "Synthetic-project-retirement-compatibility";
  16  | const directory = resolve("test-results/project-simplification-fixture");
  17  | const digest = (bytes: Uint8Array) => createHash("sha256").update(bytes).digest("hex");
  18  | async function prepare() {
  19  | 	return prepareCompletionArchive(directory, password, async db => {
  20  | 		const file = readFileSync(resolve("apps/web/public/samples/logo.png"));
  21  | 		const id = await db.putFile(new File([file], "legacy-logo.png", { type: "image/png" }));
  22  | 		const project = assetSchema.parse({ ...newAsset("project"), name: "Legacy project", category: "", url: "https://project.example.test/",
  23  | 			description: "Basic description", contact: "Basic contact", notes: "Basic note", tags: ["legacy"],
  24  | 			projectLaunchMonth: "2025-11", projectInspectionDate: "2026-11-15",
  25  | 			projectTitle: "Legacy title", projectPromoUrl: "https://promo.example.test/", projectMediumDescription: "Legacy medium copy",
  26  | 			longDescription: "Legacy long copy must not merge into ordinary notes", projectFeatures: "Legacy features", projectPricing: "Legacy pricing",
  27  | 			projectPricingType: "Legacy type", projectEmail: "legacy@example.test", attachments: [id],
  28  | 			projectMedia: { logoId: id, homeScreenshotId: "", productScreenshotIds: [], promoCoverId: "" } });
  29  | 		const vault = { ...newAsset("vault"), name: "Legacy external vault", location: "Synthetic location" };
  30  | 		const relation = { id: crypto.randomUUID(), from: project.id, to: vault.id, label: "Historical relation", createdAt: project.createdAt, verifiedAt: "", deleted: false };
  31  | 		const submission = submissionSchema.parse({ id: crypto.randomUUID(), assetId: project.id, name: "Legacy backlink", url: "https://directory.example.test/old", status: "verify", evidence: "Historical receipt" });
  32  | 		await db.saveBatch([{ type: "asset", value: project }, { type: "asset", value: vault }, { type: "relation", value: relation }, { type: "submission", value: submission }]);
  33  | 		const expense = historySchema.parse({ id: crypto.randomUUID(), assetId: project.id, action: "expense", title: "Legacy project expense",
  34  | 			note: "Ordinary retained project expense", amount: 1234, currency: "USD", eventDate: "2026-10-27", createdAt: "2026-10-27T00:00:00.000Z" });
  35  | 		await db.createFinanceEntry(expense);
  36  | 		return { project, vault, relation, submission, expense, fileDigest: digest(file) };
  37  | 	});
  38  | }
  39  | let fixture: Awaited<ReturnType<typeof prepare>>;
  40  | test.beforeAll(async () => { fixture = await prepare(); });
  41  | 
  42  | for (const [locale, width] of [["zh-CN", 390], ["en", 1280]] as const) test(`${locale} ${width}: removed project UI preserves legacy backup data`, async ({ browser }) => {
  43  | 	test.setTimeout(120_000);
  44  | 	const context = await browser.newContext({ locale, viewport: { width, height: 900 }, acceptDownloads: true });
  45  | 	await context.addInitScript(language => localStorage.setItem("keepany-language", language), locale);
  46  | 	const developmentRequests = recordDevelopmentRequests(context), errors: string[] = [];
  47  | 	const page = await context.newPage(); page.on("pageerror", error => errors.push(error.message));
  48  | 	const t = (key: keyof typeof resources.en.translation) => resources[locale].translation[key];
  49  | 	async function archive() {
  50  | 		await page.goto("/intake"); await page.locator("#backup-password").fill(password);
  51  | 		await page.getByRole("button", { name: t("backup"), exact: true }).click();
  52  | 		const link = page.getByRole("link", { name: t("saveBackupFile"), exact: true }); await expect(link).toBeVisible();
  53  | 		const pending = page.waitForEvent("download"); await link.click(); const path = await (await pending).path();
  54  | 		if (!path) throw Error("backup-download-missing");
  55  | 		const entries = unzipSync(await decryptBackup(new Uint8Array(readFileSync(path)), password));
  56  | 		const rows = JSON.parse(strFromU8(entries["records.json"])) as { id: string; type: string; payload: string }[];
  57  | 		return { entries, rows, asset: JSON.parse(rows.find(row => row.type === "asset" && JSON.parse(row.payload).id === fixture.project.id)!.payload) as Asset };
  58  | 	}
  59  | 	const goProject = () => page.goto(`/assets/project/${fixture.project.id}`);
  60  | 	const edit = () => page.locator(".asset-project-action-bar").getByRole("button", { name: t("edit"), exact: true }).click();
  61  | 	try {
  62  | 		await page.goto("/intake"); await page.locator("#backup-password").fill(password); await openBackupRestorePanel(page);
  63  | 		await page.locator("#restore-file").setInputFiles(resolve(directory, "fixture.ka1"));
  64  | 		await page.getByRole("button", { name: t("preview"), exact: true }).first().click();
  65  | 		await page.getByRole("button", { name: /^(确认|Confirm) ·/ }).click();
  66  | 		await expect(page.getByText(locale === "en" ? /Restored \d+ records/ : /已恢复 \d+ 条记录/)).toBeVisible();
  67  | 		await expect(page.getByText(t("intakeExternalLinkImport"), { exact: true })).toHaveCount(0);
  68  | 		await goProject();
  69  | 		await expect(page.locator(".asset-backlinks-card, .asset-project-materials, .asset-project-stats, [data-project-media-role]")).toHaveCount(0);
  70  | 		await expect(page.locator(".asset-attachments-card .image-item img")).toHaveCount(1);
  71  | 		await expect(page.locator(".asset-project-profile-card")).toContainText("Basic contact");
  72  | 		await expect(page.locator(`.asset-finance-card [data-bill-id="${fixture.expense.id}"]`)).toContainText(fixture.expense.title!);
  73  | 		const layout = await page.locator("main.asset-detail-project").evaluate(main => {
  74  | 			const hero = main.querySelector(":scope > .page-header")!.getBoundingClientRect();
  75  | 			const finance = main.querySelector(":scope > .asset-finance-card")!.getBoundingClientRect();
  76  | 			return { heroBottom: hero.bottom, financeTop: finance.top,
  77  | 				emptyMetaSpans: [...main.querySelectorAll(".asset-project-hero-meta > span")].filter(node => !node.textContent?.trim()).length,
  78  | 				overflow: document.documentElement.scrollWidth > innerWidth + 1 };
  79  | 		});
  80  | 		await test.info().attach("project-expense-layout", { body: JSON.stringify(layout), contentType: "application/json" });
  81  | 		await page.screenshot({ path: test.info().outputPath("project-expense-layout.png"), fullPage: true });
  82  | 		expect.soft(layout.heroBottom, "Project title and hero precede its ordinary expense ledger").toBeLessThanOrEqual(layout.financeTop);
> 83  | 		expect.soft(layout.emptyMetaSpans, "An empty category must not render an empty capsule").toBe(0);
      |                                                                                            ^ Error: An empty category must not render an empty capsule
  84  | 		expect.soft(layout.overflow, "The restored project with an expense fits the viewport").toBe(false);
  85  | 		await edit(); const form = page.getByRole("dialog");
  86  | 		await expect(form.locator("#projectTitle, #projectPromoUrl, #projectEmail, #projectLogoFile, #longDescription")).toHaveCount(0);
  87  | 		await expect(form.locator("#notes")).toHaveValue("Basic note");
  88  | 		await form.locator("#name").fill("Cancelled name"); await form.getByRole("button", { name: t("cancel"), exact: true }).click();
  89  | 		expect((await archive()).asset).toEqual(fixture.project);
  90  | 		await goProject(); await edit();
  91  | 		await form.locator("#name").fill("Updated basic project"); await form.locator("#notes").fill("Updated ordinary note");
  92  | 		await form.locator("#tags").fill("legacy, retained");
  93  | 		await form.getByRole("button", { name: t("save"), exact: true }).click(); await expect(form).toHaveCount(0); await page.reload();
  94  | 		await expect(page.locator(".asset-project-profile-card")).toContainText("Updated ordinary note");
  95  | 		const result = await archive();
  96  | 		const { name, notes, tags, updatedAt, ...retained } = result.asset;
  97  | 		const { name: oldName, notes: oldNotes, tags: oldTags, updatedAt: oldUpdatedAt, ...before } = fixture.project;
  98  | 		expect({ name, notes, tags }).toEqual({ name: "Updated basic project", notes: "Updated ordinary note", tags: ["legacy", "retained"] });
  99  | 		expect(retained).toEqual(before);
  100 | 		expect(digest(result.entries[`files/${fixture.project.attachments[0]}`])).toBe(fixture.fileDigest);
  101 | 		for (const record of [fixture.submission, fixture.vault, fixture.relation, fixture.expense]) expect(JSON.parse(result.rows.find(row => JSON.parse(row.payload).id === record.id)!.payload)).toEqual(record);
  102 | 		await page.goto(`/assets/vault/${fixture.vault.id}`);
  103 | 		await expect(page.getByText(t("vaultReferenceRetired"), { exact: true })).toBeVisible();
  104 | 		await expect(page.getByRole("button", { name: t("edit"), exact: true })).toHaveCount(0);
  105 | 		await page.getByRole("link", { name: t("vaultReferenceBackup"), exact: true }).click(); await expect(page).toHaveURL(/\/intake$/);
  106 | 		expect(developmentRequests).toEqual([]); expect(errors).toEqual([]);
  107 | 		await test.info().attach("legacy-preservation-readback", { body: JSON.stringify({ rows: result.rows, developmentRequests, errors }), contentType: "application/json" });
  108 | 	} finally { await context.close(); }
  109 | });
  110 | 
```