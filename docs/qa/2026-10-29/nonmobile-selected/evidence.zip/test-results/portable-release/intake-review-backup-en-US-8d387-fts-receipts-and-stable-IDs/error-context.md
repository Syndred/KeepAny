# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: intake-review-backup.spec.ts >> en-US downloaded encrypted backup restores CSV and legacy PDF drafts, receipts and stable IDs
- Location: tests\e2e\intake-review-backup.spec.ts:31:42

# Error details

```
Error: expect(received).toHaveLength(expected)

Expected length: 2
Received length: 1
Received array:  [{"asset": {"accountProfileVerifiedAt": "", "accountProvider": "", "amount": 0, "attachments": [], "billingAnchor": "", "borrower": "", "cancelledAt": "", "category": "", "contact": "", "createdAt": "2026-10-29T05:58:08.815Z", "currency": "CNY", "cycle": "month", "deleted": false, "description": "Ignored PDF reference USD 99.00", "discountAmount": 0, "discountUntil": "", "dueDate": "", "id": "pdf-b588d336a32415c78c184e246656617831a7f633148f3221", "interval": 1, "itemExpectedReturnDate": "", "itemLifecycleStatus": "inUse", "itemMedia": {"coverId": "", "detailIds": [], "receiptIds": []}, "itemPurchasePriceKnown": false, "itemStartDate": "", "itemStatusDate": "", "itemWarrantyStatus": "unverified", "kind": "item", "lastItemEventId": "", "lastRenewalId": "", "lastSubscriptionSaveId": "", "location": "", "longDescription": "", "name": "invoice-ignored", "notes": "", "projectDomains": [], "projectEmail": "", "projectFeatures": "", "projectInspectionDate": "", "projectLaunchMonth": "", "projectMedia": {"homeScreenshotId": "", "logoId": "", "productScreenshotIds": [], "promoCoverId": ""}, "projectMediumDescription": "", "projectPricing": "", "projectPricingType": "", "projectPromoUrl": "", "projectTitle": "", "purchaseDate": "", "renewalCount": 0, "status": "active", "subscriptionPaymentMethod": "", "tags": [], "trialEndsAt": "", "updatedAt": "2026-10-29T05:58:08.815Z", "url": "", "username": "", "warrantyDate": ""}, "fileHash": "b588d336a32415c78c184e246656617831a7f633148f3221fe4237ac786fb2af", "fileName": "invoice-ignored.pdf", "id": "pdf-b588d336a32415c78c184e246656617831a7f633148f3221fe4237ac786fb2af", "kindSelected": false, "rowNumber": 1, "source": "pdf", "sourceText": "Ignored PDF reference USD 99.00", "status": "ignored"}]
```

# Test source

```ts
  1   | import { readFileSync } from 'node:fs';
  2   | import { expect, test, type Page } from '@playwright/test';
  3   | import { strFromU8, unzipSync } from 'fflate';
  4   | import { decryptBackup } from '../../packages/local-db/src/backup-crypto';
  5   | import { pdf as makePdf } from "./fixtures/pdf";
  6   | import type { ReviewedCandidate } from '../../packages/local-db/src/intake-review';
  7   | import { selectChoice } from "./helpers/select-choice";
  8   | import { prepareLegacyPdfArchive, restoreCompletionArchive } from "./helpers/completion-archive";
  9   | import { openBackupRestorePanel } from "./helpers/backup-restore";
  10  | 
  11  | const password = 'intake-review-backup-test-password';
  12  | const csv = Buffer.from('name,kind\nPending CSV,project\nAccepted CSV,project\nIgnored CSV,item');
  13  | 
  14  | 
  15  | async function download(page: Page, zh: boolean) {
  16  |   await page.locator('#backup-password').fill(password);
  17  |   await page.getByRole('button', { name: zh ? '创建备份' : 'Create backup', exact: true }).click();
  18  |   const link = page.getByRole('link', { name: zh ? '保存备份文件' : 'Save backup file' });
  19  |   await expect(link).toBeVisible();
  20  |   const downloaded = page.waitForEvent('download'); await link.click();
  21  |   const result = await downloaded, path = await result.path();
  22  |   if (!path) throw Error('download-missing');
  23  |   expect(result.suggestedFilename()).toMatch(/\.ka1$/);
  24  |   const bytes = readFileSync(path);
  25  |   expect(bytes.subarray(0, 8).toString()).toBe('KEEPANY1');
  26  |   const entries = unzipSync(await decryptBackup(new Uint8Array(bytes), password));
  27  |   return { path, rows: JSON.parse(strFromU8(entries['records.json'])) as Array<{ id: string; payload: string }>,
  28  |     candidates: JSON.parse(strFromU8(entries['intake-review.json'])) as ReviewedCandidate[] };
  29  | }
  30  | 
  31  | for (const locale of ['zh-CN', 'en-US']) test(`${locale} downloaded encrypted backup restores CSV and legacy PDF drafts, receipts and stable IDs`, async ({ browser }) => {
  32  |   const zh = locale === 'zh-CN';
  33  |   const source = await browser.newContext({ locale, viewport: { width: 390, height: 844 } });
  34  |   const page = await source.newPage(); const errors: string[] = [];
  35  |   page.on('pageerror', error => errors.push(error.message));
  36  |   const pendingPdf = makePdf(['Original PDF reference USD 12.00']), ignoredPdf = makePdf(['Ignored PDF reference USD 99.00']);
  37  |   const legacy = await prepareLegacyPdfArchive(test.info().outputPath('legacy-pdf-fixture'), password, [
  38  |     { fileName: 'invoice-pending.pdf', text: 'Original PDF reference USD 12.00' },
  39  |     { fileName: 'invoice-ignored.pdf', text: 'Ignored PDF reference USD 99.00' },
  40  |   ]);
  41  |   try {
  42  |     await page.goto('/intake');
  43  |     await page.locator('.intake-mode-tabs').getByRole('button', { name: zh ? '表格' : 'Spreadsheet', exact: true }).click();
  44  |     await page.locator('#csv-file').setInputFiles({ name: 'intake-backup.csv', mimeType: 'text/csv', buffer: csv });
  45  |     const rows = page.locator('.intake-review-row'); await expect(rows).toHaveCount(3);
  46  |     await rows.nth(0).getByLabel(zh ? '名称' : 'Name', { exact: true }).fill('Edited pending CSV');
  47  |     await rows.nth(0).getByLabel(zh ? '简短描述' : 'Short description').fill('CSV pending manual edit');
  48  |     await rows.nth(1).getByLabel(zh ? '名称' : 'Name', { exact: true }).fill('Edited accepted CSV');
  49  |     await rows.nth(1).getByRole('button', { name: zh ? '确认入库' : 'Confirm and save', exact: true }).click();
  50  |     await expect(rows.nth(1)).toContainText(zh ? '已确认' : 'Confirmed');
  51  |     await rows.nth(2).getByRole('button', { name: zh ? '忽略' : 'Ignore', exact: true }).click();
  52  |     await expect(rows.nth(2)).toContainText(zh ? '已忽略' : 'Ignored');
  53  |     // Historical PDF rows are test preparation; only the candidate's visible KA1 restore consumes them.
  54  |     await restoreCompletionArchive(page, password, legacy.path);
  55  |     const pendingBatch = page.getByRole('region', { name: 'invoice-pending.pdf', exact: true });
  56  |     const pending = pendingBatch.locator('.intake-review-row');
  57  |     await expect(pending).toBeVisible();
  58  |     await selectChoice(pending.getByLabel(zh ? '资料类型' : 'Record type'), 'account');
  59  |     await pending.getByLabel(zh ? '名称' : 'Name', { exact: true }).fill('Edited pending PDF');
  60  |     await pending.getByLabel(zh ? '简短描述' : 'Short description').fill('PDF manual edit');
  61  |     await pendingBatch.getByText(zh ? '查看提取原文' : 'View extracted text', { exact: true }).click();
  62  |     await expect(pendingBatch.locator('.intake-review-original pre')).toContainText('Original PDF reference USD 12.00');
  63  |     await page.getByRole('region', { name: 'invoice-ignored.pdf', exact: true }).locator('.intake-review-row').getByRole('button', { name: zh ? '忽略' : 'Ignore', exact: true }).click();
  64  |     await expect(rows).toHaveCount(5);
  65  |     const before = await download(page, zh);
  66  |     expect(before.rows).toHaveLength(1); expect(before.candidates).toHaveLength(5);
  67  |     expect(before.candidates.filter(row => row.status === 'accepted')).toHaveLength(1);
> 68  |     expect(before.candidates.filter(row => row.status === 'ignored')).toHaveLength(2);
      |                                                                       ^ Error: expect(received).toHaveLength(expected)
  69  |     expect(before.candidates.find(row => row.source === 'pdf' && row.status === 'pending')).toMatchObject({
  70  |       kindSelected: true, sourceText: expect.stringContaining('Original PDF reference USD 12.00'),
  71  |       asset: { name: 'Edited pending PDF', kind: 'account', description: 'PDF manual edit' },
  72  |     });
  73  |     const destination = await browser.newContext({ locale, viewport: { width: 390, height: 844 } });
  74  |     const restored = await destination.newPage(); restored.on('pageerror', error => errors.push(error.message));
  75  |     try {
  76  |       await restored.goto('/intake'); await expect(restored.locator('.intake-review-row')).toHaveCount(0);
  77  |       await restored.locator('#backup-password').fill(password);
  78  |       await openBackupRestorePanel(restored);
  79  |       await restored.locator('#restore-file').setInputFiles(before.path);
  80  |       await restored.getByRole('button', { name: zh ? '预览' : 'Preview', exact: true }).first().click();
  81  |       const confirm = restored.getByRole('button', { name: /^(确认|Confirm) · 1/ });
  82  |       await expect(restored.getByRole('status').filter({ hasText: zh ? '资料记录：1 · 收录审核：5' : 'Records: 1 · Intake reviews: 5' })).toBeVisible();
  83  |       await confirm.click();
  84  |       const restoredRows = restored.locator('.intake-review-row'); await expect(restoredRows).toHaveCount(5);
  85  |       await restored.reload(); await expect(restoredRows).toHaveCount(5);
  86  |       expect((await download(restored, zh)).candidates).toEqual(before.candidates);
  87  |       await restored.locator('.intake-mode-tabs').getByRole('button', { name: zh ? '表格' : 'Spreadsheet', exact: true }).click();
  88  |       await restored.locator('#csv-file').setInputFiles({ name: 'renamed.csv', mimeType: 'text/csv', buffer: csv });
  89  |       await restored.locator('#csv-file').setInputFiles({ name: 'renamed-pending.pdf', mimeType: 'application/pdf', buffer: pendingPdf });
  90  |       await expect(restored.getByText(zh ? /不再支持导入 PDF/ : /PDF import is no longer supported/)).toBeVisible();
  91  |       await restored.locator('#csv-file').setInputFiles({ name: 'renamed-ignored.pdf', mimeType: 'application/pdf', buffer: ignoredPdf });
  92  |       await expect(restored.getByText(zh ? /不再支持导入 PDF/ : /PDF import is no longer supported/)).toBeVisible();
  93  |       await expect(restoredRows).toHaveCount(5);
  94  |       const after = await download(restored, zh); expect(after).toEqual({ ...before, path: after.path });
  95  |       const restoredBatch = restored.getByRole('region', { name: 'invoice-pending.pdf', exact: true });
  96  |       const restoredPdf = restoredBatch.locator('.intake-review-row');
  97  |       await restoredBatch.getByText(zh ? '查看提取原文' : 'View extracted text', { exact: true }).click();
  98  |       await expect(restoredBatch.locator('.intake-review-original pre')).toContainText('Original PDF reference USD 12.00');
  99  |       await expect(restoredPdf.getByLabel(zh ? '资料类型' : 'Record type')).toHaveAttribute("data-value", 'account');
  100 |       await restored.screenshot({ path: test.info().outputPath(`intake-review-backup-${locale}.png`), fullPage: true });
  101 |       expect(await restored.evaluate(() => document.documentElement.scrollWidth > innerWidth)).toBe(false);
  102 |       await restoredPdf.getByRole('button', { name: zh ? '确认入库' : 'Confirm and save', exact: true }).click();
  103 |       await expect(restoredPdf).toContainText(zh ? '已确认' : 'Confirmed');
  104 |       await restored.goto('/assets/account'); await expect(restored.getByText('Edited pending PDF', { exact: true })).toBeVisible();
  105 |       expect(errors).toEqual([]);
  106 |     } finally { await destination.close(); }
  107 |   } finally { await source.close(); }
  108 | });
  109 | 
```