# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: core-pages-matrix.spec.ts >> zh-CN overview, intake, settings and trash fit 360px
- Location: tests\e2e\core-pages-matrix.spec.ts:9:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: '回收站', level: 1 })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('heading', { name: '回收站', level: 1 }) with timeout 5000ms
  - waiting for getByRole('heading', { name: '回收站', level: 1 })

```

```yaml
- complementary:
  - strong: KeepAny
  - text: 个人资产工作台
  - button "关闭"
  - button "个人工作区":
    - strong: 个人工作区
  - text: 工作空间
  - navigation "导航":
    - button "概览 按住拖动排序"
    - link "概览":
      - /url: /
    - button "待办 按住拖动排序"
    - link "待办":
      - /url: /tasks
    - button "资产 按住拖动排序"
    - link "资产":
      - /url: /assets
    - button "账号 按住拖动排序"
    - link "账号":
      - /url: /accounts
  - link "回收站":
    - /url: /trash
  - text: 我的分类
  - link "自定义侧边栏":
    - /url: /collections
  - button "我 我的工作区 仅自己可见":
    - text: 我
    - strong: 我的工作区
    - text: 仅自己可见
- banner:
  - button "导航"
  - link "返回概览":
    - /url: /
  - button "搜索全部资料"
  - link "待办提醒":
    - /url: /tasks
  - button "AI 助手与授权"
  - link "收录与备份":
    - /url: /intake
- main:
  - status: 正在打开资料…
```

# Test source

```ts
  1   | import { mkdirSync } from "node:fs";
  2   | import { expect, test } from "@playwright/test";
  3   | import { selectChoice } from "./helpers/select-choice";
  4   | 
  5   | const evidence = process.env.KEEPANY_EVIDENCE_DIR ?? "docs/evidence/2026-09-29";
  6   | 
  7   | for (const locale of ["en-US", "zh-CN"] as const) {
  8   | 	for (const width of [360, 390, 768, 1280, 1440]) {
  9   | 		test(`${locale} overview, intake, settings and trash fit ${width}px`, async ({
  10  | 			browser,
  11  | 		}) => {
  12  | 			test.setTimeout(90_000);
  13  | 			mkdirSync(evidence, { recursive: true });
  14  | 			const context = await browser.newContext({
  15  | 				locale,
  16  | 				viewport: { width, height: 844 },
  17  | 			});
  18  | 			const page = await context.newPage();
  19  | 			const errors: string[] = [];
  20  | 			page.on("pageerror", (error) => errors.push(error.message));
  21  | 			const copy =
  22  | 				locale === "zh-CN"
  23  | 					? {
  24  | 							add: "新增",
  25  | 							name: "名称",
  26  | 							save: "保存",
  27  | 							move: "移至回收站",
  28  | 							restore: "恢复",
  29  | 							overview: "概览",
  30  | 							intake: "随手收录，慢慢整理。",
  31  | 							settings: "设置",
  32  | 							trash: "回收站",
  33  | 						}
  34  | 					: {
  35  | 							add: "Add",
  36  | 							name: "Name",
  37  | 							save: "Save",
  38  | 							move: "Move to trash",
  39  | 							restore: "Restore",
  40  | 							overview: "Overview",
  41  | 							intake: "Collect now, organize later.",
  42  | 							settings: "Settings",
  43  | 							trash: "Trash",
  44  | 						};
  45  | 			const stem = `core-${locale === "zh-CN" ? "zh" : "en"}-${width}`;
  46  | 			async function verifyPage(title: string) {
  47  | 				await expect(
  48  | 					page.getByRole("heading", { level: 1, name: title }),
> 49  | 				).toBeVisible();
      |       ^ Error: expect(locator).toBeVisible() failed
  50  | 				expect(
  51  | 					await page.evaluate(() => document.documentElement.scrollWidth),
  52  | 					`${locale} ${width}px ${page.url()}`,
  53  | 				).toBeLessThanOrEqual(width);
  54  | 				const padding = await page.locator("main.page").evaluate((element) => {
  55  | 					const style = getComputedStyle(element);
  56  | 					return [style.paddingTop, style.paddingRight, style.paddingBottom, style.paddingLeft].map(Number.parseFloat);
  57  | 				});
  58  | 				for (const [index, value] of padding.entries()) expect(value, "Page padding stays compact").toBeLessThanOrEqual(index === 2 ? 24 : 16);
  59  | 			}
  60  | 			async function verifyReadableSubscription(name: string) {
  61  | 				const card = page.locator(".asset-library-card").filter({ hasText: name }).first();
  62  | 				await expect(card).toBeVisible();
  63  | 				await expect(card.locator(".asset-library-meta")).toContainText("90,071,992,547,409.91");
  64  | 				expect(await card.evaluate((element) => element.scrollWidth <= element.clientWidth)).toBe(true);
  65  | 			}
  66  | 			try {
  67  | 				await page.goto("/assets/subscription");
  68  | 				await page.getByRole("button", { name: copy.add, exact: true }).click();
  69  | 				let dialog = page.getByRole("dialog");
  70  | 				const subscription = `Core subscription ${locale} ${width}`;
  71  | 				await dialog.getByLabel(copy.name, { exact: true }).fill(subscription);
  72  | 				await dialog.locator("#amount").fill("90071992547409.91");
  73  | 				await dialog.locator("#dueDate").fill("2026-10-31");
  74  | 				await dialog.getByRole("button", { name: copy.save }).click();
  75  | 				await expect(dialog).toBeHidden();
  76  | 				if (width <= 390) {
  77  | 					await verifyReadableSubscription(subscription);
  78  | 					await page.screenshot({
  79  | 						path: `${evidence}/${stem}-subscription-list.png`,
  80  | 					});
  81  | 				}
  82  | 
  83  | 				await page.goto("/");
  84  | 				await verifyPage(copy.overview);
  85  | 				await expect(page.locator(".overview-action-row")).toContainText(subscription);
  86  | 				await expect(page.locator(".overview-stat").first()).toContainText("1");
  87  | 				const actionDate = page.locator(".overview-action-date strong").first();
  88  | 				await expect(actionDate).toBeVisible();
  89  | 				const dateLines = await actionDate.evaluate((element) => {
  90  | 					const range = document.createRange();
  91  | 					range.selectNodeContents(element);
  92  | 					return [...range.getClientRects()].filter((rect) => rect.width > 0 && rect.height > 0).length;
  93  | 				});
  94  | 				expect(dateLines, "The due date stays on one readable line").toBe(1);
  95  | 				await page.screenshot({
  96  | 					path: `${evidence}/${stem}-overview-populated.png`,
  97  | 					fullPage: true,
  98  | 				});
  99  | 
  100 | 				await page.goto("/intake");
  101 | 				await verifyPage(copy.intake);
  102 | 				await expect(page.locator("#backup-password")).toBeVisible();
  103 | 				await page.screenshot({
  104 | 					path: `${evidence}/${stem}-intake.png`,
  105 | 					fullPage: true,
  106 | 				});
  107 | 
  108 | 				await page.goto("/settings");
  109 | 				await verifyPage(copy.settings);
  110 | 				await page.screenshot({
  111 | 					path: `${evidence}/${stem}-settings.png`,
  112 | 					fullPage: true,
  113 | 				});
  114 | 
  115 | 				await page.goto("/trash");
  116 | 				await verifyPage(copy.trash);
  117 | 				await page.screenshot({ path: `${evidence}/${stem}-trash-empty.png` });
  118 | 				await page.goto("/assets/project");
  119 | 				await page.getByRole("button", { name: copy.add, exact: true }).click();
  120 | 				dialog = page.getByRole("dialog");
  121 | 				const project = `Core ${"L".repeat(150)}`;
  122 | 				await dialog.getByLabel(copy.name, { exact: true }).fill(project);
  123 | 				await dialog.getByRole("button", { name: copy.save }).click();
  124 | 				await expect(dialog).toBeHidden();
  125 | 				await page
  126 | 					.locator("main.page .list-row")
  127 | 					.filter({ hasText: project })
  128 | 					.click();
  129 | 				await page
  130 | 					.locator("main.page > .asset-project-action-bar")
  131 | 					.getByRole("button", { name: copy.move })
  132 | 					.click();
  133 | 				await page
  134 | 					.getByRole("dialog")
  135 | 					.getByRole("button", { name: copy.move })
  136 | 					.click();
  137 | 				await expect(page).toHaveURL(/\/assets\/project$/);
  138 | 				await page.goto("/trash");
  139 | 				await verifyPage(copy.trash);
  140 | 				const row = page.locator("main.page .list-row").filter({
  141 | 					hasText: project,
  142 | 				});
  143 | 				await expect(row).toBeVisible();
  144 | 				await expect(
  145 | 					row.getByRole("button", { name: copy.restore }),
  146 | 				).toBeVisible();
  147 | 				await page.screenshot({
  148 | 					path: `${evidence}/${stem}-trash-populated.png`,
  149 | 					fullPage: true,
```