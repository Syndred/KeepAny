# b507：30真实忙碌＋10有资料Social的独立取证

实际ZIP SHA3db95a056862bb62c5e698b209b1bd0c582da1d720bec91747f8df7420c281cc；sourceCommit b5078901316309ee138a42b66f53c4324cf5c020/sourceDirty=true；实际HTTP入口SHA2067bd5a748b664b7b4dd218027a12f693cdfd7fed8f35de6393231429317403。每份raw identity来自实际HTTP及原ZIP，未把d2旧结果改标签。

首轮强busy固定原输入10组：7通过、en1280详情恢复在860.78ms截图间结束导致after disabled=false，2未运行；保存全部原始JSON/PNG/log/result与失败trace。该失败是取帧跨真实状态窗，不据此判产品失败，原帧不计通过。7完整组的21消费者，加上同一失败组已完成的workspace原子状态，共22个有效消费者保留。

基于具体860.78ms窗口，补缺只执行英文1280（详情/定向）、1920和2560（三消费者），共8状态。合法虚构辅助库备注8000→32000字符，仍200条且每字段低于65536；实际UI文件导入，保留原8 sample ID/关联，最终208条。新库源文件实际解密计数确认200×32000，摘要在fixture-receipt.json；KDBX二进制不入本档。产品configureDatabase固定Argon2id配置，未通过改产品KDF或人为hold busy延时。新输入3/3通过2.2m，原禁用前后/44px/几何/恢复ID/预算均不放宽；原22不重复取帧求绿。

最终30个consumer状态按busy-selection.json明确选择：workspace/detail/asset-filter×zh-CN/en×390/768/1280/1920/2560。每项真实操作前后完整按钮原子快照全部disabled，恢复前后全部false；恢复关联条目原ID/数量核对。按既有约定，CDP16倍主线程性能准备、截图为实际全部button rect并集加4px上下文；父容器/search几何另测，不以图片证明不可见字段。detail不提供sampleAccounts，恢复密码操作用来检同一toolbar忙碌，N/A原文保留。before/after可能因样例恢复更新出现9→8控件，但分别原子校验，不能把summary.buttons当同一after帧。

Social10固定冻结原输入全部通过1.9m：实际新建有资料自媒体和关联无密码条目，展开、邻居高度、类别筛选、搜索清除、键盘收起展开、刷新正常解锁及原条目恢复。未以空分类替代。

人工视觉：六张联系图内30busy＋30恢复的完整原button区域已全部实际打开；Social10的filtered/neighbors/restored30张原PNG均逐张实际打开。文字/动作可读，所看邻居不被拉伸，极简无密码显示及按钮状态可见。此判定只限这些原区域/状态，不能代替全部页面、FC20高级工具、普通布局26组/主控体验或最终CI/交付。正常26自动化另已26/26，视觉仍单独复核，不由本40范围外推。

正式预设引用为docs/qa/2026-10-28/evidence/final-vault-tools/independent-b507-states.zip；独立代理只在ignored自有目录产出，root逐CRC/manifest核对后复制。原d2归档不改。ZIP有每成员SHA/bytes的MANIFEST，原输入与failure事实完整保留；没有KDBX原二进制、用户秘密或rawNetLog。
