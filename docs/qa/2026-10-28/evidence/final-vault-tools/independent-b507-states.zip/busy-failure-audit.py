import pathlib,json
p=pathlib.Path('test-results/independent-final-b507/busy-large/en-1280.json');d=json.loads(p.read_text());
for x in d['steps']:
 if 'capture-timing'in x['stage']:print(x)
 if x['stage'].endswith('-after-screenshot'):print(x['stage'],'buttons',len(x['buttons']),'disabled',sum(b['disabled'] for b in x['buttons']))
print('tail stages',[x['stage'] for x in d['steps']][-9:])
