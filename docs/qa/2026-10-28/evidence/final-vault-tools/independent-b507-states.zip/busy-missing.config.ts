import {defineConfig} from '@playwright/test';import {resolve} from 'node:path';
export default defineConfig({testDir:resolve('test-results/independent-final-b507'),testIgnore:['**/inputs/**'],testMatch:'busy-missing.spec.ts',workers:1,retries:0,maxFailures:1,timeout:180000,outputDir:process.env.KEEPANY_INDEPENDENT_EVIDENCE+'/runs',reporter:[['list'],['json',{outputFile:process.env.KEEPANY_INDEPENDENT_EVIDENCE+'/results.json'}]],use:{baseURL:'http://127.0.0.1:4237',trace:{mode:'retain-on-failure',snapshots:false,screenshots:false,sources:true},screenshot:'only-on-failure'}});

