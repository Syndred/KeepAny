# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: unified-workspaces-release.spec.ts >> zh-CN 1280px built merged workspace preserves sample records, ledger and inline vault access
- Location: tests\e2e\unified-workspaces-release.spec.ts:9:2

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('.account-passwords-section').locator('#password-vault-master')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('.account-passwords-section').locator('#password-vault-master') with timeout 5000ms
  - waiting for locator('.account-passwords-section').locator('#password-vault-master')

```

```yaml
- complementary:
  - strong: KeepAny
  - text: 个人资产工作台
  - button "个人工作区":
    - strong: 个人工作区
  - text: 工作空间
  - navigation "导航":
    - button "概览 按住拖动排序"
    - link "概览":
      - /url: /
    - button "待办 按住拖动排序"
    - link "待办 5":
      - /url: /tasks
    - button "资产 按住拖动排序"
    - link "资产":
      - /url: /assets
    - button "账号 按住拖动排序"
    - link "账号":
      - /url: /accounts
    - status
  - link "回收站":
    - /url: /trash
  - text: 我的分类
  - link "工作室资料":
    - /url: /collections/b9dd3852-4530-4b03-af6a-aa73d1080ea4
  - link "自定义侧边栏":
    - /url: /collections
  - button "我 我的工作区 仅自己可见":
    - text: 我
    - strong: 我的工作区
    - text: 仅自己可见
- banner:
  - link "返回列表":
    - /url: /assets/account
  - button "搜索全部资料": 搜索全部资料 ⌘ K
  - link "待办提醒":
    - /url: /tasks
  - button "AI 助手与授权"
  - link "收录与备份":
    - /url: /intake
- complementary "需要留意的提醒":
  - strong: 1 项提醒
  - link "确认素材使用范围":
    - /url: /tasks#task-07410fac-fee9-4f76-8236-7a12ebb0ec3e
- main:
  - text: 账号 · 其他
  - heading "示例 | 松果内容频道" [level=1]
  - button "编辑"
  - button "移至回收站"
  - heading "关系图" [level=2]
  - paragraph: 1 个直接关联 · 18 个间接关联
  - button "添加关联"
  - button "直接关联" [pressed]
  - button "完整关系"
  - text: 查找关联
  - searchbox "查找关联"
  - group: 读图说明
  - region "关系图":
    - button "放大":
      - img
    - button "缩小":
      - img
    - button "适应画布"
    - button "全屏查看"
    - application:
      - img:
        - group "示例 | 松果内容频道 → 示例 | 工作室联系号码 · 验证号码 · 已核实"
      - text: 当前资料
      - strong: 示例 | 松果内容频道
      - text: pinecone
      - link "示例 | 工作室联系号码 +1 202-555-0142":
        - /url: /assets/account/901cc679-574a-4ac3-b954-5d34d66cf07e
        - strong: 示例 | 工作室联系号码
        - text: +1 202-555-0142
      - img
      - link "React Flow attribution":
        - /url: https://reactflow.dev?utm_source=attribution
        - text: React Flow
  - group: 关联明细 · 1
  - heading "待办" [level=2]
  - button "新增"
  - strong: 这里还没有内容
  - heading "基本信息" [level=2]
  - term: 服务商
  - definition: 未记录
  - term: 账号标识
  - definition: pinecone
  - term: 状态
  - definition: 使用中
  - term: 用途
  - definition: 独立工作室官网，连接产品、域名、联系账号与托管服务。
  - heading "记录与安全" [level=2]
  - term: 账号资料核实日期
  - definition: 未记录
  - term: 最近关系核验
  - definition: 2026年10月26日
  - button "收起密码" [expanded]
  - link "管理这个账号的密码":
    - /url: /assets/vault#asset-2bf8afd5-4472-4db2-96a9-eb09d6eb4e9b
  - region "密码库":
    - heading "密码库" [level=2]
    - paragraph: 密码只保存在本机加密库中。
    - status: 已锁定
    - heading "密码库已锁定" [level=3]
    - paragraph: 输入主密码解锁。
    - text: 主密码
    - textbox "主密码"
    - button "显示密码"
    - button "解锁密码库"
    - paragraph: 忘记密码时只能使用原主密码或恢复其他备份，无法自动重置。
  - heading "图片" [level=2]
  - button "添加图片"
  - strong: 这里还没有内容
  - heading "变更影响" [level=2]
  - paragraph: 按生成时的关联逐项核对，关联变更后请复核旧待办；完成只记录本机检查，不会更新第三方资料。
  - button "生成检查待办 · 1"
  - group "筛选待办":
    - button "全部 · 0" [pressed]
    - button "待处理 · 0"
    - button "已完成 · 0"
  - strong: 这里还没有内容
```

# Test source

```ts
  1  | import { mkdirSync } from "node:fs";
  2  | import { join } from "node:path";
  3  | import { expect, test } from "@playwright/test";
  4  | 
  5  | const evidence = process.env.KEEPANY_EVIDENCE_DIR ?? "/tmp/keepany-unified-built";
  6  | mkdirSync(evidence, { recursive: true });
  7  | 
  8  | for (const locale of ["zh-CN", "en-US"] as const) for (const width of [390, 1280]) {
  9  | 	test(`${locale} ${width}px built merged workspace preserves sample records, ledger and inline vault access`, async ({ browser }) => {
  10 | 		const context = await browser.newContext({ locale, viewport: { width, height: 950 } });
  11 | 		const page = await context.newPage();
  12 | 		const errors: string[] = [];
  13 | 		page.on("pageerror", (error) => errors.push(error.message));
  14 | 		const zh = locale === "zh-CN";
  15 | 		try {
  16 | 			await page.goto("/");
  17 | 			await page.getByRole("link", { name: zh ? "用示例资料开始" : "Start with sample records", exact: true }).click();
  18 | 			const add = page.getByRole("button", { name: zh ? "加入示例资料" : "Add sample records", exact: true });
  19 | 			await add.click();
  20 | 			await expect(add).toBeDisabled();
  21 | 			await expect(page.getByRole("button", { name: zh ? "完整示例资料已加入" : "Full sample records already added", exact: true })).toBeDisabled();
  22 | 			await page.goto("/assets");
  23 | 			await expect(page.getByRole("heading", { name: zh ? "资产" : "Assets", exact: true })).toBeVisible();
  24 | 			await expect(page.locator(".workspace-asset-grid .asset-project-card").first()).toBeVisible();
  25 | 			expect(await page.locator(".workspace-asset-grid .asset-library-card").count()).toBeGreaterThanOrEqual(2);
  26 | 			await expect(page.locator(".workspace-summary-grid > section")).toHaveCount(4);
  27 | 			await expect(page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).resolves.toBe(true);
  28 | 			await page.screenshot({ path: join(evidence, `built-assets-${zh ? "zh" : "en"}-${width}.png`), fullPage: true });
  29 | 			await page.locator(".workspace-navigation").getByRole("link", { name: zh ? "费用账本" : "Ledger", exact: true }).click();
  30 | 			await expect(page.locator(".finance-summary > section")).toHaveCount(3);
  31 | 			await expect(page.getByRole("heading", { name: zh ? "订阅与账单" : "Subscriptions and bills", exact: true })).toBeVisible();
  32 | 			await page.goto("/accounts");
  33 | 			await expect(page.getByRole("heading", { name: zh ? "账号" : "Accounts", exact: true })).toBeVisible();
  34 | 			await expect(page.locator(".asset-account-card").first()).toBeVisible();
  35 | 			await page.screenshot({ path: join(evidence, `built-accounts-${zh ? "zh" : "en"}-${width}.png`), fullPage: true });
  36 | 			await page.locator(".asset-account-card").first().click();
  37 | 			await page.getByRole("button", { name: zh ? "在此查看密码" : "View passwords here", exact: true }).click();
  38 | 			const passwords = page.locator(".account-passwords-section");
  39 | 			await expect(passwords.locator("#password-vault-master")).toBeVisible();
  40 | 			await expect(passwords.getByRole("status").filter({ hasText: zh ? "正在打开密码库" : "Opening the password vault" })).toHaveCount(0);
  41 | 			await expect(passwords).toBeFocused();
  42 | 			await expect(passwords).toBeInViewport();
  43 | 			await expect.poll(() => passwords.evaluate((section) => {
  44 | 				const facts = document.querySelector(".account-facts-grid");
  45 | 				if (!facts) return false;
  46 | 				const panel = section.getBoundingClientRect();
  47 | 				const source = facts.getBoundingClientRect();
  48 | 				return panel.top >= source.bottom - 1 && panel.width >= source.width - 1 && panel.top >= 0 && panel.top < innerHeight - 100;
  49 | 			})).toBe(true);
  50 | 			await page.screenshot({ path: join(evidence, `built-inline-open-${zh ? "zh" : "en"}-${width}.png`), fullPage: false });
  51 | 			await expect(page.locator(".account-passwords-section #password-vault-master")).toBeVisible();
  52 | 			await expect(page.getByRole("heading", { level: 1 })).toHaveCount(1);
  53 | 			await expect(page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).resolves.toBe(true);
  54 | 			const syntheticMaster = "Synthetic FC12 persistence 2026!";
  55 | 			await passwords.locator("#password-vault-master").fill(syntheticMaster);
  56 | 			await passwords.locator("#password-vault-master-confirm").fill(syntheticMaster);
  57 | 			await passwords.getByRole("button", { name: zh ? "创建密码库" : "Create vault", exact: true }).click();
  58 | 			await expect(passwords.locator(".password-vault-toolbar")).toBeVisible();
  59 | 			await page.reload();
  60 | 			await expect(page.getByRole("button", { name: zh ? "在此查看密码" : "View passwords here", exact: true })).toBeVisible();
  61 | 			await page.getByRole("button", { name: zh ? "在此查看密码" : "View passwords here", exact: true }).click();
> 62 | 			await expect(passwords.locator("#password-vault-master")).toBeVisible();
     |                                                              ^ Error: expect(locator).toBeVisible() failed
  63 | 			await expect(passwords.locator("#password-vault-master-confirm")).toHaveCount(0);
  64 | 			await expect(passwords).toBeFocused();
  65 | 			await expect.poll(() => passwords.evaluate((section) => section.getBoundingClientRect().top)).toBeGreaterThanOrEqual(0);
  66 | 			await expect.poll(() => passwords.evaluate((section) => section.getBoundingClientRect().top)).toBeLessThan(200);
  67 | 			await page.screenshot({ path: join(evidence, `built-inline-persisted-${zh ? "zh" : "en"}-${width}.png`), fullPage: false });
  68 | 			await passwords.locator("#password-vault-master").fill(syntheticMaster);
  69 | 			await passwords.getByRole("button", { name: zh ? "解锁密码库" : "Unlock vault", exact: true }).click();
  70 | 			await expect(passwords.locator(".password-vault-toolbar")).toBeVisible();
  71 | 			await page.getByRole("button", { name: zh ? "收起密码" : "Hide passwords", exact: true }).click();
  72 | 			await expect(passwords).toHaveCount(0);
  73 | 			expect(errors).toEqual([]);
  74 | 		} finally { await context.close(); }
  75 | 	});
  76 | }
  77 | 
```