# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: unified-workspaces-release.spec.ts >> en-US 390px built merged workspace preserves sample records, ledger and inline vault access
- Location: tests\e2e\unified-workspaces-release.spec.ts:9:2

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('.account-passwords-section').locator('#password-vault-master')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('.account-passwords-section').locator('#password-vault-master') with timeout 5000ms
  - waiting for locator('.account-passwords-section').locator('#password-vault-master')

```

```yaml
- complementary:
  - strong: KeepAny
  - text: Personal asset workspace
  - button "Close"
  - button "Personal workspace":
    - strong: Personal workspace
  - text: Workspace
  - navigation "Navigation":
    - button "Overview Drag to reorder"
    - link "Overview":
      - /url: /
    - button "Tasks Drag to reorder"
    - link "Tasks 5":
      - /url: /tasks
    - button "Assets Drag to reorder"
    - link "Assets":
      - /url: /assets
    - button "Accounts Drag to reorder"
    - link "Accounts":
      - /url: /accounts
    - status
  - link "Trash":
    - /url: /trash
  - text: Collections
  - link "Studio essentials":
    - /url: /collections/e5af8372-cd11-45cd-9ae9-69921b85df92
  - link "Customize sidebar":
    - /url: /collections
  - button "Me My workspace Only visible here":
    - text: Me
    - strong: My workspace
    - text: Only visible here
- banner:
  - button "Navigation"
  - link "Back to list":
    - /url: /assets/account
  - button "Search all records"
  - link "Task reminders":
    - /url: /tasks
  - button "AI assistant and access"
  - link "Import & backup":
    - /url: /intake
- complementary "Reminders to review":
  - strong: 1 reminder
  - link "Check media usage rights":
    - /url: /tasks#task-e81606aa-cf4f-488b-85c5-228c39a3f6b1
- main:
  - text: Accounts · Other
  - heading "Sample | Passwordless login" [level=1]
  - button "Edit"
  - button "Move to trash"
  - heading "Connections" [level=2]
  - paragraph: 1 direct · 18 indirect
  - button "Add connection"
  - button "Direct" [pressed]
  - button "All connections"
  - text: Find connections
  - searchbox "Find connections"
  - group: Graph guide
  - region "Connections":
    - button "Zoom in":
      - img
    - button "Zoom out":
      - img
    - button "Fit all"
    - button "Expand graph"
    - application:
      - img:
        - group "Sample | Passwordless login → Sample | Studio phone · Verification phone · Verified"
      - text: Current record
      - strong: Sample | Passwordless login
      - link "Sample | Studio phone +1 202-555-0142":
        - /url: /assets/account/a827596d-7f29-4ad1-9d47-56799e578804
        - strong: Sample | Studio phone
        - text: +1 202-555-0142
      - img
      - link "React Flow attribution":
        - /url: https://reactflow.dev?utm_source=attribution
        - text: React Flow
  - group: Connection detail · 1
  - heading "Tasks" [level=2]
  - button "Add"
  - strong: Nothing here yet
  - heading "Basic information" [level=2]
  - term: Provider
  - definition: Not recorded
  - term: Username / identifier
  - definition: Not recorded
  - term: Status
  - definition: Active
  - term: Purpose
  - definition: Not recorded
  - term: URL
  - definition:
    - link "https://login.example.com":
      - /url: https://login.example.com
  - heading "Records and security" [level=2]
  - term: Account profile reviewed
  - definition: Not recorded
  - term: Last connection verified
  - definition: Oct 26, 2026
  - button "Hide passwords" [expanded]
  - link "Manage this account’s passwords":
    - /url: /assets/vault#asset-3b2d7748-4c20-403e-a358-5de4178df744
  - region "Password vault":
    - heading "Password vault" [level=2]
    - paragraph: Passwords stay in the encrypted vault on this device.
    - status: Locked
    - heading "Password vault is locked" [level=3]
    - paragraph: Enter the master password to unlock.
    - text: Master password
    - textbox "Master password"
    - button "Show password"
    - button "Unlock vault"
    - paragraph: If you forget it, use the original master password or restore another backup; it cannot be reset automatically.
  - heading "Images" [level=2]
  - button "Add image"
  - strong: Nothing here yet
  - heading "Change impact" [level=2]
  - paragraph: Check the saved connections and review older tasks when connections change. Completing a task records a local check; it does not update other services.
  - button "Create checklist · 1"
  - group "Filter tasks":
    - button "All · 0" [pressed]
    - button "Pending · 0"
    - button "Completed · 0"
  - strong: Nothing here yet
```

# Test source

```ts
  1  | import { mkdirSync } from "node:fs";
  2  | import { join } from "node:path";
  3  | import { expect, test } from "@playwright/test";
  4  | 
  5  | const evidence = process.env.KEEPANY_EVIDENCE_DIR ?? "/tmp/keepany-unified-built";
  6  | mkdirSync(evidence, { recursive: true });
  7  | 
  8  | for (const locale of ["zh-CN", "en-US"] as const) for (const width of [390, 1280]) {
  9  | 	test(`${locale} ${width}px built merged workspace preserves sample records, ledger and inline vault access`, async ({ browser }) => {
  10 | 		const context = await browser.newContext({ locale, viewport: { width, height: 950 } });
  11 | 		const page = await context.newPage();
  12 | 		const errors: string[] = [];
  13 | 		page.on("pageerror", (error) => errors.push(error.message));
  14 | 		const zh = locale === "zh-CN";
  15 | 		try {
  16 | 			await page.goto("/");
  17 | 			await page.getByRole("link", { name: zh ? "用示例资料开始" : "Start with sample records", exact: true }).click();
  18 | 			const add = page.getByRole("button", { name: zh ? "加入示例资料" : "Add sample records", exact: true });
  19 | 			await add.click();
  20 | 			await expect(add).toBeDisabled();
  21 | 			await expect(page.getByRole("button", { name: zh ? "完整示例资料已加入" : "Full sample records already added", exact: true })).toBeDisabled();
  22 | 			await page.goto("/assets");
  23 | 			await expect(page.getByRole("heading", { name: zh ? "资产" : "Assets", exact: true })).toBeVisible();
  24 | 			await expect(page.locator(".workspace-asset-grid .asset-project-card").first()).toBeVisible();
  25 | 			expect(await page.locator(".workspace-asset-grid .asset-library-card").count()).toBeGreaterThanOrEqual(2);
  26 | 			await expect(page.locator(".workspace-summary-grid > section")).toHaveCount(4);
  27 | 			await expect(page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).resolves.toBe(true);
  28 | 			await page.screenshot({ path: join(evidence, `built-assets-${zh ? "zh" : "en"}-${width}.png`), fullPage: true });
  29 | 			await page.locator(".workspace-navigation").getByRole("link", { name: zh ? "费用账本" : "Ledger", exact: true }).click();
  30 | 			await expect(page.locator(".finance-summary > section")).toHaveCount(3);
  31 | 			await expect(page.getByRole("heading", { name: zh ? "订阅与账单" : "Subscriptions and bills", exact: true })).toBeVisible();
  32 | 			await page.goto("/accounts");
  33 | 			await expect(page.getByRole("heading", { name: zh ? "账号" : "Accounts", exact: true })).toBeVisible();
  34 | 			await expect(page.locator(".asset-account-card").first()).toBeVisible();
  35 | 			await page.screenshot({ path: join(evidence, `built-accounts-${zh ? "zh" : "en"}-${width}.png`), fullPage: true });
  36 | 			await page.locator(".asset-account-card").first().click();
  37 | 			await page.getByRole("button", { name: zh ? "在此查看密码" : "View passwords here", exact: true }).click();
  38 | 			const passwords = page.locator(".account-passwords-section");
  39 | 			await expect(passwords.locator("#password-vault-master")).toBeVisible();
  40 | 			await expect(passwords.getByRole("status").filter({ hasText: zh ? "正在打开密码库" : "Opening the password vault" })).toHaveCount(0);
  41 | 			await expect(passwords).toBeFocused();
  42 | 			await expect(passwords).toBeInViewport();
  43 | 			await expect.poll(() => passwords.evaluate((section) => {
  44 | 				const facts = document.querySelector(".account-facts-grid");
  45 | 				if (!facts) return false;
  46 | 				const panel = section.getBoundingClientRect();
  47 | 				const source = facts.getBoundingClientRect();
  48 | 				return panel.top >= source.bottom - 1 && panel.width >= source.width - 1 && panel.top >= 0 && panel.top < innerHeight - 100;
  49 | 			})).toBe(true);
  50 | 			await page.screenshot({ path: join(evidence, `built-inline-open-${zh ? "zh" : "en"}-${width}.png`), fullPage: false });
  51 | 			await expect(page.locator(".account-passwords-section #password-vault-master")).toBeVisible();
  52 | 			await expect(page.getByRole("heading", { level: 1 })).toHaveCount(1);
  53 | 			await expect(page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).resolves.toBe(true);
  54 | 			const syntheticMaster = "Synthetic FC12 persistence 2026!";
  55 | 			await passwords.locator("#password-vault-master").fill(syntheticMaster);
  56 | 			await passwords.locator("#password-vault-master-confirm").fill(syntheticMaster);
  57 | 			await passwords.getByRole("button", { name: zh ? "创建密码库" : "Create vault", exact: true }).click();
  58 | 			await expect(passwords.locator(".password-vault-toolbar")).toBeVisible();
  59 | 			await page.reload();
  60 | 			await expect(page.getByRole("button", { name: zh ? "在此查看密码" : "View passwords here", exact: true })).toBeVisible();
  61 | 			await page.getByRole("button", { name: zh ? "在此查看密码" : "View passwords here", exact: true }).click();
> 62 | 			await expect(passwords.locator("#password-vault-master")).toBeVisible();
     |                                                              ^ Error: expect(locator).toBeVisible() failed
  63 | 			await expect(passwords.locator("#password-vault-master-confirm")).toHaveCount(0);
  64 | 			await expect(passwords).toBeFocused();
  65 | 			await expect.poll(() => passwords.evaluate((section) => section.getBoundingClientRect().top)).toBeGreaterThanOrEqual(0);
  66 | 			await expect.poll(() => passwords.evaluate((section) => section.getBoundingClientRect().top)).toBeLessThan(200);
  67 | 			await page.screenshot({ path: join(evidence, `built-inline-persisted-${zh ? "zh" : "en"}-${width}.png`), fullPage: false });
  68 | 			await passwords.locator("#password-vault-master").fill(syntheticMaster);
  69 | 			await passwords.getByRole("button", { name: zh ? "解锁密码库" : "Unlock vault", exact: true }).click();
  70 | 			await expect(passwords.locator(".password-vault-toolbar")).toBeVisible();
  71 | 			await page.getByRole("button", { name: zh ? "收起密码" : "Hide passwords", exact: true }).click();
  72 | 			await expect(passwords).toHaveCount(0);
  73 | 			expect(errors).toEqual([]);
  74 | 		} finally { await context.close(); }
  75 | 	});
  76 | }
  77 | 
```