# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ai-account-import-release.spec.ts >> zh-CN account identifiers are reviewed, saved and retained at 1280px
- Location: tests\e2e\ai-account-import-release.spec.ts:15:3

# Error details

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 16
Received:    12
```

# Test source

```ts
  1   | import { mkdirSync } from "node:fs";
  2   | import { expect, test } from "@playwright/test";
  3   | import {
  4   | 	aiServer,
  5   | 	checkLayout,
  6   | 	evidence,
  7   | 	labels,
  8   | 	model,
  9   | 	syntheticKey,
  10  | } from "./helpers/ai-workflow";
  11  | import { selectChoice } from "./helpers/select-choice";
  12  | 
  13  | for (const language of ["zh-CN", "en"] as const) {
  14  | 	for (const width of [390, 1280]) {
  15  | 		test(`${language} account identifiers are reviewed, saved and retained at ${width}px`, async ({
  16  | 			browser,
  17  | 		}) => {
  18  | 			const copy = labels[language],
  19  | 				zh = language === "zh-CN";
  20  | 			const mock = await aiServer();
  21  | 			const context = await browser.newContext({
  22  | 				viewport: { width, height: 844 },
  23  | 			});
  24  | 			await context.addInitScript(
  25  | 				(value) => localStorage.setItem("keepany-language", value),
  26  | 				language,
  27  | 			);
  28  | 			const page = await context.newPage();
  29  | 			const errors: string[] = [];
  30  | 			page.on("pageerror", (error) => errors.push(error.message));
  31  | 			try {
  32  | 				await page.goto("/intake");
  33  | 				await expect(page.locator(".ai-import-panel")).toContainText(
  34  | 					zh ? "尚未配置 AI 模型" : "No AI model is configured",
  35  | 				);
  36  | 				await page.goto("/settings#assistant");
  37  | 				const settings = page.locator(".ai-settings-panel");
  38  | 				await selectChoice(
  39  | 					settings.locator("#ai-settings-provider"),
  40  | 					"compatible",
  41  | 				);
  42  | 				await settings.locator("#ai-settings-url").fill(mock.baseURL);
  43  | 				await settings.locator("#ai-settings-model").fill(model);
  44  | 				await selectChoice(
  45  | 					settings.locator("#ai-settings-key-source"),
  46  | 					"session",
  47  | 				);
  48  | 				await settings.locator("#ai-settings-api-key").fill(syntheticKey);
  49  | 				await settings
  50  | 					.getByRole("button", { name: copy.saveSettings, exact: true })
  51  | 					.click();
  52  | 				await expect(
  53  | 					settings.getByRole("status").filter({ hasText: copy.ready }),
  54  | 				).toBeVisible();
  55  | 				await page
  56  | 					.locator(".top-actions")
  57  | 					.getByRole("link", { name: copy.intake, exact: true })
  58  | 					.click();
  59  | 				const importer = page.locator(".ai-import-panel"),
  60  | 					rows = page.locator(".intake-review-row");
  61  | 				await expect(importer).toContainText(
  62  | 					`${zh ? "当前模型：" : "Current model: "}${model}`,
  63  | 				);
  64  | 				await expect(importer.locator(".notice")).toHaveCount(0);
  65  | 				const choose = importer.getByRole("button", {
  66  | 					name: zh ? "选择文件" : "Choose file",
  67  | 					exact: true,
  68  | 				});
  69  | 				await expect(importer.locator("#ai-import-file")).toBeHidden();
  70  | 				const fileChooser = page.waitForEvent("filechooser");
  71  | 				await choose.focus();
  72  | 				await choose.press("Enter");
  73  | 				const fileName = `${"account-import-".repeat(10)}.txt`;
  74  | 				await (await fileChooser).setFiles({
  75  | 					name: fileName,
  76  | 					mimeType: "text/plain",
  77  | 					buffer: Buffer.from("Portal: https://example.test/"),
  78  | 				});
  79  | 				await expect(importer).toContainText(fileName);
  80  | 				await expect(importer.locator("#ai-import-text")).toBeDisabled();
  81  | 				await checkLayout(page, importer, width);
  82  | 				const fileGap = await importer.evaluate((panel) => {
  83  | 					const file = panel.querySelector(".file-picker");
  84  | 					const action = file?.nextElementSibling;
  85  | 					if (!file || !action) throw Error("Missing file picker or action");
  86  | 					return (
  87  | 						action.getBoundingClientRect().top -
  88  | 						file.getBoundingClientRect().bottom
  89  | 					);
  90  | 				});
> 91  | 				expect(fileGap).toBeGreaterThanOrEqual(16);
      |                     ^ Error: expect(received).toBeGreaterThanOrEqual(expected)
  92  | 				await importer
  93  | 					.getByRole("button", {
  94  | 						name: zh ? "移除文件" : "Remove file",
  95  | 						exact: true,
  96  | 					})
  97  | 					.click();
  98  | 				await expect(importer.locator("#ai-import-file")).toHaveValue("");
  99  | 				await expect(importer.locator("#ai-import-text")).toBeEnabled();
  100 | 				const generateGap = await importer.evaluate((panel) => {
  101 | 					const file = panel.querySelector(".file-picker");
  102 | 					const action = file?.nextElementSibling;
  103 | 					if (!file || !action) throw Error("Missing file picker or action");
  104 | 					return (
  105 | 						action.getBoundingClientRect().top -
  106 | 						file.getBoundingClientRect().bottom
  107 | 					);
  108 | 				});
  109 | 				expect(generateGap).toBeGreaterThanOrEqual(16);
  110 | 				await importer
  111 | 					.locator("#ai-import-text")
  112 | 					.fill(
  113 | 						"Test account: https://example.test/ (GitHub):数据库密码fictional-secret",
  114 | 					);
  115 | 				await importer
  116 | 					.getByRole("button", { name: copy.generate, exact: true })
  117 | 					.click();
  118 | 				await expect(importer).toContainText(
  119 | 					zh
  120 | 						? "请先移除文字中的密码"
  121 | 						: "Remove passwords, API keys or private keys",
  122 | 				);
  123 | 				expect(mock.requests).toHaveLength(0);
  124 | 				await expect(rows).toHaveCount(0);
  125 | 				const emailSource = "Portal: https://example.test/dashboard (gmail)",
  126 | 					githubSource = "Database: https://db.example.test/dashboard (GitHub)";
  127 | 				const source = `${emailSource}\n${githubSource}\ngmail=reader@example.test`;
  128 | 				const response = JSON.stringify({
  129 | 					text: "",
  130 | 					records: [
  131 | 						{
  132 | 							kind: "account",
  133 | 							name: "Portal",
  134 | 							url: "https://example.test/dashboard",
  135 | 							username: "reader@example.test",
  136 | 							description: "Gmail",
  137 | 							evidence: emailSource,
  138 | 						},
  139 | 						{
  140 | 							kind: "account",
  141 | 							name: "Database",
  142 | 							url: "https://db.example.test/dashboard",
  143 | 							username: "",
  144 | 							description: "GitHub",
  145 | 							evidence: githubSource,
  146 | 						},
  147 | 					],
  148 | 				});
  149 | 				mock.responses.push(response);
  150 | 				await importer.locator("#ai-import-text").fill(source);
  151 | 				await importer
  152 | 					.getByRole("button", { name: copy.generate, exact: true })
  153 | 					.click();
  154 | 				await expect(rows).toHaveCount(2);
  155 | 				const batches = page.locator(".intake-review-batch");
  156 | 				await expect(batches).toHaveCount(1);
  157 | 				const batch = batches.first();
  158 | 				await expect(batch.locator(".intake-review-batch-header > strong")).toHaveCount(1);
  159 | 				await expect(batch.locator(".intake-review-batch-model")).toContainText(model);
  160 | 				await expect(batch.locator(".intake-review-original pre")).toHaveCount(1);
  161 | 				await expect(rows.locator(".intake-review-original")).toHaveCount(0);
  162 | 				await batch.locator(".intake-review-original > summary").click();
  163 | 				await expect(batch.locator(".intake-review-original pre")).toHaveText(source);
  164 | 				await batch.locator(".intake-review-original > summary").click();
  165 | 				await expect(batch.locator(".intake-review-original pre")).toBeHidden();
  166 | 				const positions = await rows.evaluateAll((elements) => elements.map((element) => {
  167 | 					const rect = element.getBoundingClientRect();
  168 | 					return { x: rect.x, y: rect.y, width: rect.width, height: rect.height };
  169 | 				}));
  170 | 				if (width === 1280) {
  171 | 					expect(positions[0].y).toBe(positions[1].y);
  172 | 					expect(positions[1].x).toBeGreaterThan(positions[0].x + positions[0].width);
  173 | 					expect(positions[0].height).toBeLessThanOrEqual(500);
  174 | 				} else {
  175 | 					expect(positions[0].x).toBe(positions[1].x);
  176 | 					expect(positions[1].y).toBeGreaterThan(positions[0].y + positions[0].height);
  177 | 				}
  178 | 				const portal = rows.filter({
  179 | 					has: page.locator('input[id$="-name"][value="Portal"]'),
  180 | 				});
  181 | 				const database = rows.filter({
  182 | 					has: page.locator('input[id$="-name"][value="Database"]'),
  183 | 				});
  184 | 				await expect(portal.locator('input[id$="-username"]')).toHaveValue(
  185 | 					"reader@example.test",
  186 | 				);
  187 | 				await expect(database.locator('input[id$="-username"]')).toHaveValue(
  188 | 					"",
  189 | 				);
  190 | 				await expect(
  191 | 					database.locator('textarea[id$="-description"]'),
```