# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: password-vault-grid.spec.ts >> zh-CN 1536 dense grid preserves fields, icon actions, legacy anchors and locked secrets
- Location: tests\e2e\password-vault-grid.spec.ts:119:3

# Error details

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 1024
Received:    1041.7808837890625
```

# Test source

```ts
  80  | 	});
  81  | 	const module = { exports: {} };
  82  | 	new Function("require", "module", "exports", bundled.outputFiles[0].text)(
  83  | 		createRequire(join(process.cwd(), "package.json")),
  84  | 		module,
  85  | 		module.exports,
  86  | 	);
  87  | 	const { VaultSession: Session } = module.exports as {
  88  | 		VaultSession: new (storage: VaultPersistence) => VaultSession;
  89  | 	};
  90  | 	let stored: VaultRecord | null = null;
  91  | 	const session = new Session({
  92  | 		read: async () => stored,
  93  | 		write: async (bytes) => {
  94  | 			stored = {
  95  | 				id: "local",
  96  | 				bytes,
  97  | 				revision: crypto.randomUUID(),
  98  | 				updatedAt: new Date().toISOString(),
  99  | 			};
  100 | 			return stored;
  101 | 		},
  102 | 	});
  103 | 	await session.initialize();
  104 | 	await session.create(visualMaster);
  105 | 	for (const record of records) await session.saveEntry(record);
  106 | 	fixtureIds = records.map((record) => {
  107 | 		const entry = session
  108 | 			.getSnapshot()
  109 | 			.entries.find((entry) => entry.title === record.title);
  110 | 		if (!entry) throw Error(`Missing synthetic vault entry: ${record.title}`);
  111 | 		return entry.id;
  112 | 	});
  113 | 	fixture = Buffer.from(await session.exportKdbx());
  114 | 	session.lock();
  115 | });
  116 | 
  117 | for (const locale of ["zh-CN", "en"] as const)
  118 | 	for (const width of [1536, 390]) {
  119 | 		test(`${locale} ${width} dense grid preserves fields, icon actions, legacy anchors and locked secrets`, async ({
  120 | 			browser,
  121 | 		}, info) => {
  122 | 			const context = await browser.newContext({
  123 | 				locale,
  124 | 				viewport: { width, height: 1024 },
  125 | 			});
  126 | 			await context.addInitScript((language) => {
  127 | 				localStorage.setItem("keepany-language", language);
  128 | 				Object.defineProperty(navigator, "clipboard", {
  129 | 					configurable: true,
  130 | 					value: {
  131 | 						writeText: async (value: string) => {
  132 | 							(window as unknown as { copied: string }).copied = value;
  133 | 						},
  134 | 					},
  135 | 				});
  136 | 			}, locale);
  137 | 			const page = await context.newPage();
  138 | 			const errors: string[] = [];
  139 | 			page.on("pageerror", (error) => errors.push(error.message));
  140 | 			const t = visualCopy(locale);
  141 | 			try {
  142 | 				await page.goto("/assets/vault");
  143 | 				await prepareVaultWorkspace(page);
  144 | 				await page
  145 | 					.getByRole("button", { name: t("pwVaultImportEmpty"), exact: true })
  146 | 					.click();
  147 | 				await page.locator("#password-vault-import-file").setInputFiles({
  148 | 					name: "synthetic-grid.kdbx",
  149 | 					mimeType: "application/octet-stream",
  150 | 					buffer: fixture,
  151 | 				});
  152 | 				await page
  153 | 					.locator("#password-vault-import-password")
  154 | 					.fill(visualMaster);
  155 | 				await page
  156 | 					.getByRole("dialog")
  157 | 					.getByRole("button", { name: t("pwVaultImportNow"), exact: true })
  158 | 					.click();
  159 | 				await expect(page.getByRole("dialog")).toBeHidden();
  160 | 				const cards = page.locator(
  161 | 					".password-vault-entry-list .password-vault-entry",
  162 | 				);
  163 | 				await expect(cards).toHaveCount(6);
  164 | 				const geometry = await cards.evaluateAll((nodes) =>
  165 | 					nodes.map((node) => {
  166 | 						const box = node.getBoundingClientRect();
  167 | 						return { x: box.x, y: box.y, width: box.width, bottom: box.bottom };
  168 | 					}),
  169 | 				);
  170 | 				expect(new Set(geometry.map((box) => Math.round(box.x))).size).toBe(
  171 | 					width === 1536 ? 3 : 1,
  172 | 				);
  173 | 				if (width === 1536) {
  174 | 					// Exclude a separate navigation row only when the entry has one.
  175 |                     const navigation = page.locator(".workspace-navigation");
  176 |                     const navigationHeight = await navigation.count()
  177 |                         ? await navigation.evaluate(node => node.getBoundingClientRect().height) : 0;
  178 | 					expect(
  179 | 						Math.max(...geometry.map((box) => box.bottom)) - navigationHeight,
> 180 | 					).toBeLessThanOrEqual(1024);
      |        ^ Error: expect(received).toBeLessThanOrEqual(expected)
  181 | 					await cards.last().locator(".password-vault-entry-actions")
  182 | 						.scrollIntoViewIfNeeded();
  183 | 					await expect(cards.last().locator(".password-vault-entry-actions"))
  184 | 						.toBeInViewport();
  185 | 				}
  186 | 				for (let i = 0; i < records.length; i++) {
  187 | 					const card = cards.filter({ hasText: records[i].title });
  188 | 					for (const value of [
  189 | 						records[i].username,
  190 | 						...(records[i].usernameAliases ?? []),
  191 | 						records[i].notes,
  192 | 					])
  193 | 						await expect(
  194 | 							card
  195 | 								.locator(".password-vault-value")
  196 | 								.filter({ hasText: value })
  197 | 								.first(),
  198 | 						).toBeVisible();
  199 | 					await expect(card).not.toContainText(
  200 | 						records[i].password || "not-a-real-secret",
  201 | 					);
  202 | 				}
  203 | 				const iconMetrics = await page
  204 | 					.locator(
  205 | 						".password-vault-entry .password-vault-icon, .password-vault-toolbar .password-vault-icon",
  206 | 					)
  207 | 					.evaluateAll((nodes) =>
  208 | 						nodes.map((node) => ({
  209 | 							text: node.textContent,
  210 | 							label: node.getAttribute("aria-label"),
  211 | 							title: node.getAttribute("title"),
  212 | 							width: node.getBoundingClientRect().width,
  213 | 							height: node.getBoundingClientRect().height,
  214 | 						})),
  215 | 					);
  216 | 				for (const metric of iconMetrics) {
  217 | 					expect(metric.text).toBe("");
  218 | 					expect(metric.label).toBeTruthy();
  219 | 					expect(metric.title).toBe(metric.label);
  220 | 					expect(metric.width).toBeGreaterThanOrEqual(43.99);
  221 | 					expect(metric.height).toBeGreaterThanOrEqual(43.99);
  222 | 				}
  223 | 				await expect(page.locator(".toast")).toBeHidden({ timeout: 10000 });
  224 | 				await page.evaluate(() => window.scrollTo(0, 0));
  225 | 				await page.mouse.move(0, 0);
  226 | 				await page.screenshot({
  227 | 					path: join(root, `grid-${locale}-${width}.png`),
  228 | 				});
  229 | 				const first = cards.filter({ hasText: records[0].title });
  230 | 				const copyPassword = first.getByRole("button", {
  231 | 					name: t("pwVaultCopyPassword"),
  232 | 					exact: true,
  233 | 				});
  234 | 				await copyPassword.click();
  235 | 				expect(
  236 | 					await page.evaluate(
  237 | 						() => (window as unknown as { copied: string }).copied,
  238 | 					),
  239 | 				).toBe(records[0].password);
  240 | 				await expect(first).not.toContainText(records[0].password);
  241 | 				await first
  242 | 					.getByRole("button", {
  243 | 						name: t("pwVaultRevealPassword"),
  244 | 						exact: true,
  245 | 					})
  246 | 					.click();
  247 | 				await expect(first.locator(".password-vault-secret")).toHaveText(
  248 | 					records[0].password,
  249 | 				);
  250 | 				await expect(
  251 | 					first.getByRole("heading", { name: records[0].title, exact: true }),
  252 | 				).toBeVisible();
  253 | 				await expect(page.locator(".password-vault-detail-view")).toHaveCount(
  254 | 					0,
  255 | 				);
  256 | 				await expect(cards).toHaveCount(6);
  257 | 				await first
  258 | 					.getByRole("button", {
  259 | 						name: t("pwVaultHidePasswordValue"),
  260 | 						exact: true,
  261 | 					})
  262 | 					.click();
  263 | 				// Real UI edits: unbroken long identifiers, multiline password and notes, valid URL.
  264 | 				await first
  265 | 					.getByRole("button", { name: t("pwVaultEditEntry"), exact: true })
  266 | 					.click();
  267 | 				const longNotes =
  268 | 					"First line with spaces.\n第二行：完整备注，不能截断。\n" +
  269 | 					`${"Full content ".repeat(20)}End.`;
  270 | 				const longAlias = `very-long-identifier-${"x".repeat(65)}@example.com`;
  271 | 				const secret = "  Synthetic-long-password  \r\nSecond secret line  ";
  272 | 				await page.locator("#password-vault-entry-notes").fill(longNotes);
  273 | 				await page
  274 | 					.locator(".pw-smart-identifier-row input")
  275 | 					.first()
  276 | 					.fill(longAlias);
  277 | 				// Use the actual paste control, since single-line inputs normalize newlines.
  278 | 				await page.evaluate(
  279 | 					(value) =>
  280 | 						Object.defineProperty(navigator, "clipboard", {
```