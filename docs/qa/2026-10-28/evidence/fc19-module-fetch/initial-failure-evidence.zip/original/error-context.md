# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: account-graph-readability.spec.ts >> zh-CN 1536px multi-source identities preserve connection purposes across reload and edits
- Location: tests/e2e/account-graph-readability.spec.ts:1435:3

# Error details

```
TimeoutError: locator.click: Timeout 15000ms exceeded.
Call log:
  - waiting for locator('main.unified-accounts-page').getByRole('button', { name: '新增', exact: true })

```

# Test source

```ts
  148 | 	})),
  149 | 	{ from: "docs", to: "mail", purpose: "recoveryEmail", verified: false },
  150 | 	{ from: "code", to: "phoneA", purpose: "phone", verified: true },
  151 | 	{ from: "design", to: "phoneB", purpose: "recoveryPhone", verified: true },
  152 | 	{ from: "mail", to: "phoneA", purpose: "recoveryPhone", verified: true },
  153 | 	{ from: "phoneA", to: "code", purpose: "linkedAccount", verified: false },
  154 | 	{ from: "mail", to: "docs", purpose: "linkedAccount", verified: true },
  155 | ];
  156 | 
  157 | function account(key: AccountKey) {
  158 | 	const record = accounts.find((item) => item.key === key);
  159 | 	if (!record && /^extra-\d+$/.test(key))
  160 | 		return {
  161 | 			key,
  162 | 			name: `QA Additional Service ${key.slice(6)}`,
  163 | 			username: `graph.owner.${key}.username`,
  164 | 			category: "other" as const,
  165 | 		};
  166 | 	if (!record) throw Error(`Missing graph scenario account: ${key}`);
  167 | 	// These scenarios enter every purpose manually. Shared primary/alias auto-linking
  168 | 	// is covered by account-shared-identity.spec.ts; keep long service usernames here.
  169 | 	return record.category === "other"
  170 | 		? { ...record, username: `graph.owner.${key}.username` }
  171 | 		: record;
  172 | }
  173 | function copy(locale: string) {
  174 | 	return locale === "zh-CN"
  175 | 		? {
  176 | 				add: "新增",
  177 | 				save: "保存",
  178 | 				addConnection: "添加关联",
  179 | 				target: "关联至",
  180 | 				label: "关联用途",
  181 | 				verifiedAt: "最近核验",
  182 | 				remove: "删除关系",
  183 | 				direct: "直接关联",
  184 | 				family: "完整关系",
  185 | 				backup: "创建备份",
  186 | 				download: "保存备份文件",
  187 | 				duplicate: "这条同方向、同用途的关系已存在。",
  188 | 				selection: "关联详情",
  189 | 				close: "关闭",
  190 | 				fit: "适应画布",
  191 | 				center: "回到当前",
  192 | 				expand: "全屏查看",
  193 | 				verified: "已核实",
  194 | 				mixed: "含待核实关系",
  195 | 				pending: "待核实",
  196 | 				purposes: {
  197 | 					email: "登录邮箱",
  198 | 					recoveryEmail: "找回邮箱",
  199 | 					phone: "登录手机号",
  200 | 					recoveryPhone: "找回手机号",
  201 | 					linkedAccount: "关联账号",
  202 | 				},
  203 | 			}
  204 | 		: {
  205 | 				add: "Add",
  206 | 				save: "Save",
  207 | 				addConnection: "Add connection",
  208 | 				target: "Connect to",
  209 | 				label: "Connection label",
  210 | 				verifiedAt: "Last verified",
  211 | 				remove: "Delete connection",
  212 | 				direct: "Direct",
  213 | 				family: "All connections",
  214 | 				backup: "Create backup",
  215 | 				download: "Save backup file",
  216 | 				duplicate: "A connection with this direction and label already exists.",
  217 | 				selection: "Connection details",
  218 | 				close: "Close",
  219 | 				fit: "Fit all",
  220 | 				center: "Back to current",
  221 | 				expand: "Expand graph",
  222 | 				verified: "Verified",
  223 | 				mixed: "Includes connections to verify",
  224 | 				pending: "To verify",
  225 | 				purposes: {
  226 | 					email: "Login email",
  227 | 					recoveryEmail: "Recovery email",
  228 | 					phone: "Login phone",
  229 | 					recoveryPhone: "Recovery phone",
  230 | 					linkedAccount: "Linked account",
  231 | 				},
  232 | 			};
  233 | }
  234 | type Copy = ReturnType<typeof copy>;
  235 | 
  236 | async function createScenarioAccount(page: Page, key: AccountKey, text: Copy) {
  237 | 	const record = account(key);
  238 | 	const back = page.locator('.topbar-back-link[href="/assets/account"]');
  239 | 	if (await back.count()) await back.click();
  240 | 	else if (new URL(page.url()).pathname !== "/assets/account") {
  241 | 		// Retain the first cold startup and entries from other sections such as Intake.
  242 | 		await page.goto("/assets/account");
  243 | 	}
  244 | 	const workspace = page.locator("main.unified-accounts-page");
  245 | 	await expect(workspace).toBeVisible();
  246 | 	await workspace
  247 | 		.getByRole("button", { name: text.add, exact: true })
> 248 | 		.click();
      |    ^ TimeoutError: locator.click: Timeout 15000ms exceeded.
  249 | 	const editor = page.getByRole("dialog");
  250 | 	await editor.locator("#name").fill(record.name);
  251 | 	await selectChoice(editor.locator("#category"), record.category);
  252 | 	await editor.locator("#username").fill(record.username);
  253 | 	await editor.getByRole("button", { name: text.save, exact: true }).click();
  254 | 	await expect(editor).toBeHidden();
  255 | 	const card = page
  256 | 		.locator(".asset-account-card")
  257 | 		.filter({ has: page.getByText(record.name, { exact: true }) });
  258 | 	await expect(card).toBeVisible();
  259 | 	const href = await card.getAttribute("href");
  260 | 	if (!href)
  261 | 		throw Error(`Scenario account has no details link: ${record.name}`);
  262 | 	return href;
  263 | }
  264 | function detailsHref(hrefs: Map<AccountKey, string>, key: AccountKey) {
  265 | 	const href = hrefs.get(key);
  266 | 	if (!href) throw Error(`Missing scenario details URL: ${key}`);
  267 | 	return href;
  268 | }
  269 | function accountId(hrefs: Map<AccountKey, string>, key: AccountKey) {
  270 | 	const id = new URL(
  271 | 		detailsHref(hrefs, key),
  272 | 		"http://scenario.invalid",
  273 | 	).pathname
  274 | 		.split("/")
  275 | 		.filter(Boolean)
  276 | 		.at(-1);
  277 | 	if (!id) throw Error(`Missing scenario account ID: ${key}`);
  278 | 	return id;
  279 | }
  280 | function connectionRow(connection: Connection, text: Copy) {
  281 | 	const endpoints = [
  282 | 		account(connection.from).name,
  283 | 		account(connection.to).name,
  284 | 	];
  285 | 	return {
  286 | 		endpoints,
  287 | 		path: endpoints.join(" → "),
  288 | 		purpose: text.purposes[connection.purpose],
  289 | 	};
  290 | }
  291 | async function addScenarioConnection(
  292 | 	page: Page,
  293 | 	hrefs: Map<AccountKey, string>,
  294 | 	connection: Connection,
  295 | 	text: Copy,
  296 | ) {
  297 | 	await page.goto(detailsHref(hrefs, connection.from));
  298 | 	await page
  299 | 		.getByRole("button", { name: text.addConnection, exact: true })
  300 | 		.click();
  301 | 	const editor = page.getByRole("dialog");
  302 | 	await selectChoice(editor.getByLabel(text.target, { exact: true }), {
  303 | 		label: account(connection.to).name,
  304 | 	});
  305 | 	await editor
  306 | 		.getByLabel(text.label, { exact: true })
  307 | 		.fill(text.purposes[connection.purpose]);
  308 | 	if (connection.verified)
  309 | 		await editor
  310 | 			.getByLabel(text.verifiedAt, { exact: true })
  311 | 			.fill("2026-10-22");
  312 | 	await editor.getByRole("button", { name: text.save, exact: true }).click();
  313 | 	await expect(editor).toBeHidden();
  314 | 	const expected = connectionRow(connection, text);
  315 | 	const row = page
  316 | 		.locator(".relation-list .relation-row")
  317 | 		.filter({
  318 | 			has: page
  319 | 				.locator(".relation-endpoints")
  320 | 				.filter({ hasText: expected.path }),
  321 | 		})
  322 | 		.filter({
  323 | 			has: page
  324 | 				.locator(".relation-purpose")
  325 | 				.filter({ hasText: expected.purpose }),
  326 | 		});
  327 | 	await expect(row).toHaveCount(1);
  328 | 	await expect(row.locator(".relation-endpoints")).toHaveText(expected.path);
  329 | 	await expect(row.locator(".relation-info strong")).toHaveText(
  330 | 		expected.endpoints,
  331 | 	);
  332 | 	await expect(row.locator(".relation-purpose")).toHaveText(expected.purpose);
  333 | }
  334 | 
  335 | async function fullFamily(page: Page, expected: Connection[], text: Copy) {
  336 | 	const details = page.locator("details.account-relation-details");
  337 | 	await expect(details).toHaveCount(1);
  338 | 	const detailsOpen = await details.evaluate(
  339 | 		(element) => (element as HTMLDetailsElement).open,
  340 | 	);
  341 | 	await page.getByRole("button", { name: text.family, exact: true }).click();
  342 | 	await expect(details).toHaveJSProperty("open", detailsOpen);
  343 | 	const pairCount = new Set(
  344 | 		expected.map((connection) => `${connection.from}:${connection.to}`),
  345 | 	).size;
  346 | 	const nodeCount = new Set(expected.flatMap((edge) => [edge.from, edge.to]))
  347 | 		.size;
  348 | 	await waitForAccountGraphLayout(page, { nodes: nodeCount, edges: pairCount });
```