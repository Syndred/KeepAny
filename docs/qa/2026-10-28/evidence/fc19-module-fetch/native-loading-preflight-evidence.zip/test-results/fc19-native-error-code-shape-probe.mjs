import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync, writeFileSync, copyFileSync } from 'node:fs';
import { resolve, join } from 'node:path';
const root=resolve(process.argv[2]);
assert(!existsSync(root));mkdirSync(root);
const processor=resolve('tests/diagnostics/summarize-browser-loading-trace.mjs');
copyFileSync(processor,join(root,'summarizer.executed.mjs'));
const fixture=join(root,'shape-code.json');
writeFileSync(fixture,JSON.stringify({traceEvents:[
  {cat:'ServiceWorker',name:'ServiceWorkerSubresourceLoader::StartRequest',ph:'X',pid:1,tid:1,ts:1,args:{url:'http://127.0.0.1:4236/assets/control-123.js'}},
  ...['net::OK','net::ERR_ABORTED','net::ERR_FAILED','net::ERR_SYNTHETIC_PRIVATE_MARKER'].map((error_code,index)=>({cat:'ServiceWorker',name:'ServiceWorkerSubresourceLoader::CommitCompleted',ph:'X',pid:1,tid:1,ts:index+2,args:{error_code,reason:'Body reading completed'}}))
]}));
const stdout=execFileSync(process.execPath,[processor,fixture],{encoding:'utf8'});
const output=JSON.parse(readFileSync(join(root,'shape-code-public-summary-v2.json'),'utf8'));
assert.equal(output.completions[3].errorCode,'[unavailable-code]','namespace-shaped unknown error codes must be omitted and remain unknown');
assert.deepEqual(output.completions.slice(0,3).map(row=>row.errorCode),['net::OK','net::ERR_ABORTED','net::ERR_FAILED']);
assert.equal(JSON.parse(stdout).failures,2);
assert.equal(JSON.parse(stdout).unavailableCodes,1);
const result={classification:'controlled synthetic JSON code-classification boundary, not browser acceptance',processorSha256:createHash('sha256').update(readFileSync(processor)).digest('hex'),shapedUnknownOmitted:true,knownCodesPreserved:true,unavailableSeparatedFromKnownFailure:true};
writeFileSync(join(root,'receipt.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
