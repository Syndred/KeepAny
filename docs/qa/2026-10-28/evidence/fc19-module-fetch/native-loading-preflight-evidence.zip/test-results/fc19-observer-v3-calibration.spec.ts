import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { expect, test } from '@playwright/test';
import { unzipSync, strFromU8 } from 'fflate';
import { observeGraphNetwork } from '../tests/e2e/helpers/graph-network-diagnostics';

for (const mode of ['metadata', 'forensic'] as const) {
  for (const targetKind of ['panel', 'workbox'] as const) {
    test(`declared-block calibration ${mode} ${targetKind}`, async ({ page }, info) => {
      const archive = readFileSync(process.env.KEEPANY_PREVIEW_ARCHIVE!);
      const archiveSha256 = createHash('sha256').update(archive).digest('hex');
      expect(archiveSha256).toBe(readFileSync(`${process.env.KEEPANY_PREVIEW_ARCHIVE}.sha256`, 'utf8').trim().split(/\s+/)[0]);
      const files = unzipSync(archive);
      const manifest = Object.keys(files).find(path => path.endsWith('/RELEASE.json'))!;
      const release = JSON.parse(strFromU8(files[manifest]));
      const pattern = targetKind === 'panel' ? /assets\/PasswordVaultPanel-[^/]+\.js$/ : /assets\/workbox-window[^/]*\.js$/;
      const target = release.webFiles.find((row: { path: string }) => pattern.test(row.path));
      expect(target).toBeTruthy();
      const targetUrl = new URL(target.path, info.project.use.baseURL).href;
      const stop = await observeGraphNetwork(page, info, undefined, { mode });
      const raw = () => readFileSync(info.outputPath('account-graph-network.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
      const cdp = await page.context().newCDPSession(page);
      try {
        await page.addInitScript(() => localStorage.setItem('keepany-language', 'zh-CN'));
        await page.goto('/');
        await expect(page.getByRole('heading', { name: '概览', level: 1, exact: true })).toBeVisible();
        await page.waitForFunction(() => navigator.serviceWorker.controller !== null);
        await expect.poll(() => raw().some(row => row.stage === 'service-worker-target')).toBe(true);
        expect(raw().filter(row => row.stage === 'service-worker-attach-after-failure')).toEqual([]);
        await cdp.send('Network.enable');
        await cdp.send('Network.setBlockedURLs', { urls: [targetUrl] });
        if (targetKind === 'panel') {
          await page.getByRole('link', { name: '账号', exact: true }).click();
          await expect(page.getByRole('heading', { name: '暂时无法打开这个页面', level: 1, exact: true })).toBeVisible();
        } else {
          // A new Document imports Workbox again; its caught registration failure
          // intentionally does not imply a route error or normal PWA registration.
          await page.goto('/');
          await expect(page.getByRole('heading', { name: '概览', level: 1, exact: true })).toBeVisible();
          await expect(page.locator('.route-load-error')).toHaveCount(0);
        }
        await expect.poll(() => raw().some(row => row.stage === 'failed' && row.url === targetUrl)).toBe(true);
        const firstFailure = raw().find(row => row.stage === 'failed' && row.url === targetUrl);
        expect(firstFailure.blockedReason).toBe('inspector');
        if (mode === 'forensic') {
          await expect.poll(() => raw().some(row => row.stage === 'failure-public-cache-observation' && row.failedUrl === targetUrl)).toBe(true);
          await expect.poll(() => raw().some(row => row.stage === 'service-worker-runtime-enabled')).toBe(true);
          const observation = raw().find(row => row.stage === 'failure-public-cache-observation' && row.failedUrl === targetUrl);
          expect(observation.queriedUrls[0]).toBe(targetUrl);
          expect(observation.queriedUrls.length).toBeLessThanOrEqual(6);
          expect(observation.cache.rows.some((row: { url: string; sha256: string; bytes: number }) => row.url === targetUrl && row.sha256 === target.sha256 && row.bytes > 0)).toBe(true);
          expect(raw().filter(row => row.stage === 'service-worker-attach-after-failure').every(row => row.nodeMonotonicMs > firstFailure.nodeMonotonicMs)).toBe(true);
        }
        await page.screenshot({ path: info.outputPath('declared-block.png') });
        await page.getByRole('link', { name: '待办', exact: true }).click();
        await expect(page.getByRole('heading', { name: '待办', level: 1, exact: true })).toBeVisible();
        if (mode === 'metadata') {
          expect(raw().filter(row => /^(service-worker-attach-after-failure|service-worker-runtime-enabled|failure-public-cache-observation)$/.test(row.stage))).toEqual([]);
        }
        expect(raw().every(row => row.observerMode === mode)).toBe(true);
        writeFileSync(info.outputPath('calibration-receipt.json'), JSON.stringify({
          classification: 'declared inspector-block collector calibration; not product root-cause reproduction or normal acceptance',
          archiveSha256, sourceCommit: release.sourceCommit, sourceDirty: release.sourceDirty,
          observerSourceSha256: createHash('sha256').update(readFileSync('tests/e2e/helpers/graph-network-diagnostics.ts')).digest('hex'),
          mode, targetKind, targetPath: target.path, firstFailure,
          subsequentNormalTasksNavigation: true,
          allRowsModeMatched: true,
        }, null, 2) + '\n');
      } finally {
        await cdp.send('Network.setBlockedURLs', { urls: [] });
        await cdp.detach();
        const firstStop = stop();
        expect(stop()).toBe(firstStop);
        await firstStop;
        expect(raw().filter(row => row.stage === 'collector-stop')).toHaveLength(1);
        expect(raw().find(row => row.stage === 'collector-stop').cleanupUnavailable).toBe(0);
      }
    });
  }
}
