import { defineConfig } from '@playwright/test';
import { mkdirSync } from 'node:fs';
import { resolve } from 'node:path';
const outputRoot = resolve('test-results/fc19-native-trace-calibration');
mkdirSync(outputRoot, { recursive: true });
export default defineConfig({
  testDir: '.', testMatch: 'fc19-observer-v3-calibration.spec.ts', testIgnore: ['**/frozen-inputs/**'],
  outputDir: resolve(outputRoot, 'run'), workers: 1, retries: 0, timeout: 60000,
  use: { baseURL: 'http://127.0.0.1:4236', locale: 'zh-CN', viewport: { width: 1536, height: 1024 }, serviceWorkers: 'allow', actionTimeout: 15000, trace: 'on',
    launchOptions: { args: ['--enable-tracing=ServiceWorker,loading', `--enable-tracing-output=${resolve(outputRoot, 'chromium-loading-trace.json')}`, '--enable-tracing-format=json', '--trace-startup-record-mode=record-continuously'] },
  },
  webServer: { cwd: process.cwd(), command: 'node scripts/serve-preview-for-tests.mjs', url: 'http://127.0.0.1:4236', reuseExistingServer: false, timeout: 30000 },
});
