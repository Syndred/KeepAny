import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { existsSync, mkdirSync, writeFileSync, readFileSync, copyFileSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { createHash } from 'node:crypto';
const root=resolve(process.argv[2]);assert(!existsSync(root));mkdirSync(root);
const processor=resolve('tests/diagnostics/summarize-browser-loading-trace.mjs');
copyFileSync(processor,join(root,'summarizer.executed.mjs'));
const bad=join(root,'broken.json');const good=join(root,'good.json');
const marker='SyntheticBrokenJsonPrivateMarker';
writeFileSync(bad,marker);
writeFileSync(good,JSON.stringify({traceEvents:[
 {cat:'ServiceWorker',name:'ServiceWorkerSubresourceLoader::StartRequest',ph:'X',ts:1,pid:1,tid:1,args:{url:'http://127.0.0.1:4236/assets/control-123.js'}},
 {cat:'ServiceWorker',name:'ServiceWorkerSubresourceLoader::CommitCompleted',ph:'X',ts:2,pid:1,tid:1,args:{error_code:'net::OK',reason:'Body reading completed'}}
]}));
const result=spawnSync(process.execPath,[processor,bad,good],{encoding:'utf8'});
writeFileSync(join(root,'child.stdout.log'),result.stdout);
writeFileSync(join(root,'child.stderr.log'),result.stderr);
assert.notEqual(result.status,0,'partial input failures must remain nonzero');
assert(existsSync(join(root,'good-public-summary-v2.json')),'valid later input must still be summarized');
assert(!result.stderr.includes(marker),'parse-error reporting must not echo input body');
assert.equal(JSON.parse(result.stderr.trim()).errorName,'SyntaxError');
assert.equal(JSON.parse(readFileSync(join(root,'good-public-summary-v2.json'),'utf8')).completions[0].errorCode,'net::OK');
const receipt={classification:'controlled corrupted+valid JSON multi-input isolation, not browser acceptance',processorSha256:createHash('sha256').update(readFileSync(processor)).digest('hex'),validLaterInputProcessed:true,partialFailureExitPreserved:true,corruptBodyNotEchoed:true};
writeFileSync(join(root,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt));
