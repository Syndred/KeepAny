import { createHash } from "node:crypto";
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { basename, dirname, join, relative } from "node:path";

// Isolated-fiction diagnostics only. Never copy arbitrary trace args or URLs.
const files = process.argv.slice(2);
if (!files.length)
	throw Error("Provide exported Chromium loading trace paths.");
// Fixed literals from the two observed Chromium revisions, not arbitrary text.
const knownReasons = new Set([
	"Fetch event dispatch did not complete",
	"Disconnected before completed",
	"Zero response status",
	"Failed to read blob body",
	"Can't create empty data pipe",
	"No body exists",
	"Too many redirects",
	"Invalid redirect",
	"Body reading completed",
	"Invalid response from static router",
	"SRI message signature mismatch",
]);
const finite = (value) =>
	typeof value === "number" && Number.isFinite(value) ? value : null;
const flowId = (value) =>
	typeof value === "string" && /^(?:0x[0-9a-f]+|[0-9]+)$/i.test(value)
		? value
		: finite(value);
for (const file of files) {
	const bytes = readFileSync(file);
	const data = JSON.parse(bytes.toString("utf8"));
	if (!Array.isArray(data.traceEvents)) throw Error("No traceEvents array.");
	const events = data.traceEvents.filter(
		(event) =>
			typeof event.cat === "string" &&
			event.cat.split(",").includes("ServiceWorker"),
	);
	const starts = events.filter(
		(event) => event.name === "ServiceWorkerSubresourceLoader::StartRequest",
	);
	const completions = events.filter(
		(event) => event.name === "ServiceWorkerSubresourceLoader::CommitCompleted",
	);
	if (!starts.length || !completions.length)
		throw Error(
			"Actual ServiceWorker request-start/completion events are missing.",
		);
	const metadata = (event) => ({
		name: event.name,
		timestampUs: finite(event.ts),
		phase:
			typeof event.ph === "string" && /^[A-Za-z()]$/.test(event.ph)
				? event.ph
				: null,
		processId: finite(event.pid),
		threadId: finite(event.tid),
		flowId: flowId(event.id),
		flowId2: {
			global: flowId(event.id2?.global),
			local: flowId(event.id2?.local),
		},
		flowBindId: flowId(event.bind_id),
	});
	const publicStarts = starts.flatMap((event) => {
		try {
			const url = new URL(event.args?.url);
			if (
				!["127.0.0.1", "localhost", "[::1]"].includes(url.hostname) ||
				!url.pathname.startsWith("/assets/") ||
				!/\.(js|css)$/.test(url.pathname)
			)
				return [];
			return [{ ...metadata(event), publicPath: url.pathname }];
		} catch {
			return [];
		}
	});
	const publicCompletions = completions.map((event) => ({
		...metadata(event),
		errorCode:
			typeof event.args?.error_code === "string" &&
			/^net::[A-Z0-9_]+$/.test(event.args.error_code)
				? event.args.error_code
				: "[unavailable-code]",
		// Only fixed internal Chromium reason tokens that contain no path/content.
		reason: knownReasons.has(event.args?.reason)
			? event.args.reason
			: "[omitted-nonstatic-reason]",
	}));
	const result = {
		schema: "keepany.chromium-service-worker-public-trace.v1",
		classification:
			"Dedicated diagnostic capture; event presence is not cancellation causality or product acceptance.",
		sourceFile: relative(process.cwd(), file).split("\\").join("/"),
		bytes: bytes.byteLength,
		sha256: createHash("sha256").update(bytes).digest("hex"),
		eventCount: data.traceEvents.length,
		serviceWorkerEventCount: events.length,
		observedStartCount: starts.length,
		observedCompletionCount: completions.length,
		publicStaticStarts: publicStarts,
		completions: publicCompletions,
		limitations: [
			"Raw trace is retained in isolated local/CI artifact only; no headers/body/arbitrary args/full commands exported.",
			"Trace ring buffer may wrap. Observed event spans do not prove complete capture; missing mapping remains unknown.",
			"Map native flow/process/time to public request start and original CDP failure before attributing any reason.",
			"Later normal browser shutdown errors must not be attributed to an earlier request without that mapping.",
		],
	};
	const output = join(
		dirname(file),
		`${basename(file, ".json")}-public-summary.json`,
	);
	if (existsSync(output))
		throw Error("Preserve the existing summary; use a new evidence directory.");
	writeFileSync(output, `${JSON.stringify(result, null, 2)}\n`);
	console.log(
		JSON.stringify({
			file: result.sourceFile,
			output: relative(process.cwd(), output),
			sha256: result.sha256,
			eventCount: result.eventCount,
			serviceWorkerEventCount: events.length,
			starts: starts.length,
			completions: completions.length,
			publicStaticStarts: publicStarts.length,
			failures: publicCompletions.filter((event) =>
				event.errorCode.startsWith("net::ERR_"),
			).length,
			unavailableCodes: publicCompletions.filter(
				(event) => event.errorCode === "[unavailable-code]",
			).length,
			causality: "unresolved; mapping required",
		}),
	);
}
