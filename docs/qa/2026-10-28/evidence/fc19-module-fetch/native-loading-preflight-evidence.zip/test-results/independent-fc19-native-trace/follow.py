exec(open('test-results/independent-fc19-native-trace/audit.py',encoding='utf-8-sig').read().split('chain=[]')[0])
for lo,hi in [(48865114105,48865114109),(48865114450,48865114950)]:
 print('WINDOW',lo,hi)
 print(json.dumps([safe(e) for e in es if e.get('pid')==15992 and e.get('tid')==18612 and lo<=e.get('ts',0)<=hi and 'ServiceWorkerSubresourceLoader' in e.get('name','')],indent=2))
m=json.loads((out/'archive-manifest-copy.json').read_text(encoding='utf-8'));print('ITEM',json.dumps(m['items'][0]))
