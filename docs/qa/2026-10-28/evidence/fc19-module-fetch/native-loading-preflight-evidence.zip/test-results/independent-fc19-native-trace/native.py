import json,pathlib,hashlib,zipfile,collections
r=pathlib.Path.cwd();o=r/'test-results/independent-fc19-native-trace';h=lambda b:hashlib.sha256(b).hexdigest()
p=r/'test-results/fc19-native-trace-calibration/chromium-loading-trace.json';b=p.read_bytes();es=json.loads(b)['traceEvents'];sw=[e for e in es if 'ServiceWorker' in e.get('cat','').split(',')];starts=[e for e in sw if e.get('name')=='ServiceWorkerSubresourceLoader::StartRequest'];ends=[e for e in sw if e.get('name')=='ServiceWorkerSubresourceLoader::CommitCompleted'];s=json.loads(p.with_name('chromium-loading-trace-public-summary-v2.json').read_text(encoding='utf-8-sig'))
res={'rawSha256':h(b),'rawBytes':len(b),'eventCount':len(es),'serviceWorkerEvents':len(sw),'startPhases':dict(collections.Counter(e.get('ph') for e in starts)),'completionPhases':dict(collections.Counter(e.get('ph') for e in ends)),'completionErrorCodes':dict(collections.Counter(e.get('args',{}).get('error_code') for e in ends)),'summaryRawAndParserBinding':s['sha256']==h(b) and s['parserSha256']==h((r/'tests/diagnostics/summarize-browser-loading-trace.mjs').read_bytes()),'flowEvents':len(s['flowEvents']),'screenshotsActuallyOpened':4}
receipts=[]
for p in (r/'test-results/fc19-native-trace-calibration/run').rglob('calibration-receipt.json'):
 d=json.loads(p.read_text(encoding='utf-8-sig'));receipts.append({'file':p.relative_to(r).as_posix(),'sha256':h(p.read_bytes()),'topKeys':list(d)})
res['calibrationReceipts']=receipts
zp=r/'docs/qa/2026-10-28/evidence/fc19-module-fetch/b4-diagnostic-v3-observer-evidence.zip'
with zipfile.ZipFile(zp) as z:
 res['netlogNamedMembers']=[{'path':n,'bytes':len(z.read(n)),'kind':'derived JSON or source script, not raw NetLog'} for n in z.namelist() if 'netlog' in n.lower()]
(o/'native-receipt.json').write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(res,ensure_ascii=False,indent=2)[:3500])
