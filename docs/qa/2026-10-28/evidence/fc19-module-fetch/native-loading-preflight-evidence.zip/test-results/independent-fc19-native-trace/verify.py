import json,pathlib,hashlib,zipfile,subprocess,collections
r=pathlib.Path.cwd();o=r/'test-results/independent-fc19-native-trace'; h=lambda b:hashlib.sha256(b).hexdigest()
paths=['playwright.module-navigation-diagnostic.config.ts','.github/workflows/module-loading-diagnostic.yml','tests/diagnostics/summarize-browser-loading-trace.mjs','.github/workflows/verify.yml']
res={'sourceHashes':{p:h((r/p).read_bytes()) for p in paths}}
zp=r/'docs/qa/2026-10-28/evidence/fc19-module-fetch/b4-diagnostic-v3-observer-evidence.zip'
with zipfile.ZipFile(zp) as z:
 ns=z.namelist();m=json.loads(z.read('MANIFEST.json'));bad=[]
 for x in m['items']:
  b=z.read(x['path'])
  if len(b)!=x['bytes'] or h(b)!=x['sha256']:bad.append(x['path'])
 res['archive']={'sha256':h(zp.read_bytes()),'bytes':zp.stat().st_size,'members':len(ns),'manifestItems':len(m['items']),'uniqueMembers':len(ns)==len(set(ns)),'crcError':z.testzip(),'mismatches':bad,'unlisted':sorted(set(ns)-{'MANIFEST.json'}-{x['path'] for x in m['items']}),'rawNetLogNames':[n for n in ns if 'netlog' in n.lower() and not any(s in n.lower() for s in ['summary','receipt','public','analysis','timeline','checks'])]}
p=o/'synthetic-unknown-code.json';p.write_text(json.dumps({'traceEvents':[{'cat':'ServiceWorker','name':'ServiceWorkerSubresourceLoader::StartRequest','ph':'X','ts':1,'pid':1,'tid':1,'args':{'url':'http://localhost/assets/control.js'}},{'cat':'ServiceWorker','name':'ServiceWorkerSubresourceLoader::CommitCompleted','ph':'X','ts':2,'pid':1,'tid':1,'args':{'error_code':'net::ERR_SYNTHETIC_PRIVATE_MARKER','reason':'private-marker'}}]}),encoding='utf-8')
p1=subprocess.run(['node','tests/diagnostics/summarize-browser-loading-trace.mjs',str(p)],capture_output=True,text=True)
res['unknownCodeProbe']={'exitCode':p1.returncode,'stdout':p1.stdout,'stderr':p1.stderr}
(o/'audit-receipt.json').write_text(json.dumps(res,indent=2)+'\n',encoding='utf-8');print(json.dumps(res,indent=2))
