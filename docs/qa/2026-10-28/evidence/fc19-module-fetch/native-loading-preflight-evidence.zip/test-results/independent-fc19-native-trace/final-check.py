import json,pathlib,hashlib,subprocess
r=pathlib.Path.cwd();o=r/'test-results/independent-fc19-native-trace';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
processor=r/'tests/diagnostics/summarize-browser-loading-trace.mjs'; expected='52ca699e79c47f5b99540fac9aedcfbcb2f0954e9f60e4a76b50e3ba0f45cf57';assert h(processor)==expected
fixture=json.loads((o/'final-multi/good.json').read_text())
receipt={'processorSha256':h(processor),'cases':[]}
for mode in ['missing-first','invalid-middle','existing-first']:
 d=o/mode;d.mkdir();a=d/'a.json';b=d/'b.json';c=d/'c.json'
 for p in [a,b,c]:p.write_text(json.dumps(fixture),encoding='utf-8')
 if mode=='missing-first':a.unlink()
 if mode=='invalid-middle':b.write_text('PRIVATE_PARSE_MARKER',encoding='utf-8')
 orig=None
 if mode=='existing-first':
  z=subprocess.run(['node',str(processor),str(a)],capture_output=True,text=True);assert z.returncode==0
  ap=a.with_name('a-public-summary-v2.json');orig=h(ap)
 z=subprocess.run(['node',str(processor),str(a),str(b),str(c)],capture_output=True,text=True)
 (d/'stdout.log').write_text(z.stdout,encoding='utf-8');(d/'stderr.log').write_text(z.stderr,encoding='utf-8')
 assert z.returncode==1 and c.with_name('c-public-summary-v2.json').exists() and 'PRIVATE_PARSE_MARKER' not in z.stderr
 if orig:assert h(ap)==orig
 receipt['cases'].append({'case':mode,'exitCode':z.returncode,'lastValidProcessed':True,'originalPreserved':True if orig else 'N/A','parseBodyOmitted':True})
p=r/'test-results/fc19-native-trace-calibration/chromium-loading-trace-public-summary-v2.json';s=json.loads(p.read_text(encoding='utf-8-sig'));assert s['parserSha256']==expected
receipt['finalNativeSummary']={'parserSha256':s['parserSha256'],'sha256':s['sha256'],'completionCount':len(s['completions']),'errorCodes':sorted(set(e['errorCode'] for e in s['completions'])),'flows':len(s['flowEvents'])}
(o/'final-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8');print(json.dumps(receipt,indent=2))
