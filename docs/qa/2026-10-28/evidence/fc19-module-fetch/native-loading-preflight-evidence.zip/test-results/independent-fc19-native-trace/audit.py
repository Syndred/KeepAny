import json,pathlib,hashlib,zipfile,collections
r=pathlib.Path.cwd(); out=r/'test-results/independent-fc19-native-trace'
p=r/'test-results/fc19-native-trace-calibration/chromium-loading-trace.json'; es=json.loads(p.read_text(encoding='utf-8-sig'))['traceEvents']
def safe(e):
 return {k:e[k] for k in ['name','ph','pid','tid','ts','dur','id'] if k in e}
chain=[]
for id in [2422,2443]:
 fs=[e for e in es if str(e.get('id'))==str(id) and e.get('ph') in ['s','t','f']]
 rec={'flowId':id,'events':[safe(e) for e in fs]}
 ends=[e for e in fs if e.get('ph')=='f']
 rec['endEnclosingScopes']=[]
 for e in ends:
  xs=[x for x in es if x.get('ph')=='X' and x.get('pid')==e.get('pid') and x.get('tid')==e.get('tid') and x.get('ts',0)<=e['ts']<x.get('ts',0)+x.get('dur',0) and 'ServiceWorker' in x.get('name','')]
  rec['endEnclosingScopes'].append([safe(x) for x in xs])
 chain.append(rec)
print(json.dumps(chain,indent=2))
(out/'flow-chain-partial.json').write_text(json.dumps(chain,indent=2)+'\n',encoding='utf-8')
zp=r/'docs/qa/2026-10-28/evidence/fc19-module-fetch/b4-diagnostic-v3-observer-evidence.zip'
with zipfile.ZipFile(zp) as z:
 names=z.namelist(); mnames=[n for n in names if n.lower().endswith('manifest.json')]; print('ZIP',len(names),'CRC',z.testzip(),'manifest',mnames)
 for n in mnames:
  m=json.loads(z.read(n)); print('MANIFEST',type(m).__name__, list(m)[:6] if isinstance(m,dict) else len(m)); (out/'archive-manifest-copy.json').write_text(json.dumps(m,ensure_ascii=False,indent=2),encoding='utf-8')
