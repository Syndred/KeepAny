import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync, spawnSync } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve, join } from 'node:path';
const root = resolve('test-results/independent-fc19-native-trace/final-privacy');
assert(!existsSync(root));
mkdirSync(root);
const marker = 'SyntheticSensitiveMarkerMustNeverBePublished';
const file = join(root, 'synthetic-native.json');
const input = { traceEvents: [
  { cat:'ServiceWorker', name:'ServiceWorkerSubresourceLoader::StartRequest', ph:'X',ts:100,pid:4,tid:5,dur:3,args:{url:`http://${marker}:pw@127.0.0.1:4236/assets/control-123.js?token=${marker}`,headers:marker,body:marker} },
  { cat:'ServiceWorker', name:'ServiceWorkerSubresourceLoader::StartRequest', ph:'s',ts:100,pid:4,tid:5,id:42,args:{secret:marker} },
  { cat:'ServiceWorker', name:`ServiceWorkerSubresourceLoader::${marker}`,ph:'s',ts:101,pid:4,tid:5,id:50,args:{} },
  { cat:'ServiceWorker', name:'ServiceWorkerSubresourceLoader::CommitCompleted', ph:'X',ts:110,pid:4,tid:5,id:{secret:marker},id2:{global:marker,local:marker},bind_id:marker,args:{error_code:marker,reason:marker,headers:marker} },
  { cat:'ServiceWorker', name:'ServiceWorkerSubresourceLoader::CommitCompleted', ph:'X',ts:111,pid:4,tid:5,args:{error_code:'net::ERR_ABORTED',reason:'Body reading completed'} },
] };
writeFileSync(file, JSON.stringify(input));
const processor = resolve('tests/diagnostics/summarize-browser-loading-trace.mjs');
const stdout = execFileSync(process.execPath, [processor,file],{encoding:'utf8'});
const output = join(root,'synthetic-native-public-summary-v2.json');
const raw = readFileSync(output,'utf8');
assert(!raw.includes(marker));
const result=JSON.parse(raw);
assert.equal(result.publicStaticStarts[0].publicPath,'/assets/control-123.js');
assert.equal(result.flowEvents.length,1);
assert.equal(result.flowEvents[0].flowId,42);
assert.equal(result.completions[0].errorCode,'[unavailable-code]');
assert.equal(result.completions[0].reason,'[omitted-nonstatic-reason]');
assert.equal(result.completions[0].flowId,null);
assert.deepEqual(result.completions[0].flowId2,{global:null,local:null});
assert.equal(result.completions[1].errorCode,'net::ERR_ABORTED');
assert.equal(result.completions[1].reason,'Body reading completed');
assert.equal(JSON.parse(stdout).failures,1);
assert.equal(JSON.parse(stdout).unavailableCodes,1);
const before = createHash('sha256').update(raw).digest('hex');
const again = spawnSync(process.execPath,[processor,file],{encoding:'utf8'});
assert.notEqual(again.status,0);
assert.equal(createHash('sha256').update(readFileSync(output)).digest('hex'),before);
const receipt={classification:'controlled synthetic JSON privacy/integrity boundary probe, not browser or product acceptance',processorSha256:createHash('sha256').update(readFileSync(processor)).digest('hex'),arbitraryArgsAndCredentialsOmitted:true,unknownFlowNameOmitted:true,unknownCodeSeparatedFromFailure:true,originalSummaryNotOverwritten:true};
writeFileSync(join(root,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify(receipt));

