import { readFileSync } from 'node:fs';
import { expect, test } from '@playwright/test';
import { unzipSync, strFromU8 } from 'fflate';
import { observeGraphNetwork } from '../tests/e2e/helpers/graph-network-diagnostics';

test('observer calibration: declared module block after normal SW activation', async ({ page }, info) => {
  const files = unzipSync(readFileSync(process.env.KEEPANY_PREVIEW_ARCHIVE!));
  const manifest = Object.keys(files).find(path => path.endsWith('/RELEASE.json'))!;
  const release = JSON.parse(strFromU8(files[manifest]));
  const panel = release.webFiles.find((row: {path: string}) => /assets\/PasswordVaultPanel-[^/]+\.js$/.test(row.path));
  expect(panel).toBeTruthy();
  const stop = await observeGraphNetwork(page, info);
  const raw = () => readFileSync(info.outputPath('account-graph-network.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
  try {
    await page.addInitScript(() => localStorage.setItem('keepany-language', 'zh-CN'));
    await page.goto('/');
    await expect(page.getByRole('heading', {name:'概览',level:1,exact:true})).toBeVisible();
    await page.waitForFunction(() => navigator.serviceWorker.controller !== null);
    await expect.poll(() => raw().some(row => row.stage === 'service-worker-target')).toBe(true);
    expect(raw().filter(row => row.stage === 'service-worker-attach-after-failure')).toEqual([]);
    const cdp = await page.context().newCDPSession(page);
    await cdp.send('Network.enable');
    await cdp.send('Network.setBlockedURLs', {urls:[new URL(panel.path, info.project.use.baseURL).href]});
    await page.getByRole('link', {name:'账号',exact:true}).click();
    await expect(page.getByRole('heading', {name:'暂时无法打开这个页面',level:1,exact:true})).toBeVisible();
    await expect.poll(() => raw().filter(row => row.stage === 'failure-public-cache-observation').length).toBeGreaterThan(0);
    await expect.poll(() => raw().filter(row => row.stage === 'service-worker-runtime-enabled').length).toBeGreaterThan(0);
    const rows = raw();
    const firstFailure = rows.find(row => row.stage === 'failed');
    expect(firstFailure.blockedReason).toBe('inspector');
    expect(rows.filter(row => row.stage === 'service-worker-attach-after-failure').every(row => row.nodeMonotonicMs > firstFailure.nodeMonotonicMs)).toBe(true);
    expect(rows.filter(row => row.stage === 'service-worker-protocol-error' || row.stage === 'worker-observation-unavailable')).toEqual([]);
    const cacheRows = rows.filter(row => row.stage === 'failure-public-cache-observation').flatMap(row => row.cache.rows ?? []);
    expect(cacheRows.some(row => row.url.endsWith(panel.path) && row.sha256 === panel.sha256 && row.bytes > 0)).toBe(true);
    await page.screenshot({path:info.outputPath('declared-module-block.png')});
    await cdp.send('Network.setBlockedURLs', {urls:[]});
    await cdp.detach();
  } finally {
    const firstStop = stop();
    expect(stop()).toBe(firstStop);
    await firstStop;
    expect(stop()).toBe(firstStop);
    expect(raw().filter(row => row.stage === 'collector-stop')).toHaveLength(1);
    expect(raw().find(row => row.stage === 'collector-stop').cleanupUnavailable).toBe(0);
  }
});
