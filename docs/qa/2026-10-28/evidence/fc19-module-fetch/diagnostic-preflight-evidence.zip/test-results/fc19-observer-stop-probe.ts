// White-box collector lifetime probe with fake protocol/page objects. Not UI acceptance.
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { createHash } from 'node:crypto';
import type { Page, TestInfo } from '@playwright/test';
import { observeGraphNetwork } from '../tests/e2e/helpers/graph-network-diagnostics';

process.env.KEEPANY_GRAPH_NETWORK_DIAGNOSTICS='1';
const directory=join(process.cwd(),'test-results/fc19-observer-stop-probe');
mkdirSync(directory,{recursive:true});
class Session extends EventEmitter {
  commands: {method:string;params:unknown}[]=[];
  detached=0;
  attach:Promise<{sessionId:string}>|undefined;
  async send(method:string,params:unknown={}) { this.commands.push({method,params}); if(method==='Target.attachToTarget'&&this.attach)return this.attach; return {}; }
  async detach() {this.detached++;}
}
const pageSession=new Session();const browserSession=new Session();
let resolveAttach!:(value:{sessionId:string})=>void;
browserSession.attach=new Promise(resolve=>{resolveAttach=resolve;});
let evaluateCalls=0;
const page={context:()=>({newCDPSession:async()=>pageSession,browser:()=>({newBrowserCDPSession:async()=>browserSession})}),evaluate:()=>{evaluateCalls++;return new Promise(()=>{});}} as unknown as Page;
const info={project:{use:{baseURL:'http://127.0.0.1:4236'}},outputPath:(name:string)=>join(directory,name)} as unknown as TestInfo;
const stop=await observeGraphNetwork(page,info);
browserSession.emit('Target.targetCreated',{targetInfo:{type:'service_worker',url:'http://127.0.0.1:4236/sw.js',targetId:'synthetic-worker'}});
assert.equal(browserSession.commands.filter(x=>x.method==='Target.attachToTarget').length,0);
const request=(id:string)=>pageSession.emit('Network.requestWillBeSent',{requestId:id,request:{url:'http://127.0.0.1:4236/assets/PasswordVaultPanel-synthetic.js'},loaderId:'synthetic-loader',frameId:'synthetic-frame',documentURL:'http://127.0.0.1:4236/accounts',type:'Script',initiator:{type:'script'},timestamp:1});
const failure=(id:string)=>pageSession.emit('Network.loadingFailed',{requestId:id,timestamp:2,errorText:'net::ERR_ABORTED',canceled:true});
request('synthetic-one');failure('synthetic-one');
assert.equal(evaluateCalls,1);
assert.equal(browserSession.commands.filter(x=>x.method==='Target.attachToTarget').length,1);
const started=performance.now();
const first=stop();const second=stop();assert.equal(first,second);
request('synthetic-late');failure('synthetic-late');
assert.equal(evaluateCalls,1,'stop must not schedule another observation');
browserSession.emit('Target.targetCreated',{targetInfo:{type:'service_worker',url:'http://127.0.0.1:4236/sw.js',targetId:'synthetic-late-worker'}});
assert.equal(browserSession.commands.filter(x=>x.method==='Target.attachToTarget').length,1,'stop must not attach new targets');
resolveAttach({sessionId:'synthetic-delayed-session'});
let timeout:ReturnType<typeof setTimeout>|undefined;
try {await Promise.race([first,new Promise<never>((_,reject)=>{timeout=setTimeout(()=>reject(Error('collector stop hung')),6500);})]);} finally {if(timeout)clearTimeout(timeout);}
assert.equal(browserSession.commands.filter(x=>x.method==='Target.sendMessageToTarget').length,0,'late attach must not enable Runtime after stopping');
assert.equal(browserSession.commands.filter(x=>x.method==='Target.detachFromTarget').length,1);
assert.equal(pageSession.detached,1);assert.equal(browserSession.detached,1);
assert.equal(stop(),first);
const rows=readFileSync(join(directory,'account-graph-network.jsonl'),'utf8').trim().split('\n').map(x=>JSON.parse(x));
assert.equal(rows.filter(x=>x.stage==='collector-stop').length,1);
assert(rows.some(x=>x.stage==='failure-observation-unavailable'&&x.name==='DiagnosticTimeout'));
const result={classification:'white-box fake protocol lifetime probe only',sourceSha256:createHash('sha256').update(readFileSync('tests/e2e/helpers/graph-network-diagnostics.ts')).digest('hex'),idempotentStop:true,hostDeadlineBounded:true,elapsedMs:performance.now()-started,noNewObservationsAfterStop:true,noNewWorkerAttachmentsAfterStop:true,lateAttachedSessionDetached:true,rootsDetachedExactlyOnce:true};
writeFileSync(join(directory,'result.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
