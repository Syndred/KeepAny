from pathlib import Path
import hashlib, json, shlex

root = Path.cwd()
base = root / 'test-results/cib4d1-module-diagnostic'
allowed = {
    '--headless', '--no-sandbox', '--enable-automation',
    '--disable-back-forward-cache', '--disable-background-networking',
    '--disable-background-timer-throttling', '--disable-backgrounding-occluded-windows',
    '--disable-renderer-backgrounding', '--disable-dev-shm-usage',
    '--disable-features', '--enable-features', '--net-log-capture-mode',
}
rows = []
for arm in ('A-bundled-trace', 'B-bundled-trace-off', 'C-chrome-trace', 'D-chrome-trace-off'):
    path = base / arm / 'netlog-default.json'
    raw = path.read_bytes()
    data = json.loads(raw)
    info = data['constants']['clientInfo']
    command_line = info.get('command_line')
    if not isinstance(command_line, str):
        rows.append({
            'arm': arm, 'sourcePath': path.relative_to(root).as_posix(),
            'sourceSha256': hashlib.sha256(raw).hexdigest(), 'sourceBytes': len(raw),
            'reportedVersion': info.get('version'), 'reportedOsType': info.get('os_type'),
            'reportedExecutableFromNetLog': None, 'whitelistedFlags': [],
            'commandLineAvailable': False,
            'interpretation': 'NetLog clientInfo has no command_line; no inferred executable/flags',
        })
        continue
    args = shlex.split(command_line)
    executable = args[0]
    # Only known hosted-runner executable roots, never other launch arguments.
    assert executable.startswith(('/opt/google/', '/usr/bin/', '/home/runner/.cache/ms-playwright/'))
    flags = [arg for arg in args[1:] if arg.split('=', 1)[0] in allowed]
    rows.append({
        'arm': arm,
        'sourcePath': path.relative_to(root).as_posix(),
        'sourceSha256': hashlib.sha256(raw).hexdigest(),
        'sourceBytes': len(raw),
        'reportedVersion': info.get('version'),
        'reportedOsType': info.get('os_type'),
        'reportedExecutableFromNetLog': executable,
        'whitelistedFlags': flags,
        'omittedOtherArguments': True,
        'captureMode': data['constants'].get('logCaptureMode'),
        'interpretation': 'separate derived NetLog launch identity; original CDP null executable/empty flags remain unchanged; not proof of cancellation cause',
    })
out = root / 'test-results/cib4d1-netlog-launch-derived.json'
assert not out.exists()
out.write_text(json.dumps(rows, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps(rows, ensure_ascii=False, indent=2))
