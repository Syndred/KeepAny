import { defineConfig } from '@playwright/test';
import { resolve } from 'node:path';
export default defineConfig({
  testDir: '.', testMatch: 'fc19-observer-v3-calibration.spec.ts', testIgnore: ['**/frozen-inputs/**'],
  outputDir: resolve('test-results/fc19-observer-v3-calibration/run'), workers: 1, retries: 0, timeout: 60000,
  use: { baseURL: 'http://127.0.0.1:4236', locale: 'zh-CN', viewport: { width: 1536, height: 1024 }, serviceWorkers: 'allow', actionTimeout: 15000, trace: 'on' },
  webServer: { cwd: process.cwd(), command: 'node scripts/serve-preview-for-tests.mjs', url: 'http://127.0.0.1:4236', reuseExistingServer: false, timeout: 30000 },
});
