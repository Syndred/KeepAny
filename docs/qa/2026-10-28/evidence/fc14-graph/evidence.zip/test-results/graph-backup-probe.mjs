import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { unzipSync } from 'fflate';
import { decryptBackup } from '../packages/local-db/src/backup-crypto.ts';

const runs = [];
let baseline;
for (const number of [1, 2, 3]) {
  const path = `test-results/retained-owner-validation/graph-repeat-${number}.ka1`;
  const bytes = await readFile(path);
  const plain = await decryptBackup(new Uint8Array(bytes), 'Synthetic graph backup probe 2026!');
  const files = unzipSync(plain);
  const records = Buffer.from(files['records.json']);
  assert.ok(records.length > 0);
  if (baseline) assert.deepEqual(records, baseline);
  else baseline = records;
  const parsed = JSON.parse(records.toString('utf8'));
  runs.push({ number, path, size: bytes.length,
    encryptedSha256: createHash('sha256').update(bytes).digest('hex'),
    recordsSha256: createHash('sha256').update(records).digest('hex'),
    recordCount: parsed.length, zipFileCount: Object.keys(files).length,
    result: 'real UI download, decrypt and ZIP validation passed; exact records equal across all three' });
}
await writeFile('test-results/correction-owner-three-backups-2312.json', JSON.stringify({
  candidate: '231218b25c2c27d71f71cd7bd4f6036ddd023700',
  actor: 'main controller using CUA normal UI; only synthetic prior library',
  scope: 'Windows IAB three consecutive real downloads, not proof of Linux CI download behavior',
  screenshot: 'test-results/correction-owner-backup-third-2312.jpg', runs,
}, null, 2) + '\n');
console.log(JSON.stringify(runs.map(({number, size, recordCount, recordsSha256})=>({number, size, recordCount, recordsSha256}))));
