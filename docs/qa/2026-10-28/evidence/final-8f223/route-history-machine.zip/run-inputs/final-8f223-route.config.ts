import { defineConfig } from '@playwright/test';
import { resolve } from 'node:path';
import original from '../playwright.route-error.config';
export default defineConfig({...original,testDir:resolve('tests/e2e'),outputDir:resolve('test-results/final-8f223-route/run'),webServer:{...original.webServer,cwd:process.cwd()}});
