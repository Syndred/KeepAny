import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { SourceTextModule } from 'node:vm';
import { unzipSync, strFromU8 } from 'fflate';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
function graph(archivePath,sourceMapping) {
 const bytes=readFileSync(archivePath);
 assert.equal(sha(bytes),readFileSync(archivePath+'.sha256','utf8').split(/\s+/)[0]);
 const files=unzipSync(bytes);const manifestName=Object.keys(files).find(n=>n.endsWith('/RELEASE.json'));
 const release=JSON.parse(strFromU8(files[manifestName]));const prefix=manifestName.slice(0,-'RELEASE.json'.length);
 const panel=release.webFiles.filter(row=>/^assets\/PasswordVaultPanel-[^/]+\.js$/.test(row.path));assert.equal(panel.length,1);
 const modules=new Map();for(const row of release.webFiles.filter(row=>row.path.endsWith('.js'))) {
  const source=files[prefix+'web/'+row.path];assert.equal(sha(source),row.sha256);
  modules.set(row.path,new SourceTextModule(strFromU8(source),{identifier:row.path}).dependencySpecifiers);
 }
 const reached=new Set();const external=new Set();
 function visit(path) {if(reached.has(path))return;reached.add(path);for(const specifier of modules.get(path)??[]){
  if(!specifier.startsWith('.')&&!specifier.startsWith('/')){external.add(specifier);continue;}
  const target=new URL(specifier,'https://synthetic.invalid/'+path).pathname.slice(1);
  assert(modules.has(target),'unresolved compiled static dependency '+target);visit(target);
 }}visit(panel[0].path);
 const families=['papaparse','file-picker','ai-settings-store'];
 if(sourceMapping){assert.equal(sourceMapping.archiveSha256,sha(bytes));assert.equal(sourceMapping.allRuntimeFilesByteEqual,true);}
 const roles=Object.fromEntries(families.map(family=>[family,sourceMapping
  ? sourceMapping.chunks.filter(row=>row.sourceRoles.some(source=>source.role===family)).map(row=>row.path)
  : release.webFiles.filter(row=>row.path.startsWith('assets/'+family)&&row.path.endsWith('.js')).map(row=>row.path)]));
 for(const [family,paths]of Object.entries(roles))assert(paths.length>0,'missing role '+family);
 return {archivePath,archiveSha256:sha(bytes),sourceCommit:release.sourceCommit,sourceDirty:release.sourceDirty,
  webCount:release.webFiles.length,sourceCount:release.sourceFiles.length,rootPanel:panel[0],staticGraph:[...reached].sort(),roles,
  requiredAdvanced:Object.entries(roles).flatMap(([family,paths])=>paths.filter(path=>reached.has(path)).map(path=>({family,path}))),external:[...external]};
}
const before=graph('dist/preview/delivery-f992b727-windows/KeepAny-0.1.0-preview.f992b727dbb0-portable.zip');
const after=graph('dist/preview/KeepAny-0.1.0-preview.8f2230147122.dirty-portable.zip',JSON.parse(readFileSync('test-results/final-8f223-source-module-map.json','utf8')));
writeFileSync('test-results/final-8f223-compiled-dependency-audit.json',JSON.stringify({classification:'actual compiled static-import graph parsed without execution by V8 SourceTextModule; not timing or cancellation-root-cause proof',before,after},null,2)+'\n');
assert.equal(new Set(before.requiredAdvanced.map(row=>row.family)).size,3);
assert.deepEqual(after.requiredAdvanced,[],'unused advanced modules remain mandatory for core accounts');
console.log(JSON.stringify({beforeRequired:before.requiredAdvanced,afterRequired:after.requiredAdvanced,beforeStaticJsCount:before.staticGraph.length,afterStaticJsCount:after.staticGraph.length,afterArchiveSha256:after.archiveSha256,actualAfterWebCount:after.webCount,actualAfterSourceCount:after.sourceCount}));
