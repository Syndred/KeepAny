from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib, json, shutil

root = Path.cwd()
dest = root / 'docs/qa/2026-10-28/evidence/final-8f223'
sha = lambda data: hashlib.sha256(data).hexdigest()
identity_path = dest / 'product-identity.json'
identity = json.loads(identity_path.read_text(encoding='utf-8'))
index_sha = identity['indexSha256']
history_source = root / 'test-results/password-history-version/evidence'
history_frozen = root / 'test-results/final-8f223-history/evidence'
assert not history_frozen.exists()
shutil.copytree(history_source, history_frozen)
history_rows = []
for path in sorted(history_frozen.glob('*/result.json')):
    row = json.loads(path.read_text(encoding='utf-8'))
    assert row['status'] == 'passed' and row['indexSha256'] == index_sha
    history_rows.append((path, row))
assert len(history_rows) == 4
preparation = {
    'classification':'Output-path preparation correction; no product assertion or budget changed',
    'actualRun':'test-results/test-results/final-8f223-history/results.json',
    'originalEvidenceDirectory':history_source.relative_to(root).as_posix(),
    'frozenEvidenceDirectory':history_frozen.relative_to(root).as_posix(),
    'facts':'The temporary config used paths relative to its directory, while the spec used its default evidence directory because KEEPANY_EVIDENCE_DIR was omitted. Four raw records all bind the actual new index and passed. They were frozen before any next history run.',
    'historicalBoundary':'Earlier b507 completion log remains historical evidence only; no claim that its unfrozen default-path raw records survived. Existing committed d2 archives are unchanged.',
}
with (history_frozen.parent / 'output-path-preparation.json').open('x', encoding='utf-8') as stream:
    json.dump(preparation, stream, ensure_ascii=False, indent=2)
inputs = ['tests/e2e/route-load-recovery.spec.ts', 'tests/e2e/password-history-version.spec.ts', 'tests/e2e/fixtures/password-smart-import-visual.ts', 'tests/e2e/helpers/vault-access.ts', 'playwright.route-error.config.ts', 'playwright.release.config.ts']
selected = []
def add(path, key):
    assert path.is_file(), path
    selected.append((path, key))
route_base = root / 'test-results/final-8f223-route/evidence'
route_rows = []
for path in sorted(route_base.rglob('*')):
    if path.is_file():
        assert path.suffix in {'.png', '.json'}, path
        add(path, 'route/evidence/' + path.relative_to(route_base).as_posix())
        if path.name == 'result.json':
            row = json.loads(path.read_text(encoding='utf-8'))
            assert row['status'] == 'passed'
            assert row['identity']['candidate'] == identity['sourceCommit']
            assert row['identity']['archiveSha256'] == identity['archiveSha256']
            assert row['identity']['indexSha256'] == index_sha
            route_rows.append((path, row))
assert len(route_rows) == 24
for path in sorted(history_frozen.rglob('*')):
    if path.is_file(): add(path, 'history/evidence/' + path.relative_to(history_frozen).as_posix())
for path in inputs: add(root / path, 'inputs/' + path)
for name in ['final-8f223-route.config.ts', 'final-8f223-history.config.ts', 'final-8f223-route-complete.log', 'final-8f223-history-complete.log']:
    add(root / 'test-results' / name, 'run-inputs/' + name)
add(history_frozen.parent / 'output-path-preparation.json', 'run-inputs/output-path-preparation.json')
archive = dest / 'route-history-machine.zip'
manifest = []
with ZipFile(archive, 'x', ZIP_DEFLATED, compresslevel=9) as zip:
    names = set()
    for path, key in sorted(selected, key=lambda row: row[1]):
        assert key not in names and '..' not in Path(key).parts
        names.add(key)
        data = path.read_bytes()
        zip.writestr(key, data)
        manifest.append({'path':key, 'source':path.relative_to(root).as_posix(), 'bytes':len(data), 'sha256':sha(data)})
    zip.writestr('MANIFEST.json', json.dumps({'schema':'keepany.frozen-evidence.v1', 'entries':manifest}, ensure_ascii=False, indent=2).encode())
with ZipFile(archive) as zip:
    assert zip.testzip() is None
    assert len(zip.namelist()) == len(set(zip.namelist())) == len(manifest) + 1
    for row in manifest:
        data = zip.read(row['path'])
        assert len(data) == row['bytes'] and sha(data) == row['sha256'], row['path']
archive_ref = archive.relative_to(root).as_posix()
def reference(path, row, base, prefix):
    return {'archive':archive_ref, 'path':prefix + path.relative_to(base).as_posix(), 'sha256':sha(path.read_bytes()), 'language':row['language'], 'width':row['width']}
recoveries = [reference(path,row,route_base,'route/evidence/') for path,row in route_rows if path.parent.name.endswith('-recovery')]
routes = [reference(path,row,route_base,'route/evidence/') for path,row in route_rows if path.parent.name.endswith('-routes')]
stable = [row for row in routes if row['width'] in [390,563]]
assert len(recoveries) == len(routes) == 12 and len(stable) == 4
record = {
    'schema':'keepany.route-history-machine.v1',
    'ids':['FC17-A','FC17-B','FC17-C','FC17-D','FC17-E','FC18-A','FC18-B','FC18-C'],
    'separateVerdicts':{'FC17-F':'Human visual/owner/independent and final normal zero-recovery cloud receipt remain separate.', 'FC18-D':'Whitebox, owner and independent review plus final cloud receipt remain separate.'},
    'scope':'Actual 8f223 original24 route and4 strict history cases. The four stableNavigation references are the mobile subset of these original24: the current frozen spec already waits for actual closed-sidebar geometry. They are not claimed as four additional executions. All raw facts and filenames are unchanged.',
    'candidate':identity['sourceCommit'], 'archiveSha256':identity['archiveSha256'], 'indexSha256':index_sha,
    'productIdentity':{'path':identity_path.relative_to(root).as_posix(), 'sha256':sha(identity_path.read_bytes())},
    'testInputs':[{'path':path, 'canonicalSha256':sha((root/path).read_text(encoding='utf-8').replace('\r\n','\n').encode())} for path in inputs],
    'archives':[{'path':archive_ref,'sha256':sha(archive.read_bytes())}],
    'recoveries':recoveries,'routes':routes,'stableNavigation':stable,
    'history':[reference(path,row,history_frozen,'history/evidence/') for path,row in history_rows],
}
with (dest / 'machine-evidence.json').open('x', encoding='utf-8') as stream:
    json.dump(record, stream, ensure_ascii=False, indent=2)
print(json.dumps({'archive':archive_ref,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'members':len(manifest)+1,'uniqueTests':28,'stableMobileSubset':4,'humanReviewInferred':False}))
