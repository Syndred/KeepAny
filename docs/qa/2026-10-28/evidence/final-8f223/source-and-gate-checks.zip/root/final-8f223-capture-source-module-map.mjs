import assert from 'node:assert/strict';
import { existsSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { resolve, join, relative } from 'node:path';
import { createHash } from 'node:crypto';
import { build } from 'vite';
import { unzipSync, strFromU8 } from 'fflate';
const root=process.cwd(); const output=resolve('test-results/final-8f223-role-analysis-web');
assert(output.startsWith(resolve('test-results')+'/')||output.startsWith(resolve('test-results')+'\\'));
assert(!existsSync(output));
const rows=[];
function roles(id) {
 const p=id.replaceAll('\\','/');const result=[];
 if(/\/node_modules\/papaparse\/(?:papaparse(?:\.min)?)\.js$/.test(p))result.push('papaparse');
 if(p.endsWith('/apps/web/src/ai-settings-store.ts'))result.push('ai-settings-store');
 if(p.endsWith('/apps/web/src/components/ui/file-picker.tsx'))result.push('file-picker');
 return result;
}
await build({root:resolve('apps/web'),build:{outDir:output,emptyOutDir:true},plugins:[{
 name:'keepany-fc20-source-role-observer',generateBundle(_options,bundle){
  for(const file of Object.values(bundle))if(file.type==='chunk') rows.push({path:file.fileName,imports:file.imports,dynamicImports:file.dynamicImports,
   sourceRoles:Object.keys(file.modules).flatMap(id=>roles(id).map(role=>({role,sourceModule:relative(root,id).replaceAll('\\','/')})))});
 }
}]});
const zip=readFileSync('dist/preview/KeepAny-0.1.0-preview.8f2230147122.dirty-portable.zip');
const files=unzipSync(zip);const releaseName=Object.keys(files).find(p=>p.endsWith('/RELEASE.json'));
const release=JSON.parse(strFromU8(files[releaseName]));const prefix=releaseName.slice(0,-'RELEASE.json'.length);
for(const file of release.webFiles)assert.equal(createHash('sha256').update(readFileSync(join(output,file.path))).digest('hex'),file.sha256,'analysis is not identical to actual candidate '+file.path);
const observed=[];function collect(directory){for(const d of readdirSync(directory,{withFileTypes:true})){const p=join(directory,d.name);if(d.isDirectory())collect(p);else observed.push(relative(output,p).replaceAll('\\','/'));}}
collect(output);assert.deepEqual(observed.sort(),release.webFiles.map(row=>row.path).sort());
const result={classification:'build-plugin source-to-chunk mapping; analysis output all124 bytes/paths verified equal to actual delivered candidate',archiveSha256:createHash('sha256').update(zip).digest('hex'),allRuntimeFilesByteEqual:true,webCount:release.webFiles.length,chunks:rows};
writeFileSync('test-results/final-8f223-source-module-map.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({allRuntimeFilesByteEqual:true,webCount:release.webFiles.length,roleChunks:rows.filter(row=>row.sourceRoles.length).map(row=>({path:row.path,sourceRoles:row.sourceRoles}))}));
