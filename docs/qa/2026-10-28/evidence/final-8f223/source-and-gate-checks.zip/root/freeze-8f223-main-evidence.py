from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib, json

root=Path.cwd()
dest=root/'docs/qa/2026-10-28/evidence/final-8f223'
sha=lambda data:hashlib.sha256(data).hexdigest()
def pack(name, selected, classification):
    output=dest/name
    names=set()
    manifest=[]
    with ZipFile(output,'x',ZIP_DEFLATED,compresslevel=9) as z:
        for path,key in sorted(selected,key=lambda row:row[1]):
            assert path.is_file(), path
            assert key not in names and '..' not in Path(key).parts and not key.startswith('/')
            names.add(key)
            data=path.read_bytes()
            z.writestr(key,data)
            manifest.append({'path':key,'source':path.relative_to(root).as_posix(),'bytes':len(data),'sha256':sha(data)})
        z.writestr('MANIFEST.json',json.dumps({'schema':'keepany.frozen-evidence.v1','classification':classification,'entries':manifest},ensure_ascii=False,indent=2).encode())
    with ZipFile(output) as z:
        assert z.testzip() is None
        assert len(z.namelist())==len(set(z.namelist()))==len(manifest)+1
        for row in manifest:
            data=z.read(row['path'])
            assert len(data)==row['bytes'] and sha(data)==row['sha256'],row['path']
    assert output.stat().st_size<95_000_000
    return {'path':output.relative_to(root).as_posix(),'bytes':output.stat().st_size,'sha256':sha(output.read_bytes()),'members':len(manifest)+1,'crcUniquePathsAndAllMemberHashes':'passed','classification':classification}
def tree(base, prefix, allowed=None):
    assert base.is_dir(), base
    return [(path,prefix+'/'+path.relative_to(base).as_posix()) for path in base.rglob('*') if path.is_file() and (allowed is None or allowed(path))]

names={'tool-state-receipt.json','advanced-module-receipt.json','vault-status-receipt.json','toast-layer-receipt.json','machine-evidence.json'}
selection=[]
for folder,prefix in [('final-8f223-vault-tools/run','initial66/run'),('final-8f223-vault-tools-strict/run','strict66/run')]:
    base=root/'test-results'/folder
    rows=tree(base,prefix,lambda path:path.suffix=='.png' or path.name in names)
    assert len([path for path,_ in rows if path.suffix=='.png'])==672
    assert len([path for path,_ in rows if path.name in names])==67
    selection+=rows
selection+=tree(root/'test-results/final-8f223-vault-tools-initial-inputs','initial66/inputs')
strict_record=json.loads((root/'test-results/final-8f223-vault-tools-strict/run/machine-evidence.json').read_text(encoding='utf-8'))
for row in strict_record['testInputs']:
    path=root/row['path']
    assert sha(path.read_text(encoding='utf-8').replace('\r\n','\n').encode())==row['canonicalSha256']
    selection.append((path,'strict66/inputs/'+row['path']))
for name in ['scripts/test-vault-tool-evidence.mjs','.github/workflows/vault-tools.yml']:
    selection.append((root/name,'strict66/additional-inputs/'+name))
for name in ['final-8f223-vault-tools-complete.log','final-8f223-vault-tools-strict-complete.log','final-8f223-vault-tools-strict-gate-probes.log']:
    selection.append((root/'test-results'/name,'logs/'+name))
probes=root/'test-results/vault-gate-probes-3mixAk'
selection+=tree(probes,'gate-probes',lambda path:path==probes/'results.json' or path.parent==probes/'logs')
vault=pack('vault-tools-machine.zip',selection,'Actual same8f223 candidate. Initial66 and strict66 are separate, each672PNG; strict version requires exact save hit and native invalid event. Machine evidence never implies human review.')

owner=pack('owner-experience.zip',tree(root/'test-results/final-8f223-owner','8f223-owner')+tree(root/'test-results/final-b507-owner','historical-b507-owner'),'Main-controller actual IAB operation. The two candidates and failed/missed capture preparations retain their original labels. The ID-order comparison correction is separate and original observation remains unchanged.')
selection=[]
red_dirs=['fc20-core-dependency-red','fc20-core-dependency-green','fc21-empty-status-red','fc21-empty-status-visual-red','fc21-empty-status-en-valid-red','fc21-empty-status-en-precondition-fixed','fc21-empty-status-green','fc21-empty-status-original-inputs','fc21-empty-status-pre-visual-inputs','fc22-toast-layer-red','fc22-toast-layer-green-pilot']
for folder in red_dirs:
    selection+=tree(root/'test-results'/folder,folder,lambda path:path.suffix in {'.png','.json','.md','.ts','.mjs','.log'} or path.name=='trace.zip')
for name in ['fc20-core-dependency-red-complete.log','fc20-core-dependency-green-complete.log','fc21-empty-status-red-complete.log','fc21-empty-status-visual-red-complete.log','fc21-empty-status-en-valid-red-complete.log','fc21-empty-status-green-complete.log','fc22-toast-layer-red-complete.log','fc22-toast-layer-green-pilot-complete.log','fc22-toast-layer-red.config.ts','fc22-toast-layer-green-pilot.config.ts']:
    selection.append((root/'test-results'/name,'logs-and-configs/'+name))
failures=pack('fc20-fc22-before-after.zip',selection,'Original bounded product reds, same-input greens and preparation errors are separate. FC22 original failed at z before height assertion; raw36 height is observation. Declared module faults differ from spontaneous ERR_ABORTED.')
selection=[]
for name in ['final-8f223-source-module-map.json','final-8f223-compiled-dependency-audit.json','final-8f223-capture-source-module-map.mjs','final-8f223-compiled-dependency-audit.mjs','final-8f223-source-module-map-complete.log','final-8f223-compiled-dependency-audit-complete.log','final-8f223-release-before.json','final-8f223-release-copy.json','sync-8f223-release.py','bind-8f223-product.py','freeze-8f223-route-history.py','freeze-8f223-main-evidence.py']:
    selection.append((root/'test-results'/name,'root/'+name))
for folder in ['final-8f223-route-binding','final-8f223-route-binding-semantic']:
    base=root/'test-results'/folder
    selection.append((root/'test-results'/(folder+'.mjs'),'gate-inputs/'+folder+'.mjs'))
    selection.append((base/'results.json','gate-results/'+folder+'.json'))
    selection.append((root/'test-results'/(folder+'-complete.log'),'gate-results/'+folder+'.log'))
selection.append((root/'scripts/verify-route-history-evidence.mjs','gate-inputs/verify-route-history-evidence.mjs'))
selection.append((root/'dist/preview/KeepAny-0.1.0-preview.8f2230147122.dirty-portable/RELEASE.json','candidate/RELEASE.json'))
binding=pack('source-and-gate-checks.zip',selection,'Current385 source/124HTTP actual candidate binding and static role graph; preserved release history; both initial hash-guard and corrected shared-reference semantic route probes. Not overall acceptance.')
checks={'schema':'keepany.8f223-local-evidence.v1','status':'not-complete','candidate':'8f2230147122ab7cb3c3bc51775cf6a4cce96387','archiveSha256':'120ba82f23966824abccb2e358facb87e37360f194bd57d7d4841e9854efdbc4','archives':[vault,owner,failures,binding],'machine':{'strictVaultTools':'66/66,672PNG,6.7m','vaultGate':'1 positive/16 negative','route':'24/24,10.4m; stable mobile4 subset included','history':'4/4,55.6s','routeGate':'2 positive/24 semantic negative','release':'124 current/2784 retained; all prior versioned bytes preserved'},'notInferred':['independent full visual review','remaining busy-state30 coverage','new AL closure','all final clean CI jobs','final clean packet and4180 actual consumption'],'boundaries':['Initial66 and strict66 input snapshots differ only as declared; neither image count nor machine pass proves a human saw every frame.','Historical b507 owner and before/after candidates keep their labels.','History default output preparation and owner JSON object-key-order comparison errors remain explicit.','Actual archive source485 predates newer test/support inputs; product385 and runtime124 equalities do not claim all support scripts equal.']}
with (dest/'root-local-evidence.json').open('x',encoding='utf-8') as f:json.dump(checks,f,ensure_ascii=False,indent=2)
print(json.dumps({'status':'not-complete','archives':checks['archives']},ensure_ascii=False))
