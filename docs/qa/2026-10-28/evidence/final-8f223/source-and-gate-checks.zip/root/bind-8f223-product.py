from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib, json, subprocess, urllib.request

root = Path.cwd()
candidate = root / 'dist/preview/KeepAny-0.1.0-preview.8f2230147122.dirty-portable'
release = json.loads((candidate / 'RELEASE.json').read_text(encoding='utf-8'))
sha = lambda b: hashlib.sha256(b).hexdigest()
canonical = lambda b: b.decode('utf-8').replace('\r\n', '\n').encode('utf-8') if b'\0' not in b else b
def canon(b):
    try:
        return canonical(b)
    except UnicodeDecodeError:
        return b
source_manifest = {r['path']: r['sha256'] for r in release['sourceFiles']}
tracked = subprocess.check_output(['git', 'ls-files', '-z', '--', 'apps', 'packages']).decode().split('\0')
product = []
for name in sorted(filter(None, tracked)):
    actual = (root / name).read_bytes()
    snapshot = (candidate / 'source' / name).read_bytes()
    assert sha(snapshot) == source_manifest[name], name
    assert sha(canon(actual)) == sha(canon(snapshot)), name
    product.append({'path': name, 'sha256': sha(snapshot), 'canonicalSha256': sha(canon(snapshot))})
assert len(product) == 385
def http(row):
    name = row['path']
    with urllib.request.urlopen('http://127.0.0.1:4239/' + name, timeout=20) as response:
        data = response.read()
        assert response.status == 200 and sha(data) == row['sha256'], name
        return {'path': name, 'status': response.status, 'sha256': sha(data), 'bytes': len(data)}
with ThreadPoolExecutor(max_workers=6) as pool:
    served = list(pool.map(http, release['webFiles']))
assert len(served) == 124
archive = root / 'dist/preview/KeepAny-0.1.0-preview.8f2230147122.dirty-portable.zip'
archive_sha = sha(archive.read_bytes())
assert archive_sha == '120ba82f23966824abccb2e358facb87e37360f194bd57d7d4841e9854efdbc4'
identity = {'sourceCommit': release['sourceCommit'], 'sourceHashPolicy': 'utf8-no-nul-crlf-to-lf-v1;binary-raw', 'productSource': product, 'httpFiles': served, 'port': 4239, 'indexSha256': next(row['sha256'] for row in served if row['path'] == 'index.html'), 'archiveSha256': archive_sha, 'sourceDirty': release['sourceDirty'], 'status': 'passed', 'scope': '385 tracked product sources match the actual packaged snapshot under the explicit canonical policy; 124 HTTP files from the candidate portable server match byte for byte. Human review and overall completion are separate.'}
destination = root / 'docs/qa/2026-10-28/evidence/final-8f223'
destination.mkdir(parents=True, exist_ok=True)
assert not (destination / 'product-identity.json').exists()
(destination / 'product-identity.json').write_text(json.dumps(identity, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'sourceCommit': release['sourceCommit'], 'productSources': len(product), 'httpFiles': len(served), 'indexSha256': identity['indexSha256']}))
