from pathlib import Path
import hashlib, json, re, shutil

root = Path.cwd()
built = root / 'apps/web/dist'
target = root / 'release/web'
release = json.loads((root / 'dist/preview/KeepAny-0.1.0-preview.8f2230147122.dirty-portable/RELEASE.json').read_text(encoding='utf-8'))
sha = lambda data: hashlib.sha256(data).hexdigest()
old = {p.relative_to(target).as_posix(): sha(p.read_bytes()) for p in target.rglob('*') if p.is_file()}
with (root / 'test-results/final-8f223-release-before.json').open('x', encoding='utf-8') as stream:
    json.dump(old, stream, indent=2)
current = {row['path']: row for row in release['webFiles']}
assert len(current) == len(release['webFiles']) == 124
assert {p.relative_to(built).as_posix() for p in built.rglob('*') if p.is_file()} == set(current)
versioned = lambda path: bool(re.fullmatch(r'assets/[\w.-]+-[\w-]+\.(?:js|css)', path) or re.fullmatch(r'workbox-[a-f\d]+\.js', path))
for path, row in current.items():
    source = built / path
    destination = target / path
    assert destination.resolve().is_relative_to(target.resolve())
    actual = sha(source.read_bytes())
    assert actual == row['sha256'], path
    if destination.exists() and versioned(path):
        assert sha(destination.read_bytes()) == actual, f'Versioned name collision: {path}'
for path in sorted(current):
    destination = target / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(built / path, destination)
for path, digest in old.items():
    assert (target / path).exists(), path
    if path not in current or versioned(path):
        assert sha((target / path).read_bytes()) == digest, path
for path, row in current.items():
    assert sha((target / path).read_bytes()) == row['sha256'], path
retained = len([path for path in old if path not in current])
receipt = {'status':'passed', 'candidate':release['sourceCommit'], 'archiveSha256':'120ba82f23966824abccb2e358facb87e37360f194bd57d7d4841e9854efdbc4', 'current':len(current), 'oldFiles':len(old), 'oldRetainedUnchanged':retained, 'allPriorVersionedFilesPreserved':True, 'scope':'Only actual 124 compiled files copied. All prior files retained; same versioned names require identical bytes. No final UI or delivery inference.'}
with (root / 'test-results/final-8f223-release-copy.json').open('x', encoding='utf-8') as stream:
    json.dump(receipt, stream, indent=2)
print(json.dumps(receipt))
