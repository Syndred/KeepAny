# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: fc21-empty-status-red.spec.ts >> zh-CN empty vault must not claim existing passwords are locked
- Location: test-results\fc21-empty-status-red.spec.ts:3:45

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator:  locator('main.unified-accounts-page').locator('.unified-account').filter({ hasText: 'Synthetic FC21 empty-vault account' }).locator('.unified-account-locked')
Expected: "尚未建立密码库。"
Received: "密码已锁定，解锁后查看。"
Timeout:  5000ms

Call log:
  - Expect "toHaveText" locator('main.unified-accounts-page').locator('.unified-account').filter({ hasText: 'Synthetic FC21 empty-vault account' }).locator('.unified-account-locked') with timeout 5000ms
  - waiting for locator('main.unified-accounts-page').locator('.unified-account').filter({ hasText: 'Synthetic FC21 empty-vault account' }).locator('.unified-account-locked')
    14 × locator resolved to <p class="unified-account-locked">密码已锁定，解锁后查看。</p>
       - unexpected value "密码已锁定，解锁后查看。"

```

```yaml
- paragraph: 密码已锁定，解锁后查看。
```

# Test source

```ts
  1  | import {expect,test} from '@playwright/test';
  2  | import {selectChoice} from '../tests/e2e/helpers/select-choice';
  3  | for(const locale of ['zh-CN','en'] as const)test(`${locale} empty vault must not claim existing passwords are locked`,async({page},info)=>{
  4  |  const zh=locale==='zh-CN';
  5  |  await page.addInitScript(language=>localStorage.setItem('keepany-language',language),locale);
  6  |  await page.goto('/accounts');const workspace=page.locator('main.unified-accounts-page');
  7  |  await workspace.getByRole('button',{name:zh?'新增':'Add',exact:true}).click();
  8  |  const editor=page.getByRole('dialog');await editor.locator('#name').fill('Synthetic FC21 empty-vault account');await selectChoice(editor.locator('#category'),'other');await editor.locator('#username').fill('fc21.empty@example.test');await editor.getByRole('button',{name:zh?'保存':'Save',exact:true}).click();await expect(editor).toBeHidden();
  9  |  const card=workspace.locator('.unified-account').filter({hasText:'Synthetic FC21 empty-vault account'});await expect(card).toBeVisible();
  10 |  await expect(workspace.locator('.password-vault-header-meta [role="status"]')).toHaveText(zh?'未建立':'Not created');
  11 |  await page.screenshot({path:info.outputPath('actual-empty-vault-account.png')});
> 12 |  await expect(card.locator('.unified-account-locked')).toHaveText(zh?'尚未建立密码库。':'No password vault has been created.');
     |                                                        ^ Error: expect(locator).toHaveText(expected) failed
  13 | });
  14 | 
```