import {defineConfig} from '@playwright/test';
import {resolve} from 'node:path';
export default defineConfig({testDir:'.',testMatch:'fc21-empty-status-red.spec.ts',outputDir:resolve('test-results/fc21-empty-status-red/run'),workers:1,retries:0,timeout:60000,use:{baseURL:'http://127.0.0.1:4238',actionTimeout:15000,trace:'on',screenshot:'only-on-failure'},webServer:{cwd:process.cwd(),command:'node scripts/serve-preview-for-tests.mjs',url:'http://127.0.0.1:4238',reuseExistingServer:false,timeout:30000}});
