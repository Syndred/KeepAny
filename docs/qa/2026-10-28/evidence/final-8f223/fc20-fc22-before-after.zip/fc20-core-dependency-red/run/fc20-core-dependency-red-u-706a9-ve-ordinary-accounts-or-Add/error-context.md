# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: fc20-core-dependency-red.spec.ts >> unused advanced CSV dependency must not remove ordinary accounts or Add
- Location: test-results\fc20-core-dependency-red.spec.ts:8:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('main.unified-accounts-page').getByRole('button', { name: '新增', exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('main.unified-accounts-page').getByRole('button', { name: '新增', exact: true }) with timeout 5000ms
  - waiting for locator('main.unified-accounts-page').getByRole('button', { name: '新增', exact: true })

```

```yaml
- complementary:
  - strong: KeepAny
  - text: 个人资产工作台
  - button "个人工作区":
    - strong: 个人工作区
  - text: 工作空间
  - navigation "导航":
    - button "概览 按住拖动排序"
    - link "概览":
      - /url: /
    - button "待办 按住拖动排序"
    - link "待办":
      - /url: /tasks
    - button "资产 按住拖动排序"
    - link "资产":
      - /url: /assets
    - button "账号 按住拖动排序"
    - link "账号":
      - /url: /accounts
    - status
  - link "回收站":
    - /url: /trash
  - text: 我的分类
  - link "自定义侧边栏":
    - /url: /collections
  - button "我 我的工作区 仅自己可见":
    - text: 我
    - strong: 我的工作区
    - text: 仅自己可见
- banner:
  - link "返回概览":
    - /url: /
  - button "搜索全部资料": 搜索全部资料 ⌘ K
  - link "待办提醒":
    - /url: /tasks
  - button "AI 助手与授权"
  - link "收录与备份":
    - /url: /intake
- main:
  - alert "暂时无法打开这个页面":
    - heading "暂时无法打开这个页面" [level=1]
    - paragraph: 请重新加载后再试，已保存的资料会保留。
    - button "重新加载"
```

# Test source

```ts
  1  | import { readFileSync, writeFileSync } from 'node:fs';
  2  | import { createHash } from 'node:crypto';
  3  | import { expect, test } from '@playwright/test';
  4  | import { strFromU8, unzipSync } from 'fflate';
  5  | import { selectChoice } from '../tests/e2e/helpers/select-choice';
  6  | import { observeGraphNetwork } from '../tests/e2e/helpers/graph-network-diagnostics';
  7  | 
  8  | test('unused advanced CSV dependency must not remove ordinary accounts or Add', async ({ page }, info) => {
  9  |   const archive=readFileSync(process.env.KEEPANY_PREVIEW_ARCHIVE!);
  10 |   const archiveSha256=createHash('sha256').update(archive).digest('hex');
  11 |   expect(archiveSha256).toBe(readFileSync(process.env.KEEPANY_PREVIEW_ARCHIVE+'.sha256','utf8').split(/\s+/)[0]);
  12 |   const files=unzipSync(archive);const release=JSON.parse(strFromU8(files[Object.keys(files).find(n=>n.endsWith('/RELEASE.json'))!]));
  13 |   const papa=release.webFiles.filter((row:{path:string})=>/^assets\/papaparse[^/]+\.js$/.test(row.path));expect(papa).toHaveLength(1);
  14 |   const stop=await observeGraphNetwork(page,info);
  15 |   const control=await page.context().newCDPSession(page);
  16 |   const failures:{path:string;error:string|null;at:string}[]=[];
  17 |   page.on('requestfailed',request=>failures.push({path:new URL(request.url()).pathname,error:request.failure()?.errorText??null,at:new Date().toISOString()}));
  18 |   const receipt:Record<string,unknown>={classification:'declared inspector CSV-dependency block; controlled regression, not spontaneous browser-root-cause reproduction',archiveSha256,sourceCommit:release.sourceCommit,sourceDirty:release.sourceDirty,target:papa[0].path};
  19 |   try {
  20 |     await page.addInitScript(()=>localStorage.setItem('keepany-language','zh-CN'));
  21 |     await page.goto('/assets/account');
  22 |     const workspace=page.locator('main.unified-accounts-page');
  23 |     await workspace.getByRole('button',{name:'新增',exact:true}).click();
  24 |     const editor=page.getByRole('dialog');
  25 |     await editor.locator('#name').fill('Synthetic FC20 ordinary account');
  26 |     await selectChoice(editor.locator('#category'),'other');
  27 |     await editor.locator('#username').fill('ordinary.fc20@example.test');
  28 |     await editor.getByRole('button',{name:'保存',exact:true}).click();
  29 |     await expect(editor).toBeHidden();
  30 |     const card=workspace.locator('.asset-account-card').filter({hasText:'Synthetic FC20 ordinary account'});
  31 |     await expect(card).toBeVisible();receipt.originalHref=await card.getAttribute('href');
  32 |     await page.goto('/');
  33 |     await expect(page.getByRole('heading',{name:'概览',level:1,exact:true})).toBeVisible();
  34 |     await control.send('Network.enable');
  35 |     await control.send('Network.setBlockedURLs',{urls:[new URL(papa[0].path,info.project.use.baseURL).href]});
  36 |     await page.getByRole('link',{name:'账号',exact:true}).click();
> 37 |     await expect(workspace.getByRole('button',{name:'新增',exact:true})).toBeVisible();
     |                                                                        ^ Error: expect(locator).toBeVisible() failed
  38 |     await expect(card).toBeVisible();
  39 |     expect(await card.getAttribute('href')).toBe(receipt.originalHref);
  40 |     await expect(page.locator('.route-load-error')).toHaveCount(0);
  41 |     receipt.basicAccountsPreserved=true;
  42 |   } finally {
  43 |     receipt.failedRequests=failures;
  44 |     receipt.routeErrorVisible=await page.locator('.route-load-error').isVisible();
  45 |     receipt.visibleAddCount=await page.locator('main.unified-accounts-page').getByRole('button',{name:'新增',exact:true}).count();
  46 |     writeFileSync(info.outputPath('core-dependency-receipt.json'),JSON.stringify(receipt,null,2)+'\n');
  47 |     await page.screenshot({path:info.outputPath('actual-final-ui.png')});
  48 |     await control.send('Network.setBlockedURLs',{urls:[]});await control.detach();await stop();
  49 |   }
  50 | });
  51 | 
```