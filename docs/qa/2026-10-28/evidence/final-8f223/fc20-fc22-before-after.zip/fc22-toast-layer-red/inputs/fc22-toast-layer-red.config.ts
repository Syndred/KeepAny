import {defineConfig} from '@playwright/test';
import {resolve} from 'node:path';
export default defineConfig({testDir:resolve('tests/e2e'),testMatch:'toast-dialog-layer.spec.ts',grep:/zh-CN 390 /,outputDir:resolve('test-results/fc22-toast-layer-red/run'),workers:1,retries:0,timeout:120000,use:{baseURL:'http://127.0.0.1:4236',serviceWorkers:'allow',actionTimeout:15000,trace:'on',screenshot:'only-on-failure'},webServer:{cwd:process.cwd(),command:'node scripts/serve-preview-for-tests.mjs',url:'http://127.0.0.1:4236',reuseExistingServer:false,timeout:30000}});
