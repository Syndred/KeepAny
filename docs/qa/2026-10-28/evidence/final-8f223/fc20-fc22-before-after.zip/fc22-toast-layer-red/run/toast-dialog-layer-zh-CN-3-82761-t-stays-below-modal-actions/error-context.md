# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: toast-dialog-layer.spec.ts >> zh-CN 390 FC22 active success toast stays below modal actions
- Location: tests\e2e\toast-dialog-layer.spec.ts:10:3

# Error details

```
Error: Page feedback must not paint over the modal or its actions

expect(received).toBeLessThan(expected)

Expected: < 30
Received:   50
```

# Page snapshot

```yaml
- generic [ref=f1e1]:
  - generic [ref=f1e2]:
    - generic [ref=f1e3]:
      - complementary [ref=f1e4]:
        - generic [aria-hidden] [ref=f1e5]:
          - generic [aria-hidden] [ref=f1e6]: K
          - generic [ref=f1e7]:
            - strong [ref=f1e8]: KeepAny
            - generic [ref=f1e9]: 个人资产工作台
          - button [ref=f1e10] [cursor=pointer]
        - button [aria-hidden] [ref=f1e14] [cursor=pointer]:
          - strong [ref=f1e19]: 个人工作区
        - generic [aria-hidden] [ref=f1e22]: 工作空间
        - navigation "导航" [ref=f1e23]:
          - generic [aria-hidden] [ref=f1e24]:
            - button [ref=f1e25]
            - link [ref=f1e33] [cursor=pointer]:
              - /url: /
              - generic [ref=f1e39]: 概览
          - generic [aria-hidden] [ref=f1e40]:
            - button [ref=f1e41]
            - link [ref=f1e49] [cursor=pointer]:
              - /url: /tasks
              - generic [ref=f1e53]: 待办
              - generic [ref=f1e54]: "5"
          - generic [aria-hidden] [ref=f1e55]:
            - button [ref=f1e56]
            - link [ref=f1e64] [cursor=pointer]:
              - /url: /assets
              - generic [ref=f1e69]: 资产
          - generic [aria-hidden] [ref=f1e70]:
            - button [ref=f1e71]
            - link [ref=f1e79] [cursor=pointer]:
              - /url: /accounts
              - generic [ref=f1e83]: 账号
          - status [ref=f1e84]
        - link [aria-hidden] [ref=f1e85] [cursor=pointer]:
          - /url: /trash
          - text: 回收站
        - generic [aria-hidden] [ref=f1e89]:
          - generic [ref=f1e90]: 我的分类
          - link [ref=f1e91] [cursor=pointer]:
            - /url: /collections/485268dc-bc69-492f-83d8-d27b98b0ee31
            - generic [ref=f1e92]: 工作室资料
          - link [ref=f1e93] [cursor=pointer]:
            - /url: /collections
            - text: 自定义侧边栏
        - button [ref=f1e96] [cursor=pointer]:
          - generic [ref=f1e97]: 我
          - generic [ref=f1e98]:
            - strong [ref=f1e99]: 我的工作区
            - generic [ref=f1e100]: 仅自己可见
      - generic [aria-hidden] [ref=f1e103]:
        - banner [ref=f1e104]:
          - button [ref=f1e105] [cursor=pointer]
          - link [ref=f1e107] [cursor=pointer]:
            - /url: /
            - text: 返回概览
          - button [ref=f1e110] [cursor=pointer]
          - generic [ref=f1e114]:
            - link [ref=f1e115] [cursor=pointer]:
              - /url: /tasks
            - button [ref=f1e120] [cursor=pointer]
            - link [ref=f1e124] [cursor=pointer]:
              - /url: /intake
        - complementary [ref=f1e126]:
          - strong [ref=f1e127]: 1 项提醒
          - link [ref=f1e129] [cursor=pointer]:
            - /url: /tasks#task-200fb752-8f97-4508-a694-5e8d0f558723
            - text: 确认素材使用范围
        - main [ref=f1e130]:
          - generic [ref=f1e131]:
            - generic [ref=f1e132]:
              - generic [ref=f1e133]:
                - heading [level=1] [ref=f1e134]: 账号
                - generic [ref=f1e135]:
                  - paragraph [ref=f1e136]: 8 条
                  - status [ref=f1e137]: 已解锁
              - button [ref=f1e138] [cursor=pointer]: 新增
            - generic [ref=f1e141]:
              - button [ref=f1e142] [cursor=pointer]
              - button [ref=f1e148] [cursor=pointer]
              - button [ref=f1e152] [cursor=pointer]
              - button [ref=f1e156] [cursor=pointer]
              - button [ref=f1e160] [cursor=pointer]
              - button [ref=f1e164] [cursor=pointer]
              - button [ref=f1e168] [cursor=pointer]: 密码回收站
              - button [ref=f1e172] [cursor=pointer]
            - generic [ref=f1e174]:
              - generic [ref=f1e175]:
                - generic [ref=f1e176]:
                  - button [ref=f1e177] [cursor=pointer]: 全部
                  - button [ref=f1e178] [cursor=pointer]: 邮箱
                  - button [ref=f1e179] [cursor=pointer]: 手机
                  - button [ref=f1e180] [cursor=pointer]: 自媒体
                  - button [ref=f1e181] [cursor=pointer]: 其他
                  - button [ref=f1e182] [cursor=pointer]
                - searchbox [ref=f1e188]
                - button [ref=f1e189] [cursor=pointer]: 管理
              - generic [ref=f1e190]:
                - generic [ref=f1e191]: 按标签筛选
                - generic [ref=f1e192]:
                  - combobox [ref=f1e193] [cursor=pointer]:
                    - generic [ref=f1e194]: 全部标签
                  - textbox [aria-hidden] [ref=f1e198]
              - generic [ref=f1e199]:
                - article [ref=f1e200]:
                  - link [ref=f1e201] [cursor=pointer]:
                    - /url: /assets/account/0010a3e1-dd8a-4ebf-a078-1af932b0235e
                    - generic [ref=f1e206]:
                      - strong [ref=f1e207]: 示例 | 团队文档账号
                      - generic [ref=f1e208]: docs@example.com
                      - generic [ref=f1e209]:
                        - generic [ref=f1e210]: 其他
                        - generic [ref=f1e211]: 1 个关联
                  - group [ref=f1e212]:
                    - generic [ref=f1e213] [cursor=pointer]: 1 个密码条目
                - article [ref=f1e214]:
                  - link [ref=f1e215] [cursor=pointer]:
                    - /url: /assets/account/091fcfa7-775f-4c22-8d49-db72eff301a4
                    - generic [ref=f1e220]:
                      - strong [ref=f1e221]: 示例 | 松果内容频道
                      - generic [ref=f1e222]: pinecone
                      - generic [ref=f1e223]:
                        - generic [ref=f1e224]: 其他
                        - generic [ref=f1e225]: 1 个关联
                  - group [ref=f1e226]:
                    - generic [ref=f1e227] [cursor=pointer]: 1 个密码条目
                - article [ref=f1e228]:
                  - link [ref=f1e229] [cursor=pointer]:
                    - /url: /assets/account/c17ba831-aa6d-45a5-8216-402096bd9e10
                    - generic [ref=f1e233]:
                      - strong [ref=f1e234]: 示例 | 工作室联系号码
                      - generic [ref=f1e235]: +1 202-555-0142
                      - generic [ref=f1e236]:
                        - generic [ref=f1e237]: 手机
                        - generic [ref=f1e238]: 8 个关联
                  - group [ref=f1e239]:
                    - generic [ref=f1e240] [cursor=pointer]: 1 个密码条目
                - article [ref=f1e241]:
                  - link [ref=f1e242] [cursor=pointer]:
                    - /url: /assets/account/cc0faa2e-45c8-4695-a8a5-eb7f9dc52cf2
                    - generic [ref=f1e247]:
                      - strong [ref=f1e248]: 示例 | CodeHub 开发账号
                      - generic [ref=f1e249]: pinecone-dev
                      - generic [ref=f1e250]:
                        - generic [ref=f1e251]: 其他
                        - generic [ref=f1e252]: 2 个关联
                  - group [ref=f1e253]:
                    - generic [ref=f1e254] [cursor=pointer]: 1 个密码条目
                - article [ref=f1e255]:
                  - link [ref=f1e256] [cursor=pointer]:
                    - /url: /assets/account/d449e86c-f8b0-4924-8606-f1c4b82643f1
                    - generic [ref=f1e261]:
                      - strong [ref=f1e262]: 示例 | 工作室邮箱
                      - generic [ref=f1e263]: hello@example.com
                      - generic [ref=f1e264]:
                        - generic [ref=f1e265]: 邮箱
                        - generic [ref=f1e266]: 4 个关联
                  - group [ref=f1e267]:
                    - generic [ref=f1e268] [cursor=pointer]: 1 个密码条目
                - article [ref=f1e269]:
                  - link [ref=f1e270] [cursor=pointer]:
                    - /url: /assets/account/e99b49d6-a655-417e-a3ec-53ea8b458e25
                    - generic [ref=f1e275]:
                      - strong [ref=f1e276]: 示例 | 免密码登录
                      - generic [ref=f1e277]:
                        - generic [ref=f1e278]: 其他
                        - generic [ref=f1e279]: 1 个关联
                  - group [ref=f1e280]:
                    - generic [ref=f1e281] [cursor=pointer]: 1 个密码条目
                - article [ref=f1e282]:
                  - link [ref=f1e283] [cursor=pointer]:
                    - /url: /assets/account/ed38d5d2-2022-4a5d-b561-4b065c659e08
                    - generic [ref=f1e288]:
                      - strong [ref=f1e289]: 示例 | 轻画设计账号
                      - generic [ref=f1e290]: design@example.com
                      - generic [ref=f1e291]:
                        - generic [ref=f1e292]: 其他
                        - generic [ref=f1e293]: 2 个关联
                  - group [ref=f1e294]:
                    - generic [ref=f1e295] [cursor=pointer]: 1 个密码条目
                - article [ref=f1e296]:
                  - link [ref=f1e297] [cursor=pointer]:
                    - /url: /assets/account/f6332209-51cd-4548-a704-fcf0e81af69b
                    - generic [ref=f1e302]:
                      - strong [ref=f1e303]: 示例 | 访问统计账号
                      - generic [ref=f1e304]: hello@example.com
                      - generic [ref=f1e305]:
                        - generic [ref=f1e306]: 其他
                        - generic [ref=f1e307]: 1 个关联
                  - group [ref=f1e308]:
                    - generic [ref=f1e309] [cursor=pointer]: 1 个密码条目
            - generic [ref=f1e310]:
              - generic [ref=f1e311]:
                - heading [level=3] [ref=f1e312]: 密码回收站
                - generic [ref=f1e316]: 移入回收站的条目仍可恢复。
              - paragraph [ref=f1e317]: 回收站为空。
          - group [ref=f1e318]:
            - generic [ref=f1e319] [cursor=pointer]:
              - text: 外部密码库引用
              - generic [ref=f1e320]: "2"
    - status [aria-hidden] [ref=f1e321]: 示例登录条目已加入，含无密码登录示例。
  - dialog [ref=f1e325]:
    - banner [ref=f1e326]:
      - heading "新密码条目" [level=2] [ref=f1e327]
      - button "关闭" [active] [ref=f1e328] [cursor=pointer]
    - generic [ref=f1e332]:
      - generic [ref=f1e333]:
        - generic [ref=f1e334]:
          - generic [ref=f1e335]: 名称
          - generic [ref=f1e336]:
            - textbox "名称" [ref=f1e337]
            - generic [ref=f1e338]:
              - button "复制名称" [disabled] [ref=f1e340]
              - button "粘贴名称" [ref=f1e345] [cursor=pointer]
        - generic [ref=f1e352]:
          - generic [ref=f1e353]:
            - generic [ref=f1e354]: 用户名或账号
            - button "添加登录标识" [ref=f1e355] [cursor=pointer]
          - generic [ref=f1e357]:
            - textbox "用户名或账号" [ref=f1e358]
            - generic [ref=f1e359]:
              - button "复制用户名或账号" [disabled] [ref=f1e361]
              - button "粘贴用户名或账号" [ref=f1e366] [cursor=pointer]
        - generic [ref=f1e372]:
          - generic [ref=f1e373]: 密码（可选）
          - generic [ref=f1e374]:
            - generic [ref=f1e375]:
              - textbox "密码（可选）" [ref=f1e376]:
                - /placeholder: 可留空，例如使用第三方账号登录
              - button "显示密码" [ref=f1e377] [cursor=pointer]
              - button "生成密码" [ref=f1e378] [cursor=pointer]
            - generic [ref=f1e379]:
              - button "复制密码" [disabled] [ref=f1e381]
              - button "粘贴密码" [ref=f1e386] [cursor=pointer]
        - generic [ref=f1e394]:
          - generic [ref=f1e395]:
            - generic [ref=f1e396]: 备注（可选）
            - button "添加网址" [ref=f1e397] [cursor=pointer]
          - generic [ref=f1e398]:
            - textbox "备注（可选）" [ref=f1e399]
            - generic [ref=f1e400]:
              - button "复制备注" [disabled] [ref=f1e402]
              - button "粘贴备注" [ref=f1e407] [cursor=pointer]
      - generic [ref=f1e413]:
        - generic [ref=f1e414]: 关联资产
        - generic [ref=f1e415]: 关联的资产名称会显示在条目中，密码不会进入资产搜索。
        - generic [ref=f1e416]:
          - combobox "关联资产" [ref=f1e417] [cursor=pointer]:
            - generic "选择要关联的资产" [ref=f1e418]
          - textbox [aria-hidden] [ref=f1e422]
      - button "保存条目" [ref=f1e424] [cursor=pointer]
```

# Test source

```ts
  18  | 				acceptanceIds: ["FC22-A", "FC22-B", "FC22-C"],
  19  | 				classification:
  20  | 					"isolated fictional actual compiled UI; real completed sample-login operation creates the toast; no injected toast or waiting for it to disappear",
  21  | 				locale,
  22  | 				width,
  23  | 				sourceCommit: release.sourceCommit,
  24  | 				sourceDirty: release.sourceDirty,
  25  | 				archiveSha256,
  26  | 			};
  27  | 			try {
  28  | 				await page.addInitScript(
  29  | 					(language) => localStorage.setItem("keepany-language", language),
  30  | 					locale,
  31  | 				);
  32  | 				await page.goto("/settings#advanced-settings");
  33  | 				await page
  34  | 					.getByRole("button", { name: t("loadSample"), exact: true })
  35  | 					.click();
  36  | 				await expect(
  37  | 					page.getByRole("button", {
  38  | 						name: t("sampleLibraryPresent"),
  39  | 						exact: true,
  40  | 					}),
  41  | 				).toBeDisabled();
  42  | 				await page.goto("/accounts");
  43  | 				await openVaultAccess(page);
  44  | 				await page.locator("#password-vault-master").fill(master);
  45  | 				await page.locator("#password-vault-master-confirm").fill(master);
  46  | 				await page
  47  | 					.getByRole("button", { name: t("pwVaultCreate"), exact: true })
  48  | 					.click();
  49  | 				const toolbar = page.locator(".password-vault-toolbar");
  50  | 				const samples = toolbar.getByRole("button", {
  51  | 					name: t("sampleLogins"),
  52  | 					exact: true,
  53  | 				});
  54  | 				await samples.click();
  55  | 				await expect(samples).toHaveCount(0, { timeout: 30_000 });
  56  | 				const originalHrefs = await page
  57  | 					.locator("a.asset-account-card")
  58  | 					.evaluateAll((nodes) =>
  59  | 						nodes.map((node) => node.getAttribute("href")),
  60  | 					);
  61  | 				expect(originalHrefs).toHaveLength(8);
  62  | 				receipt.originalHrefs = originalHrefs;
  63  | 				const toast = page.locator('.toast[role="status"]');
  64  | 				await expect(toast).toBeVisible();
  65  | 				receipt.originalToastText = await toast.innerText();
  66  | 				await page.screenshot({
  67  | 					path: info.outputPath("toast-normal-page.png"),
  68  | 				});
  69  | 				await toolbar
  70  | 					.getByRole("button", { name: t("pwVaultNewEntry"), exact: true })
  71  | 					.click();
  72  | 				const dialog = page.getByRole("dialog"),
  73  | 					save = dialog.getByRole("button", {
  74  | 						name: t("pwVaultSaveEntry"),
  75  | 						exact: true,
  76  | 					});
  77  | 				await expect(dialog).toBeVisible();
  78  | 				await expect(toast).toBeVisible();
  79  | 				const geometry = await save.evaluate((button) => {
  80  | 					const popup = button.closest('[role="dialog"]'),
  81  | 						notice = document.querySelector('.toast[role="status"]'),
  82  | 						backdrop = document.querySelector(".overlay");
  83  | 					if (!popup || !notice || !backdrop)
  84  | 						throw Error("Expected actual toast, modal and backdrop");
  85  | 					const a = button.getBoundingClientRect(),
  86  | 						b = notice.getBoundingClientRect();
  87  | 					return {
  88  | 						toastZ: Number(getComputedStyle(notice).zIndex),
  89  | 						backdropZ: Number(getComputedStyle(backdrop).zIndex),
  90  | 						dialogZ: Number(getComputedStyle(popup).zIndex),
  91  | 						overlapArea:
  92  | 							Math.max(
  93  | 								0,
  94  | 								Math.min(a.right, b.right) - Math.max(a.left, b.left),
  95  | 							) *
  96  | 							Math.max(
  97  | 								0,
  98  | 								Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top),
  99  | 							),
  100 | 						tap: { x: a.x + a.width / 2, y: a.y + a.height * 0.85 },
  101 | 						button: { x: a.x, y: a.y, width: a.width, height: a.height },
  102 | 						toastVisible: b.width > 0 && b.height > 0,
  103 | 					};
  104 | 				});
  105 | 				receipt.geometry = geometry;
  106 | 				await page.screenshot({
  107 | 					path: info.outputPath("toast-and-dialog.png"),
  108 | 				});
  109 | 				await expect(toast).toBeVisible();
  110 | 				if (process.env.KEEPANY_FC22_REQUIRE_OVERLAP === "1")
  111 | 					expect(
  112 | 						geometry.overlapArea,
  113 | 						"Pre-fix failure must be actual overlapping UI",
  114 | 					).toBeGreaterThan(0);
  115 | 				expect(
  116 | 					geometry.toastZ,
  117 | 					"Page feedback must not paint over the modal or its actions",
> 118 | 				).toBeLessThan(geometry.backdropZ);
      |       ^ Error: Page feedback must not paint over the modal or its actions
  119 | 				expect(geometry.backdropZ).toBeLessThan(geometry.dialogZ);
  120 | 				expect(geometry.button.width).toBeGreaterThanOrEqual(44);
  121 | 				expect(geometry.button.height).toBeGreaterThanOrEqual(44);
  122 | 				const hit = await page.evaluate((point) => {
  123 | 					const element = document.elementFromPoint(point.x, point.y);
  124 | 					return {
  125 | 						insideDialog: !!element?.closest('[role="dialog"]'),
  126 | 						insideToast: !!element?.closest(".toast"),
  127 | 					};
  128 | 				}, geometry.tap);
  129 | 				expect(hit).toEqual({ insideDialog: true, insideToast: false });
  130 | 				receipt.modalTapUnobstructed = true;
  131 | 				await page.mouse.click(geometry.tap.x, geometry.tap.y);
  132 | 				await expect(dialog).toBeVisible();
  133 | 				expect(
  134 | 					await dialog
  135 | 						.locator("#password-vault-entry-title")
  136 | 						.evaluate(
  137 | 							(node) => (node as HTMLInputElement).validity.valueMissing,
  138 | 						),
  139 | 				).toBe(true);
  140 | 				await expect(toast).toBeVisible();
  141 | 				await page.screenshot({
  142 | 					path: info.outputPath("toast-and-required-error.png"),
  143 | 				});
  144 | 				await expect(toast).toBeVisible();
  145 | 				receipt.toastVisibleThroughoutModalCheck = true;
  146 | 				receipt.requiredInputStayedUnsaved = true;
  147 | 				await dialog
  148 | 					.getByRole("button", { name: t("close"), exact: true })
  149 | 					.click();
  150 | 				await expect(dialog).toBeHidden();
  151 | 				expect(
  152 | 					await page
  153 | 						.locator("a.asset-account-card")
  154 | 						.evaluateAll((nodes) =>
  155 | 							nodes.map((node) => node.getAttribute("href")),
  156 | 						),
  157 | 				).toEqual(originalHrefs);
  158 | 				receipt.assetIdentitiesPreserved = true;
  159 | 				receipt.completed = true;
  160 | 			} finally {
  161 | 				writeFileSync(
  162 | 					info.outputPath("toast-layer-receipt.json"),
  163 | 					`${JSON.stringify(receipt, null, 2)}\n`,
  164 | 				);
  165 | 			}
  166 | 		});
  167 | 	}
  168 | 
```