import {expect,test} from '@playwright/test';
import {selectChoice} from '../tests/e2e/helpers/select-choice';
for(const locale of ['zh-CN','en'] as const)test(`${locale} empty vault must not claim existing passwords are locked`,async({page},info)=>{
 const zh=locale==='zh-CN';
 await page.addInitScript(language=>localStorage.setItem('keepany-language',language),locale);
 await page.goto('/accounts');const workspace=page.locator('main.unified-accounts-page');
 await workspace.getByRole('button',{name:zh?'新增':'Add',exact:true}).click();
 const editor=page.getByRole('dialog');await editor.locator('#name').fill('Synthetic FC21 empty-vault account');await selectChoice(editor.locator('#category'),'other');await editor.locator('#username').fill('fc21.empty@example.test');await editor.getByRole('button',{name:zh?'保存':'Save',exact:true}).click();await expect(editor).toBeHidden();
 const card=workspace.locator('.unified-account').filter({hasText:'Synthetic FC21 empty-vault account'});await expect(card).toBeVisible();
 await expect(workspace.locator('.password-vault-header-meta [role="status"]')).toHaveText(zh?'未建立':'Not set up');
 await page.screenshot({path:info.outputPath('actual-empty-vault-account.png')});
 await expect(card.locator('.unified-account-locked')).toHaveText(zh?'尚未建立密码库。':'No password vault has been created.');
});
