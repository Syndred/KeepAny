from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,json,shutil

root=Path.cwd()
base=root/'test-results/final-8f223-vault-finite'
dest=root/'docs/qa/2026-10-28/evidence/final-8f223'
sha=lambda data:hashlib.sha256(data).hexdigest()
record_path=base/'evidence/machine-evidence.json'
record=json.loads(record_path.read_text(encoding='utf-8'))
original=dest/'vault-tools-machine.zip'
assert sha(original.read_bytes())=='6e7afd0a2f27eb1eeca6e903c7b5351ec58fc2e9ff5de69be0e58c69b674a92b'
with ZipFile(original) as z:
    for case in record['cases']:
        for file in [{'path':case['receipt'],'sha256':case['sha256']},*case['evidence']]:
            assert sha(z.read('strict66/run/'+file['path']))==file['sha256'],file['path']
probe=root/'test-results/vault-gate-probes-6v4iIh'
green=json.loads((probe/'results.json').read_text(encoding='utf-8'))
assert green['status']=='passed' and len(green['results'])==21 and all(row['passed'] for row in green['results'])
selected=[]
for path in base.rglob('*'):
    if path.is_file() and 'evidence' not in path.relative_to(base).parts:
        selected.append((path,'root/'+path.relative_to(base).as_posix()))
selected.append((record_path,'current-machine-evidence.json'))
for path in [root/'scripts/verify-vault-tool-evidence.mjs',root/'scripts/test-vault-tool-evidence.mjs',root/'test-results/prepare-vault-finite-recheck.py',root/'test-results/reconstruct-vault-finite-red-input.mjs',root/'test-results/freeze-vault-finite-check.py']:
    selected.append((path,'current-inputs/'+path.relative_to(root).as_posix()))
for path in probe.rglob('*'):
    if path.is_file() and (path==probe/'results.json' or path.parent==probe/'logs'):
        selected.append((path,'final-green/'+path.relative_to(probe).as_posix()))
for name in ['gate-nonfinite-counterexample.mjs','gate-nonfinite-counterexample.json']:
    path=root/'test-results/independent-final-8f223'/name
    selected.append((path,'independent-original/'+name))
assert json.loads((root/'test-results/independent-final-8f223/gate-nonfinite-counterexample.json').read_text(encoding='utf-8'))['exit']==0
output=dest/'vault-evidence-finite-check.zip'
manifest=[]
with ZipFile(output,'x',ZIP_DEFLATED,compresslevel=9) as z:
    names=set()
    for path,key in sorted(selected,key=lambda row:row[1]):
        assert key not in names and '..' not in Path(key).parts
        names.add(key);data=path.read_bytes();z.writestr(key,data)
        manifest.append({'path':key,'source':path.relative_to(root).as_posix(),'bytes':len(data),'sha256':sha(data)})
    z.writestr('MANIFEST.json',json.dumps({'schema':'keepany.frozen-evidence.v1','classification':'Mechanical finite-number guard correction. Unchanged real UI evidence is hash-bound to strict66/run in the original committed vault-tools-machine.zip; no UI rerun or changed expected result. Original false accept and probe assertion red retained.','entries':manifest},ensure_ascii=False,indent=2).encode())
with ZipFile(output) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(set(z.namelist()))==len(manifest)+1
    for row in manifest:
        data=z.read(row['path']);assert len(data)==row['bytes'] and sha(data)==row['sha256'],row['path']
summary={'schema':'keepany.vault-finite-guard-check.v1','status':'passed','classification':'Mechanical evidence verifier only; not a product/UI defect or new browser execution','candidate':record['sourceCommit'],'archiveSha256':record['archiveSha256'],'actualRealUiTests':'Original strict66/672 unchanged','sameReceiptHashes':66,'samePngHashes':672,'sameUiInputs':6,'onlyChangedMachineInput':'scripts/verify-vault-tool-evidence.mjs','originalRawArchive':{'path':original.relative_to(root).as_posix(),'sha256':sha(original.read_bytes()),'memberPrefix':'strict66/run/'},'supplement':{'path':output.relative_to(root).as_posix(),'bytes':output.stat().st_size,'sha256':sha(output.read_bytes()),'members':len(manifest)+1,'crcUniquePathsAllMemberHashes':'passed'},'red':'Original checker accepted width string Infinity with exit0. Exact accepted bytes reconstructed from preserved object and verified against its existing accepted-record receipt SHA ec2d9177a702516761c3c7681ca2923c185bee46b73bc68b56825bb359385e50. Original pretty evidence also retained.','green':'New checker requires finite numeric width/height >=44. Complete unchanged evidence passes;1positive20negative final probes pass, including width/height strings Infinity and44. New malformed-input artifacts store the exact bytes supplied to the verifier.','scope':'Human visual/whitebox/owner/independent and overall final delivery remain separate.'}
with (dest/'vault-evidence-finite-check.json').open('x',encoding='utf-8') as f:json.dump(summary,f,ensure_ascii=False,indent=2)
print(json.dumps({'status':'passed','supplement':summary['supplement'],'pngsStillInOriginalArchive':672},ensure_ascii=False))
