from pathlib import Path
import hashlib,json,shutil

root=Path.cwd()
source=root/'test-results/final-8f223-vault-tools-strict/run'
destination=root/'test-results/final-8f223-vault-finite/evidence'
destination.mkdir()
record=json.loads((source/'machine-evidence.json').read_text(encoding='utf-8'))
sha=lambda data:hashlib.sha256(data).hexdigest()
ui_inputs=[]
for row in record['testInputs']:
    if row['path']=='scripts/verify-vault-tool-evidence.mjs':continue
    actual=sha((root/row['path']).read_text(encoding='utf-8').replace('\r\n','\n').encode())
    assert actual==row['canonicalSha256'],row['path']
    ui_inputs.append(row)
assert len(ui_inputs)==6
for case in record['cases']:
    for file in [{'path':case['receipt'],'sha256':case['sha256']},*case['evidence']]:
        original=source/file['path'];copied=destination/file['path']
        assert copied.resolve().is_relative_to(destination.resolve())
        assert sha(original.read_bytes())==file['sha256'],file['path']
        copied.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(original,copied)
with (destination.parent/'recheck-input-provenance.json').open('x',encoding='utf-8') as stream:
    json.dump({'classification':'Re-evaluate unchanged real UI evidence with a narrower mechanical verifier fix. No browser rerun or relabel of the original run.','source':source.relative_to(root).as_posix(),'sourceMachineRecordSha256':sha((source/'machine-evidence.json').read_bytes()),'copiedReceipts':len(record['cases']),'copiedPngs':sum(len(case['evidence']) for case in record['cases']),'unchangedSixUiInputs':ui_inputs,'onlyCheckerChanged':'Finite numeric width/height guard; original checker and original machine record remain preserved.'},stream,indent=2)
print(json.dumps({'receipts':len(record['cases']),'pngs':sum(len(c['evidence']) for c in record['cases']),'unchangedUiInputs':len(ui_inputs),'output':destination.relative_to(root).as_posix()}))
