# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: account-layout-independent.spec.ts >> independent zh-CN 768: AL02 AL03 AL04 AL05 shared consumers
- Location: tests\e2e\account-layout-independent.spec.ts:15:2

# Error details

```
Error: accounts 密码回收站 right boundary

expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= -0.001
Received:    -30
```

# Test source

```ts
  1   | import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
  2   | import { join } from "node:path";
  3   | import { expect, test, type Locator } from "@playwright/test";
  4   | import { resources } from "../../apps/web/src/i18n";
  5   | 
  6   | // Independent acceptance: only public navigation/UI, fresh synthetic library per case.
  7   | const evidence = process.env.KEEPANY_INDEPENDENT_EVIDENCE ?? "test-results/account-layout-independent";
  8   | mkdirSync(evidence, { recursive: true });
  9   | const master = "Independent synthetic vault 2026!";
  10  | const longTitle = "Independent synthetic login — long title with readable complete metadata across every consuming container";
  11  | const longUrl = `https://independent.example.test/${"readable-path/".repeat(12)}`;
  12  | const notes = "Synthetic notes only. Every field must remain readable without a narrow value column.\n第二行虚构备注：长内容应完整显示，不裁剪、不丢失。";
  13  | 
  14  | for (const language of ["zh-CN", "en"] as const) for (const width of [390, 768, 1280, 1920, 2560]) {
  15  |  test(`independent ${language} ${width}: AL02 AL03 AL04 AL05 shared consumers`, async ({ browser }) => {
  16  |   test.setTimeout(240_000);
  17  |   const context = await browser.newContext({ viewport: { width, height: 1050 }, locale: language });
  18  |   await context.addInitScript((locale) => localStorage.setItem("keepany-language", locale), language);
  19  |   const page = await context.newPage(); page.setDefaultTimeout(15_000);
  20  |   const t = (key: string) => (resources[language].translation as Record<string, string>)[key] ?? key;
  21  |   const errors: string[] = []; page.on("pageerror", (error) => errors.push(error.message));
  22  |   const steps: object[] = [];
  23  |   const stem = `${language}-${width}`;
  24  |   async function capture(name: string, target?: Locator) {
  25  |    if (target) { await target.scrollIntoViewIfNeeded(); await target.screenshot({ path: join(evidence, `${stem}-${name}.png`) }); }
  26  |    else await page.screenshot({ path: join(evidence, `${stem}-${name}.png`), fullPage: true });
  27  |    steps.push({ step: name, url: page.url(), screenshot: `${stem}-${name}.png` });
  28  |   }
  29  |   async function readable(card: Locator, name: string) {
  30  |    await expect(card).toBeVisible();
  31  |    const metrics = await card.evaluate((node) => {
  32  |     const box = node.getBoundingClientRect();
  33  |     const values = [...node.querySelectorAll<HTMLElement>(".password-vault-value")].map((value) => ({ width: value.getBoundingClientRect().width, scroll: value.scrollWidth, client: value.clientWidth }));
  34  |     const buttons = [...node.querySelectorAll<HTMLElement>(".password-vault-value-actions button")].map((button) => { const r = button.getBoundingClientRect(); return { width: r.width, height: r.height, left: r.left - box.left, right: box.right - r.right }; });
  35  |     return { width: box.width, values, buttons, overflow: document.documentElement.scrollWidth > document.documentElement.clientWidth };
  36  |    });
  37  |    expect(metrics.overflow).toBe(false);
  38  |    for (const value of metrics.values) { expect(value.width).toBeGreaterThan(150); expect(value.scroll).toBeLessThanOrEqual(value.client + 1); }
  39  |    // CSS pixels are subtracted from large scroll coordinates; normalize only
  40  |    // floating point noise (<0.001px), while retaining the 44px requirement.
  41  |    for (const button of metrics.buttons) { expect(Number(button.width.toFixed(3))).toBeGreaterThanOrEqual(44); expect(Number(button.height.toFixed(3))).toBeGreaterThanOrEqual(44); expect(button.left).toBeGreaterThanOrEqual(0); expect(button.right).toBeGreaterThanOrEqual(0); }
  42  |    steps.push({ step: `${name}-geometry`, metrics });
  43  |   }
  44  |   async function toolbarFits(toolbar: Locator, name: string) {
  45  |    const geometry = await toolbar.evaluate((node) => {
  46  |     const box = node.getBoundingClientRect();
  47  |     return { width: box.width, controls: [...node.querySelectorAll<HTMLElement>("button, input")].map((element) => { const rect = element.getBoundingClientRect(); return { label: element.getAttribute("aria-label") ?? element.textContent, left: rect.left - box.left, right: box.right - rect.right, width: rect.width }; }) };
  48  |    });
  49  |    steps.push({ step: `${name}-toolbar-geometry`, geometry });
> 50  |    for (const control of geometry.controls) { expect(control.left, `${name} ${control.label} left boundary`).toBeGreaterThanOrEqual(-0.001); expect(control.right, `${name} ${control.label} right boundary`).toBeGreaterThanOrEqual(-0.001); }
      |                                                                                                                                                                                                               ^ Error: accounts 密码回收站 right boundary
  51  |   }
  52  |   try {
  53  |    await page.goto("/settings#advanced-settings");
  54  |    await page.getByRole("button", { name: t("loadSample"), exact: true }).click();
  55  |    await expect(page.getByRole("button", { name: t("sampleLibraryPresent"), exact: true })).toBeDisabled();
  56  |    await page.goto("/accounts");
  57  |    const access = page.locator(".unified-vault-access"); await access.locator("summary").click();
  58  |    await page.locator("#password-vault-master").fill(master); await page.locator("#password-vault-master-confirm").fill(master);
  59  |    await page.getByRole("button", { name: t("pwVaultCreate"), exact: true }).click();
  60  |    const toolbar = page.locator(".password-vault-toolbar");
  61  |    const sampleButton = toolbar.getByRole("button", { name: t("sampleLogins"), exact: true });
  62  |    const sampleTextLines = await sampleButton.evaluate((node) => {
  63  |     const walker = document.createTreeWalker(node, NodeFilter.SHOW_TEXT), tops = new Set<number>();
  64  |     while (walker.nextNode()) { const range = document.createRange(); range.selectNodeContents(walker.currentNode); for (const rect of range.getClientRects()) tops.add(Math.round(rect.top)); }
  65  |     return tops.size;
  66  |    });
  67  |    await capture("toolbar-sample-logins", toolbar);
  68  |    await toolbarFits(toolbar, "accounts");
  69  |    expect(sampleTextLines, "AL10 sample action label must not fold into a narrow icon cell").toBe(1);
  70  |    await sampleButton.click();
  71  |    await expect(toolbar.getByRole("button", { name: t("sampleLogins"), exact: true })).toHaveCount(0, { timeout: 30_000 });
  72  |    const categories = page.locator(".unified-account-list").first().locator(".asset-category-scroll > button");
  73  |    const categoryCount = await categories.count();
  74  |    for (let index = 1; index < categoryCount - 1; index++) {
  75  |     await categories.nth(index).click();
  76  |     const accounts = page.locator(".unified-account");
  77  |     if (await accounts.count()) {
  78  |      const account = accounts.first(), disclosure = account.locator(".unified-account-passwords");
  79  |      await disclosure.locator("summary").click(); await expect(disclosure).toHaveJSProperty("open", true);
  80  |      if (await disclosure.locator(".password-vault-entry").count()) await readable(disclosure.locator(".password-vault-entry").first(), `category-${index}`);
  81  |      await capture(`category-${index}-expanded`, account);
  82  |     } else await capture(`category-${index}-empty`);
  83  |    }
  84  |    await categories.first().click();
  85  |    const query = page.getByRole("searchbox", { name: t("accountListSearch"), exact: true });
  86  |    await query.fill("not-an-existent-synthetic-account"); await expect(page.locator(".unified-account")).toHaveCount(0);
  87  |    await capture("filter-empty"); await query.press("Escape"); await expect(page.locator(".unified-account")).toHaveCount(8);
  88  |    await toolbar.getByRole("button", { name: t("pwVaultNewEntry"), exact: true }).click();
  89  |    await page.getByRole("dialog").getByRole("button", { name: t("pwVaultSaveEntry"), exact: true }).click();
  90  |    await expect(page.getByRole("dialog")).toBeVisible(); expect(await page.locator("#password-vault-entry-title").evaluate((node) => (node as HTMLInputElement).validity.valueMissing)).toBe(true);
  91  |    await capture("required-error");
  92  |    await page.locator("#password-vault-entry-title").fill("Cancelled synthetic draft");
  93  |    await page.getByRole("dialog").getByRole("button", { name: t("close"), exact: true }).click();
  94  |    await expect(page.locator(".workspace-password-only")).toHaveCount(0);
  95  |    await toolbar.getByRole("button", { name: t("pwVaultNewEntry"), exact: true }).click();
  96  |    await page.locator("#password-vault-entry-title").fill(longTitle); await page.locator("#password-vault-entry-username").fill("primary-independent@example.test");
  97  |    for (const alias of ["second-independent@example.test", "+1 202-555-0157"]) {
  98  |     await page.getByRole("dialog").getByRole("button", { name: t("pwVaultAddIdentifier"), exact: true }).click(); await page.locator(".pw-smart-identifier-row input").last().fill(alias);
  99  |    }
  100 |    await page.getByRole("dialog").getByRole("button", { name: t("pwVaultAddUrl"), exact: true }).click();
  101 |    await page.locator("#password-vault-entry-url").fill(longUrl); await page.locator("#password-vault-entry-notes").fill(notes);
  102 |    await page.getByRole("dialog").getByRole("button", { name: t("pwVaultSaveEntry"), exact: true }).click();
  103 |    const standalone = page.locator(".workspace-password-only .password-vault-entry");
  104 |    await expect(standalone).toContainText(longTitle); await expect(standalone).toContainText(longUrl); await expect(standalone).toContainText(notes);
  105 |    await readable(standalone, "unlinked"); await expect(standalone.getByRole("button", { name: t("pwVaultRevealPassword"), exact: true })).toBeDisabled();
  106 |    await capture("unlinked-long", standalone);
  107 |    await standalone.getByRole("button", { name: t("pwVaultEditEntry"), exact: true }).click(); await page.locator("#password-vault-entry-title").fill("Cancelled overwrite");
  108 |    await capture("unlinked-editor"); await page.getByRole("dialog").getByRole("button", { name: t("close"), exact: true }).click(); await expect(standalone).toContainText(longTitle);
  109 |    const phoneAccount = page.locator(".unified-account").filter({ has: page.locator(".asset-account-phone") });
  110 |    await phoneAccount.locator(".asset-account-card").click();
  111 |    await page.getByRole("button", { name: t("workspaceShowPasswords"), exact: true }).click();
  112 |    const detail = page.locator(".account-passwords-section");
  113 |    await readable(detail.locator(".password-vault-entry").first(), "detail"); await capture("detail-embedded", detail);
  114 |    await toolbarFits(detail.locator(".password-vault-toolbar"), "detail");
  115 |    await detail.locator(".password-vault-entry").first().getByRole("button", { name: t("pwVaultEditEntry"), exact: true }).click();
  116 |    await page.locator("#password-vault-entry-notes").fill(notes); await page.getByRole("dialog").getByRole("button", { name: t("pwVaultSaveEntry"), exact: true }).click();
  117 |    await expect(detail).toContainText(notes); await page.reload();
  118 |    await page.getByRole("button", { name: t("workspaceShowPasswords"), exact: true }).click();
  119 |    await page.locator("#password-vault-unlock-master").fill("wrong synthetic master"); await page.getByRole("button", { name: t("pwVaultUnlock"), exact: true }).click();
  120 |    await expect(page.locator(".password-vault-message").filter({ hasText: t("pwVaultUnlockFailed") })).toBeVisible(); await capture("detail-unlock-error", page.locator(".account-passwords-section"));
  121 |    await page.locator("#password-vault-unlock-master").fill(master); await page.getByRole("button", { name: t("pwVaultUnlock"), exact: true }).click();
  122 |    await expect(detail).toContainText(notes); await readable(detail.locator(".password-vault-entry").first(), "detail-reloaded");
  123 |    await capture("detail-reloaded", detail);
  124 |    // A full document navigation intentionally locks the in-memory KDBX session.
  125 |    await page.goto("/accounts");
  126 |    await expect(standalone).toHaveCount(0);
  127 |    const reentryAccess = page.locator(".unified-vault-access");
  128 |    if (!await reentryAccess.evaluate((node) => (node as HTMLDetailsElement).open)) await reentryAccess.locator("summary").click();
  129 |    await page.locator("#password-vault-unlock-master").fill(master); await page.getByRole("button", { name: t("pwVaultUnlock"), exact: true }).click();
  130 |    await expect(standalone).toContainText(longTitle); await query.fill(notes); await expect(page.locator(".workspace-password-only")).toHaveCount(0); await query.fill("");
  131 |    await readable(standalone, "unlinked-return"); expect(errors).toEqual([]);
  132 |    steps.push({ step: "finished", errors, result: "passed" });
  133 |   } finally {
  134 |    const candidate = process.env.KEEPANY_PREVIEW_DIRECTORY ? JSON.parse(readFileSync(join(process.env.KEEPANY_PREVIEW_DIRECTORY, "RELEASE.json"), "utf8")) : null;
  135 |    writeFileSync(join(evidence, `${stem}-independent.json`), JSON.stringify({ language, width, sourceCommit: candidate?.sourceCommit, candidateVersion: candidate?.version, steps, errors }, null, 2));
  136 |    await context.close();
  137 |   }
  138 |  });
  139 | }
  140 | 
```