# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: account-layout-independent.spec.ts >> independent zh-CN 390: AL02 AL03 AL04 AL05 shared consumers
- Location: tests\e2e\account-layout-independent.spec.ts:15:2

# Error details

```
Error: accounts 补齐示例登录条目 touch height

expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 44
Received:    32
```

# Test source

```ts
  1   | import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
  2   | import { join } from "node:path";
  3   | import { expect, test, type Locator } from "@playwright/test";
  4   | import { resources } from "../../apps/web/src/i18n";
  5   | 
  6   | // Independent acceptance: only public navigation/UI, fresh synthetic library per case.
  7   | const evidence = process.env.KEEPANY_INDEPENDENT_EVIDENCE ?? "test-results/account-layout-independent";
  8   | mkdirSync(evidence, { recursive: true });
  9   | const master = "Independent synthetic vault 2026!";
  10  | const longTitle = "Independent synthetic login — long title with readable complete metadata across every consuming container";
  11  | const longUrl = `https://independent.example.test/${"readable-path/".repeat(12)}`;
  12  | const notes = "Synthetic notes only. Every field must remain readable without a narrow value column.\n第二行虚构备注：长内容应完整显示，不裁剪、不丢失。";
  13  | 
  14  | for (const language of ["zh-CN", "en"] as const) for (const width of [390, 768, 1280, 1920, 2560]) {
  15  |  test(`independent ${language} ${width}: AL02 AL03 AL04 AL05 shared consumers`, async ({ browser }) => {
  16  |   test.setTimeout(240_000);
  17  |   const context = await browser.newContext({ viewport: { width, height: 1050 }, locale: language });
  18  |   await context.addInitScript((locale) => localStorage.setItem("keepany-language", locale), language);
  19  |   const page = await context.newPage(); page.setDefaultTimeout(15_000);
  20  |   const t = (key: string) => (resources[language].translation as Record<string, string>)[key] ?? key;
  21  |   const errors: string[] = []; page.on("pageerror", (error) => errors.push(error.message));
  22  |   const steps: object[] = [];
  23  |   const stem = `${language}-${width}`;
  24  |   async function capture(name: string, target?: Locator) {
  25  |    if (target) { await target.scrollIntoViewIfNeeded(); await target.screenshot({ path: join(evidence, `${stem}-${name}.png`) }); }
  26  |    else await page.screenshot({ path: join(evidence, `${stem}-${name}.png`), fullPage: true });
  27  |    steps.push({ step: name, url: page.url(), screenshot: `${stem}-${name}.png` });
  28  |   }
  29  |   async function readable(card: Locator, name: string) {
  30  |    await expect(card).toBeVisible();
  31  |    const metrics = await card.evaluate((node) => {
  32  |     const box = node.getBoundingClientRect();
  33  |     const values = [...node.querySelectorAll<HTMLElement>(".password-vault-value")].map((value) => ({ width: value.getBoundingClientRect().width, scroll: value.scrollWidth, client: value.clientWidth }));
  34  |     const buttons = [...node.querySelectorAll<HTMLElement>(".password-vault-value-actions button")].map((button) => { const r = button.getBoundingClientRect(); return { width: r.width, height: r.height, left: r.left - box.left, right: box.right - r.right }; });
  35  |     return { width: box.width, values, buttons, overflow: document.documentElement.scrollWidth > document.documentElement.clientWidth };
  36  |    });
  37  |    expect(metrics.overflow).toBe(false);
  38  |    for (const value of metrics.values) { expect(value.width).toBeGreaterThan(150); expect(value.scroll).toBeLessThanOrEqual(value.client + 1); }
  39  |    // CSS pixels are subtracted from large scroll coordinates; normalize only
  40  |    // floating point noise (<0.001px), while retaining the 44px requirement.
  41  |    for (const button of metrics.buttons) { expect(Number(button.width.toFixed(3))).toBeGreaterThanOrEqual(44); expect(Number(button.height.toFixed(3))).toBeGreaterThanOrEqual(44); expect(button.left).toBeGreaterThanOrEqual(0); expect(button.right).toBeGreaterThanOrEqual(0); }
  42  |    steps.push({ step: `${name}-geometry`, metrics });
  43  |   }
  44  |   async function toolbarFits(toolbar: Locator, name: string) {
  45  |    const geometry = await toolbar.evaluate((node) => {
  46  |     const box = node.getBoundingClientRect();
  47  |     return { width: box.width, controls: [...node.querySelectorAll<HTMLElement>("button, input")].map((element) => { const rect = element.getBoundingClientRect(); return { label: element.getAttribute("aria-label") ?? element.textContent, tag: element.tagName, left: rect.left - box.left, right: box.right - rect.right, width: rect.width, height: rect.height }; }) };
  48  |    });
  49  |    steps.push({ step: `${name}-toolbar-geometry`, geometry });
  50  |    for (const control of geometry.controls) {
  51  |     expect(Number(control.width.toFixed(3)), `${name} ${control.label} usable width`).toBeGreaterThanOrEqual(control.tag === "INPUT" ? 150 : 44);
> 52  |     expect(Number(control.height.toFixed(3)), `${name} ${control.label} touch height`).toBeGreaterThanOrEqual(44);
      |                                                                                        ^ Error: accounts 补齐示例登录条目 touch height
  53  |     expect(control.left, `${name} ${control.label} left boundary`).toBeGreaterThanOrEqual(-0.001);
  54  |     expect(control.right, `${name} ${control.label} right boundary`).toBeGreaterThanOrEqual(-0.001);
  55  |    }
  56  |   }
  57  |   try {
  58  |    await page.goto("/settings#advanced-settings");
  59  |    await page.getByRole("button", { name: t("loadSample"), exact: true }).click();
  60  |    await expect(page.getByRole("button", { name: t("sampleLibraryPresent"), exact: true })).toBeDisabled();
  61  |    await page.goto("/accounts");
  62  |    const access = page.locator(".unified-vault-access"); await access.locator("summary").click();
  63  |    await page.locator("#password-vault-master").fill(master); await page.locator("#password-vault-master-confirm").fill(master);
  64  |    await page.getByRole("button", { name: t("pwVaultCreate"), exact: true }).click();
  65  |    const toolbar = page.locator(".password-vault-toolbar");
  66  |    const sampleButton = toolbar.getByRole("button", { name: t("sampleLogins"), exact: true });
  67  |    const sampleTextLines = await sampleButton.evaluate((node) => {
  68  |     const walker = document.createTreeWalker(node, NodeFilter.SHOW_TEXT), tops = new Set<number>();
  69  |     while (walker.nextNode()) { const range = document.createRange(); range.selectNodeContents(walker.currentNode); for (const rect of range.getClientRects()) tops.add(Math.round(rect.top)); }
  70  |     return tops.size;
  71  |    });
  72  |    await capture("toolbar-sample-logins", toolbar);
  73  |    await toolbarFits(toolbar, "accounts");
  74  |    expect(sampleTextLines, "AL10 sample action label must not fold into a narrow icon cell").toBe(1);
  75  |    await sampleButton.click();
  76  |    await expect(toolbar.getByRole("button", { name: t("sampleLogins"), exact: true })).toHaveCount(0, { timeout: 30_000 });
  77  |    const categories = page.locator(".unified-account-list").first().locator(".asset-category-scroll > button");
  78  |    const categoryCount = await categories.count();
  79  |    for (let index = 1; index < categoryCount - 1; index++) {
  80  |     await categories.nth(index).click();
  81  |     const accounts = page.locator(".unified-account");
  82  |     if (await accounts.count()) {
  83  |      const account = accounts.first(), disclosure = account.locator(".unified-account-passwords");
  84  |      await disclosure.locator("summary").click(); await expect(disclosure).toHaveJSProperty("open", true);
  85  |      if (await disclosure.locator(".password-vault-entry").count()) await readable(disclosure.locator(".password-vault-entry").first(), `category-${index}`);
  86  |      await capture(`category-${index}-expanded`, account);
  87  |     } else await capture(`category-${index}-empty`);
  88  |    }
  89  |    await categories.first().click();
  90  |    const query = page.getByRole("searchbox", { name: t("accountListSearch"), exact: true });
  91  |    await query.fill("not-an-existent-synthetic-account"); await expect(page.locator(".unified-account")).toHaveCount(0);
  92  |    await capture("filter-empty"); await query.press("Escape"); await expect(page.locator(".unified-account")).toHaveCount(8);
  93  |    await toolbar.getByRole("button", { name: t("pwVaultNewEntry"), exact: true }).click();
  94  |    await page.getByRole("dialog").getByRole("button", { name: t("pwVaultSaveEntry"), exact: true }).click();
  95  |    await expect(page.getByRole("dialog")).toBeVisible(); expect(await page.locator("#password-vault-entry-title").evaluate((node) => (node as HTMLInputElement).validity.valueMissing)).toBe(true);
  96  |    await capture("required-error");
  97  |    await page.locator("#password-vault-entry-title").fill("Cancelled synthetic draft");
  98  |    await page.getByRole("dialog").getByRole("button", { name: t("close"), exact: true }).click();
  99  |    await expect(page.locator(".workspace-password-only")).toHaveCount(0);
  100 |    await toolbar.getByRole("button", { name: t("pwVaultNewEntry"), exact: true }).click();
  101 |    await page.locator("#password-vault-entry-title").fill(longTitle); await page.locator("#password-vault-entry-username").fill("primary-independent@example.test");
  102 |    for (const alias of ["second-independent@example.test", "+1 202-555-0157"]) {
  103 |     await page.getByRole("dialog").getByRole("button", { name: t("pwVaultAddIdentifier"), exact: true }).click(); await page.locator(".pw-smart-identifier-row input").last().fill(alias);
  104 |    }
  105 |    await page.getByRole("dialog").getByRole("button", { name: t("pwVaultAddUrl"), exact: true }).click();
  106 |    await page.locator("#password-vault-entry-url").fill(longUrl); await page.locator("#password-vault-entry-notes").fill(notes);
  107 |    await page.getByRole("dialog").getByRole("button", { name: t("pwVaultSaveEntry"), exact: true }).click();
  108 |    const standalone = page.locator(".workspace-password-only .password-vault-entry");
  109 |    await expect(standalone).toContainText(longTitle); await expect(standalone).toContainText(longUrl); await expect(standalone).toContainText(notes);
  110 |    await readable(standalone, "unlinked"); await expect(standalone.getByRole("button", { name: t("pwVaultRevealPassword"), exact: true })).toBeDisabled();
  111 |    await capture("unlinked-long", standalone);
  112 |    await standalone.getByRole("button", { name: t("pwVaultEditEntry"), exact: true }).click(); await page.locator("#password-vault-entry-title").fill("Cancelled overwrite");
  113 |    await capture("unlinked-editor"); await page.getByRole("dialog").getByRole("button", { name: t("close"), exact: true }).click(); await expect(standalone).toContainText(longTitle);
  114 |    const phoneAccount = page.locator(".unified-account").filter({ has: page.locator(".asset-account-phone") });
  115 |    await phoneAccount.locator(".asset-account-card").click();
  116 |    await page.getByRole("button", { name: t("workspaceShowPasswords"), exact: true }).click();
  117 |    const detail = page.locator(".account-passwords-section");
  118 |    await readable(detail.locator(".password-vault-entry").first(), "detail"); await capture("detail-embedded", detail);
  119 |    await toolbarFits(detail.locator(".password-vault-toolbar"), "detail");
  120 |    await detail.locator(".password-vault-entry").first().getByRole("button", { name: t("pwVaultEditEntry"), exact: true }).click();
  121 |    await page.locator("#password-vault-entry-notes").fill(notes); await page.getByRole("dialog").getByRole("button", { name: t("pwVaultSaveEntry"), exact: true }).click();
  122 |    await expect(detail).toContainText(notes); await page.reload();
  123 |    await page.getByRole("button", { name: t("workspaceShowPasswords"), exact: true }).click();
  124 |    await page.locator("#password-vault-unlock-master").fill("wrong synthetic master"); await page.getByRole("button", { name: t("pwVaultUnlock"), exact: true }).click();
  125 |    await expect(page.locator(".password-vault-message").filter({ hasText: t("pwVaultUnlockFailed") })).toBeVisible(); await capture("detail-unlock-error", page.locator(".account-passwords-section"));
  126 |    await page.locator("#password-vault-unlock-master").fill(master); await page.getByRole("button", { name: t("pwVaultUnlock"), exact: true }).click();
  127 |    await expect(detail).toContainText(notes); await readable(detail.locator(".password-vault-entry").first(), "detail-reloaded");
  128 |    await capture("detail-reloaded", detail);
  129 |    // A full document navigation intentionally locks the in-memory KDBX session.
  130 |    await page.goto("/accounts");
  131 |    await expect(standalone).toHaveCount(0);
  132 |    const reentryAccess = page.locator(".unified-vault-access");
  133 |    if (!await reentryAccess.evaluate((node) => (node as HTMLDetailsElement).open)) await reentryAccess.locator("summary").click();
  134 |    await page.locator("#password-vault-unlock-master").fill(master); await page.getByRole("button", { name: t("pwVaultUnlock"), exact: true }).click();
  135 |    await expect(standalone).toContainText(longTitle); await query.fill(notes); await expect(page.locator(".workspace-password-only")).toHaveCount(0); await query.fill("");
  136 |    await readable(standalone, "unlinked-return"); expect(errors).toEqual([]);
  137 |    steps.push({ step: "finished", errors, result: "passed" });
  138 |   } finally {
  139 |    const candidate = process.env.KEEPANY_PREVIEW_DIRECTORY ? JSON.parse(readFileSync(join(process.env.KEEPANY_PREVIEW_DIRECTORY, "RELEASE.json"), "utf8")) : null;
  140 |    writeFileSync(join(evidence, `${stem}-independent.json`), JSON.stringify({ language, width, sourceCommit: candidate?.sourceCommit, candidateVersion: candidate?.version, steps, errors }, null, 2));
  141 |    await context.close();
  142 |   }
  143 |  });
  144 | }
  145 | 
```