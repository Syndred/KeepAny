import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
let source=readFileSync('tests/e2e/account-layout-independent.spec.ts','utf8').replaceAll('\r\n','\n');
source=source.replace('[390, 768, 1280, 1920, 2560]','[390, 768, 1280, 1536, 1920, 2560]');
source=source.replaceAll('KEEPANY_PREVIEW_DIRECTORY','KEEPANY_INDEPENDENT_PACKAGE_DIR');
source=source.replace('const box = node.getBoundingClientRect();',`const box = node.getBoundingClientRect();
                    const style = getComputedStyle(node);
                    const contentWidth = box.width - parseFloat(style.paddingLeft) - parseFloat(style.paddingRight) - parseFloat(style.borderLeftWidth) - parseFloat(style.borderRightWidth);
                    const firstRow = node.querySelector('.password-vault-value-row')!;
                    const firstValue = firstRow.querySelector('.password-vault-value')!.getBoundingClientRect();
                    const firstActions = firstRow.querySelector('.password-vault-value-actions')!.getBoundingClientRect();
                    const stacked = firstValue.top >= firstActions.bottom - 1;`);
source=source.replace('width: box.width,\n\t\t\t\t\t\tvalues,','width: box.width, contentWidth, stacked, viewportWidth: innerWidth,\n\t\t\t\t\t\tvalues,');
source=source.replace('expect(metrics.overflow).toBe(false);','expect(metrics.overflow).toBe(false);\n                expect(metrics.stacked, `${name} follows frozen 360px content-container boundary`).toBe(metrics.contentWidth <= 360.01);');
source=source.replace('await capture("unlinked-long", standalone);',`await capture("unlinked-long", standalone);
                if (width === 1536) {
                    const originalViewport = page.viewportSize()!;
                    for (const target of [359, 361]) {
                        const before = await standalone.evaluate(node => {
                            const box=node.getBoundingClientRect(),style=getComputedStyle(node);
                            return {content:box.width-parseFloat(style.paddingLeft)-parseFloat(style.paddingRight)-parseFloat(style.borderLeftWidth)-parseFloat(style.borderRightWidth),columns:getComputedStyle(node.parentElement!).gridTemplateColumns.split(/\\s+/).length};
                        });
                        const viewportWidth=Math.round(page.viewportSize()!.width+(target-before.content)*before.columns);
                        await page.setViewportSize({width:viewportWidth,height:originalViewport.height});
                        const actual=await standalone.evaluate(node=>{const b=node.getBoundingClientRect(),s=getComputedStyle(node);return b.width-parseFloat(s.paddingLeft)-parseFloat(s.paddingRight)-parseFloat(s.borderLeftWidth)-parseFloat(s.borderRightWidth)});
                        expect(Math.abs(actual-target), 'normal UI viewport reaches requested content boundary').toBeLessThanOrEqual(1);
                        steps.push({step:'threshold-viewport',target,actual,viewportWidth});
                        await readable(standalone,'unlinked-threshold-'+target);
                        await capture('unlinked-threshold-'+target,standalone);
                    }
                    await page.setViewportSize(originalViewport);
                    await readable(standalone,'unlinked-after-threshold');
                }`);
mkdirSync('test-results/independent-fc11',{recursive:true});
writeFileSync('test-results/independent-fc11/fc11-consumers.spec.ts',source);
