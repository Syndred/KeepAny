import{readFileSync,writeFileSync,mkdirSync}from'node:fs';import{resolve}from'node:path';import{createHash}from'node:crypto';import{spawnSync}from'node:child_process';import{unzipSync,zipSync,strToU8,strFromU8}from'fflate';
const dir='test-results/independent-d2-route-binding';mkdirSync(dir,{recursive:true});const source='docs/qa/2026-10-28/evidence/final-route-recovery/machine-evidence.json',base=JSON.parse(readFileSync(source,'utf8')),sha=b=>createHash('sha256').update(b).digest('hex'),archive=dir+'/mutated-evidence.zip',recordPath=dir+'/record.json',originalFiles=unzipSync(readFileSync(base.archives[0].path)),results=[];
function run(name,mutate,zipChange=false){const r=structuredClone(base),files={...originalFiles};if(zipChange){for(const key of ['recoveries','routes','stableNavigation','history'])for(const ref of r[key])ref.archive=archive;r.archives=[{...r.archives[0],path:archive}];}function raw(key,index,fn){const ref=r[key][index],v=JSON.parse(strFromU8(files[ref.path]));fn(v);const bytes=strToU8(JSON.stringify(v));files[ref.path]=bytes;ref.sha256=sha(bytes);}mutate(r,raw,files);if(zipChange){const b=zipSync(files,{level:0});writeFileSync(archive,b);r.archives[0].sha256=sha(b);}writeFileSync(recordPath,JSON.stringify(r));const p=spawnSync(process.execPath,['scripts/verify-route-history-evidence.mjs',recordPath],{encoding:'utf8',maxBuffer:1024*1024});const text=(p.stdout??'')+(p.stderr??'');results.push({name,exitCode:p.status,expected:name.startsWith('positive')?'pass':'reject',matched:name.startsWith('positive')?p.status===0:p.status!==0,output:text.slice(0,2500)});console.log(name,p.status);writeFileSync(dir+'/results.json',JSON.stringify({source,sourceSha256:sha(readFileSync(source)),scriptSha256:sha(readFileSync('scripts/verify-route-history-evidence.mjs')),results},null,2));}
run('positive-copy',()=>{});run('positive-repacked-exact',()=>{},true);
for(const[name,fn]of[
 ['missing-recovery',r=>r.recoveries.pop()],['duplicate-route-combination',r=>r.routes[1]=r.routes[0]],['wrong-candidate',r=>r.candidate='0'.repeat(40)],['wrong-index',r=>r.indexSha256='0'.repeat(64)],['missing-input',r=>r.testInputs.pop()],['wrong-input-hash',r=>r.testInputs[0].canonicalSha256='0'.repeat(64)],['wrong-identity-hash',r=>r.productIdentity.sha256='0'.repeat(64)]])run(name,fn);
const step=(v,s)=>v.steps.find(x=>x.stage===s);
for(const[name,key,fn]of[
 ['one-manual-reload','recoveries',v=>step(v,'saved-data-preserved').manualRecoveryCount=1],
 ['wrong-error-class','recoveries',v=>step(v,'error-controls').classification='unexpected'],
 ['button-under-44','recoveries',v=>step(v,'error-controls').geometry.button.height=43.99],
 ['nonfinite-null-left','recoveries',v=>step(v,'error-controls').geometry.section.left=null],
 ['heading-outside-viewport','recoveries',v=>step(v,'error-controls').geometry.heading.top=-20],
 ['missing-requestfailed','recoveries',v=>step(v,'failure-observed').failed=[]],
 ['wrong-router-request','routes',v=>step(v.routes[0],'actual-http-module-failure').target='/other.js'],
 ['missing-navigation','routes',v=>v.routes[0].steps=v.routes[0].steps.filter(x=>x.stage!=='error-navigation')],
 ['sidebar-still-open','stableNavigation',v=>step(v.routes[0],'error-navigation').mobileSidebarRight=2],
 ['wrong-history-order','history',v=>v.steps.filter(x=>x.stage==='history').forEach(x=>x.versions?.reverse())],
 ['history-preservation-false','history',v=>step(v,'restored-version-one').previousHistoryPreserved=false],
 ['wrong-png-sha','recoveries',v=>step(v,'screenshot').sha256='0'.repeat(64)],
 ['wrong-case-png-path','recoveries',v=>step(v,'screenshot').path='/other-case/'+step(v,'screenshot').name+'.png'],
 ['missing-state-png','recoveries',v=>v.steps=v.steps.filter(x=>!(x.stage==='screenshot'&&x.name==='failure-1-hover'))]
])run(name,(_,raw)=>raw(key,0,fn),true);
if(results.some(r=>!r.matched))process.exit(1);
