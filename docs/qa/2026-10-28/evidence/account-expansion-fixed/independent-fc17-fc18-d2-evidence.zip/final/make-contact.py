from pathlib import Path
from PIL import Image,ImageOps,ImageDraw,ImageFont
import json,hashlib,math
base=Path('test-results/independent-fc17-d2fd-final');out=base/'contact';out.mkdir(exist_ok=True)
font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',15)
manifest=[]
def sheet(rows,name):
 # Actual error content, cropped at900CSS-pixel equivalent on wide screens;
 # full original viewport originals remain separately available for boundary review.
 w=500;h=245;im=Image.new('RGB',(w*4,h*len(rows)), '#dddddd');draw=ImageDraw.Draw(im)
 for row,shots in enumerate(rows):
  for col,s in enumerate(shots):
   p=Path(s['path']);src=Image.open(p).convert('RGB')
   if s['name'].endswith('-default'):
    g=s['geometry'];left=max(0,int(g['left'])-4);top=max(0,int(g['top'])-4);src=src.crop((left,top,min(src.width,left+900),min(src.height,int(g['bottom'])+4)))
   else:src=src.crop((0,0,min(900,src.width),src.height))
   fitted=ImageOps.contain(src,(w-8,h-32));im.paste(fitted,(col*w+4,row*h+28));draw.text((col*w+5,row*h+5),s['name'][:65],font=font,fill='black');manifest.append({'sheet':name,'source':p.as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'state':s['name']})
 im.save(out/name)
for result in sorted((base/'evidence').glob('*/result.json')):
 r=json.loads(result.read_text('utf-8'));label=result.parent.name
 if 'routes' in r:
  groups=[]
  for route in r['routes']:
   geo=next((s['geometry']['section'] for s in route['steps'] if s['stage']=='error-controls'),None)
   shots=[dict(s,geometry=geo) for s in route['steps'] if s['stage']=='screenshot' and not s['name'].endswith('-normal-navigation')]
   if len(shots)==4:groups.append(shots)
  for start in range(0,len(groups),5):sheet(groups[start:start+5],f'{label}-{start//5}.png')
 else:
  groups=[]
  geos=[s['geometry']['section'] for s in r['steps'] if s['stage']=='error-controls']
  for index,g in enumerate(geos,1):
   shots=[dict(s,geometry=g) for s in r['steps'] if s['stage']=='screenshot' and s['name'].startswith(f'failure-{index}-')]
   if len(shots)==4:groups.append(shots)
  if groups:sheet(groups,f'{label}.png')
(out/'sources.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8');print('sheets',len(list(out.glob('*.png'))),'source frames',len(manifest))
