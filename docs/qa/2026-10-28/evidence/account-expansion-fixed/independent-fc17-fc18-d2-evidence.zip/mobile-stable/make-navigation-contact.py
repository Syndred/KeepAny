from pathlib import Path
from PIL import Image,ImageOps,ImageDraw,ImageFont
import json,hashlib,math
base=Path('test-results/independent-fc17-d2fd-mobile-stable');out=base/'navigation-contact';out.mkdir(exist_ok=True)
font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',14);manifest=[]
for file in sorted((base/'evidence').glob('*-routes/result.json')):
 r=json.loads(file.read_text('utf-8'));shots=[(route,s) for route in r['routes'] for s in route['steps'] if s['stage']=='screenshot' and s['name'].endswith('-normal-navigation')]
 im=Image.new('RGB',(1600,280*math.ceil(len(shots)/4)),'#ddd');d=ImageDraw.Draw(im)
 for n,(route,s) in enumerate(shots):
  src=Image.open(s['path']).convert('RGB');src=src.crop((0,0,src.width,min(src.height,550)));fit=ImageOps.contain(src,(390,250));x=n%4*400;y=n//4*280;im.paste(fit,(x+5,y+25));d.text((x+5,y+4),route['path'][:48],fill='black',font=font);manifest.append({'sheet':file.parent.name+'.png','source':s['path'],'sha256':hashlib.sha256(Path(s['path']).read_bytes()).hexdigest()})
 im.save(out/(file.parent.name+'.png'))
(out/'sources.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8');print(len(manifest),'normal navigation frames')
