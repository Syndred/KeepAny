# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: fc08-independent.spec.ts >> en 390 six FC08 menu consumers
- Location: test-results\fc08-independent.spec.ts:5:77

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('dialog', { name: 'pwSmartModelDetails', exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('dialog', { name: 'pwSmartModelDetails', exact: true }) with timeout 5000ms
  - waiting for getByRole('dialog', { name: 'pwSmartModelDetails', exact: true })

```

```yaml
- complementary:
  - navigation "Navigation":
    - status
- dialog "Model details":
  - banner:
    - heading "Model details" [level=2]
    - button "Close"
  - strong: keepany-synthetic-model
  - text: http://127.0.0.1:61542/v1
  - paragraph: This entire list will be sent, including usernames, passwords and notes.
  - paragraph: Your existing vault and master password will not be sent.
  - button "Cancel"
```

# Test source

```ts
  1  | import { expect, test, type Locator } from '@playwright/test';
  2  | import { mkdirSync,writeFileSync } from 'node:fs';
  3  | import {join} from 'node:path';
  4  | import { visualHarness, recognitionFixture } from '../tests/e2e/fixtures/password-smart-import-visual';
  5  | for(const locale of ['zh-CN','en'] as const) for(const width of [390,1280]) test(`${locale} ${width} six FC08 menu consumers`,async({browser})=>{
  6  |  test.setTimeout(120000);
  7  |  const h=await visualHarness(browser,locale,{width,height:900});
  8  |  const evidence=process.env.KEEPANY_INDEPENDENT_EVIDENCE!;mkdirSync(evidence,{recursive:true});
  9  |  const metrics:unknown[]=[];
  10 |  async function menu(trigger:Locator,name:string,value:string|RegExp){
  11 |   await expect(trigger).toBeVisible();const anchor=await trigger.boundingBox();if(!anchor)throw Error('missing anchor');await trigger.click();
  12 |   const popup=h.page.locator('.themed-select-content.pw-smart-select-menu[data-open]:visible');await expect(popup).toHaveCount(1);await expect(popup).toBeVisible();
  13 |   const geometry=await popup.evaluate(n=>{const b=n.getBoundingClientRect(),l=n.querySelector('[role="listbox"]')!;return {width:b.width,left:b.left,right:b.right,viewport:innerWidth,overflow:l.scrollWidth>l.clientWidth,anchor:getComputedStyle(n).getPropertyValue('--anchor-width')};});
  14 |   expect(geometry.width).toBeGreaterThanOrEqual(Math.min(220,width-32)-1);expect(geometry.width).toBeLessThanOrEqual(width-32+1);expect(geometry.left).toBeGreaterThanOrEqual(0);expect(geometry.right).toBeLessThanOrEqual(width);expect(geometry.overflow).toBe(false);
  15 |   expect(Math.abs(geometry.width-Math.min(Math.max(220,anchor.width),width-32))).toBeLessThanOrEqual(1);
  16 |   await h.page.screenshot({path:join(evidence,`${locale}-${width}-${name}-open.png`)});metrics.push({name,geometry,anchorWidth:anchor.width});
  17 |   const option=typeof value==='string'?popup.locator(`[role="option"][data-value="${value}"]`):popup.getByRole('option',{name:value});await option.click();await expect(popup).toHaveCount(0);
  18 |  }
  19 |  try{
  20 |   await h.configure();await h.createVault();await h.seedExisting({title:'FC08 existing',username:'fc08-owner@example.test',password:'Synthetic-before!42'});
  21 |   const importer=await h.open();const fixture=recognitionFixture([{title:'FC08 existing',username:'fc08-owner@example.test',password:'Synthetic-after!42'},{title:'FC08 new',username:'fc08-new@example.test',password:'Synthetic-new!42'}]);
  22 |   h.mock.responses.push(fixture.response);await importer.locator('#pw-smart-source').fill(fixture.source+'\nSynthetic standalone fragment');
  23 |   await importer.getByRole('button',{name:/^(用 AI 识别|用 .* 识别清单|Recognize with AI|Use AI|Recognize list with .*)$/,exact:true}).click();
  24 |   await h.page.getByRole('button',{name:/^(确认识别|Confirm recognition)$/,exact:true}).click();await expect(importer.locator('.pw-work-list-row')).toHaveCount(3);
  25 |   await menu(h.page.getByRole('combobox',{name:/^(其他输入方式|Other input methods)$/,exact:true}),'input-methods','mapping');await expect(importer.locator('#pw-map-field-1')).toBeVisible();
  26 |   await menu(importer.locator('#pw-map-field-1'),'mapping-field','title');await expect(importer.locator('#pw-map-field-1')).toHaveAttribute('data-value','title');
  27 |   await importer.getByRole('button',{name:h.t('pwSmartBackToReview'),exact:true}).click();
  28 |   await importer.locator('.pw-work-list-row').filter({hasText:'fc08-owner@example.test'}).click();
  29 |   const saveMethod=importer.locator('.pw-work-editor').getByRole('combobox',{name:locale==='zh-CN'?'保存方式':'Save method',exact:true});
  30 |   await menu(saveMethod,'conflict-save',locale==='zh-CN'?/^更新 /:/^Update /);await expect(saveMethod).toHaveAttribute('data-value',/^update:/);
  31 |   await menu(importer.getByRole('combobox',{name:locale==='zh-CN'?'更多':'More',exact:true}),'workspace-more','all');await expect(importer.locator('.pw-import-workspace')).toHaveAttribute('data-view','all');
  32 |   await importer.locator('.pw-work-list-row[data-source-group]').click();const form=importer.locator('.pw-work-fragment:not([hidden]) .pw-smart-fragment-form');await expect(form).toBeVisible();
  33 |   await form.getByRole('button',{name:h.t('pwSmartFragmentChangeTarget'),exact:true}).click();await menu(form.locator('[id$="-target"]'),'fragment-target','new');await expect(form).toHaveAttribute('data-completion-target','new');
  34 |   await menu(h.page.getByRole('combobox',{name:/^(导入操作菜单|Import actions)$/,exact:true}),'import-actions','model');
> 35 |   const details=h.page.getByRole('dialog',{name:h.t('pwSmartModelDetails'),exact:true});await expect(details).toBeVisible();await details.getByRole('button',{name:locale==='zh-CN'?'关闭':'Close',exact:true}).click();await expect(details).toHaveCount(0);
     |                                                                                                               ^ Error: expect(locator).toBeVisible() failed
  36 |   await h.page.screenshot({path:join(evidence,`${locale}-${width}-after-actions.png`)});expect(h.errors).toEqual([]);
  37 |  }finally{writeFileSync(join(evidence,`${locale}-${width}-metrics.json`),JSON.stringify(metrics,null,2));await h.close();}
  38 | });
  39 | 
```