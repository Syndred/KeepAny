# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: password-smart-import-visual.spec.ts >> zh-CN duplicate conflict bulk tools save and draft close confirmations
- Location: tests\e2e\password-smart-import-visual.spec.ts:544:1

# Error details

```
Error: expect(locator).toHaveCSS(expected) failed

Locator:  getByRole('listbox')
Expected: "220px"
Received: "145px"
Timeout:  5000ms

Call log:
  - Expect "toHaveCSS" getByRole('listbox') with timeout 5000ms
  - waiting for getByRole('listbox')
    13 × locator resolved to <div role="listbox" id="base-ui-_r_2l_-list" class="themed-select-viewport base-ui-disable-scrollbar">…</div>
       - unexpected value "145px"

```

```yaml
- listbox:
  - option "查看全部条目"
  - option "查看重复条目"
  - option "整理网站名称" [disabled]
```

# Test source

```ts
  488 | 			})
  489 | 			.check();
  490 | 		await evidence.capture(
  491 | 			"05-B",
  492 | 			"Two explicit starts split two independent accounts; blank and explanatory lines remain numbered.",
  493 | 		);
  494 | 		await importer
  495 | 			.getByRole("button", { name: h.t("pwSmartMapReview"), exact: true })
  496 | 			.click();
  497 | 		await importer.getByRole("tab", { name: /已核对/ }).click();
  498 | 		await expect(importer.locator(".pw-work-list-row")).toHaveCount(2);
  499 | 		await field(importer, "notes").fill("Synthetic review draft remains");
  500 | 		await goInput(importer);
  501 | 		await importer.locator("#pw-smart-source").fill(`${source}\nExtra note`);
  502 | 		await expect(importer).toContainText(h.t("pwSmartSourceChangedHint"));
  503 | 		await evidence.capture(
  504 | 			"05-D",
  505 | 			"Changing source displays replacement warning while preserving the existing review.",
  506 | 		);
  507 | 		await importer
  508 | 			.getByRole("button", { name: h.t("pwSmartBackToReview"), exact: true })
  509 | 			.click();
  510 | 		await expect(field(importer, "notes")).toHaveValue(
  511 | 			"Synthetic review draft remains",
  512 | 		);
  513 | 		await goInput(importer);
  514 | 		await importer
  515 | 			.locator("#pw-smart-source")
  516 | 			.fill("New service\nnew@example.com\nDemo-only-new!42");
  517 | 		await h.page
  518 | 			.getByRole("combobox", { name: "其他输入方式", exact: true })
  519 | 			.click();
  520 | 		await h.page
  521 | 			.getByRole("option", { name: h.t("pwSmartMap"), exact: true })
  522 | 			.click();
  523 | 		// Existing mapping choices intentionally remain until edited; explicitly set the current rows.
  524 | 		for (const [number, value] of [
  525 | 			[1, "title"],
  526 | 			[2, "username"],
  527 | 			[3, "password"],
  528 | 		] as const) {
  529 | 			await selectChoice(importer.locator(`#pw-map-field-${number}`), value);
  530 | 		}
  531 | 		await importer
  532 | 			.getByRole("button", { name: h.t("pwSmartMapAdd"), exact: true })
  533 | 			.click();
  534 | 		await evidence.capture(
  535 | 			"05-C",
  536 | 			"Mapped entries append to the existing review batch.",
  537 | 		);
  538 | 		expect(h.errors).toEqual([]);
  539 | 	} finally {
  540 | 		await h.close();
  541 | 	}
  542 | });
  543 | 
  544 | test("zh-CN duplicate conflict bulk tools save and draft close confirmations", async ({
  545 | 	browser,
  546 | }, info) => {
  547 | 	const h = await visualHarness(browser, "zh-CN");
  548 | 	const evidence = visualEvidence(h.page, info, "zh-CN");
  549 | 	try {
  550 | 		const importer = await seedMain(h);
  551 | 		await row(importer, "team@example.com").click();
  552 | 		await editor(importer)
  553 | 			.getByRole("combobox", { name: "保存方式", exact: true })
  554 | 			.click();
  555 | 		await evidence.capture(
  556 | 			"07-B",
  557 | 			"A password conflict defaults to skip and requires an explicit save action.",
  558 | 		);
  559 | 		await h.page.getByRole("option", { name: /更新 Notion/ }).click();
  560 | 		await expect(editor(importer)).toContainText("将保留旧密码历史");
  561 | 		await evidence.capture(
  562 | 			"07-C",
  563 | 			"Update is tied to the selected existing Notion identity.",
  564 | 		);
  565 | 		await field(importer, "password").fill(visualOldNotionPassword);
  566 | 		await field(importer, "notes").fill("Synthetic metadata-only update");
  567 | 		await editor(importer)
  568 | 			.getByRole("combobox", { name: "保存方式", exact: true })
  569 | 			.click();
  570 | 		await evidence.capture(
  571 | 			"07-D",
  572 | 			"Same-password metadata changes use explicit update, never a duplicated entry.",
  573 | 		);
  574 | 		await h.page.keyboard.press("Escape");
  575 | 		await importer
  576 | 			.getByRole("button", { name: "批量核对", exact: true })
  577 | 			.click();
  578 | 		await evidence.capture(
  579 | 			"08-A",
  580 | 			"Batch selection excludes missing fields and identity conflicts.",
  581 | 		);
  582 | 		await h.page
  583 | 			.getByRole("dialog")
  584 | 			.last()
  585 | 			.getByRole("button", { name: "返回", exact: true })
  586 | 			.click();
  587 | 		await importer.getByRole("combobox", { name: "更多", exact: true }).click();
> 588 | 		await expect(h.page.getByRole("listbox")).toHaveCSS("width", "220px");
      |                                             ^ Error: expect(locator).toHaveCSS(expected) failed
  589 | 		await evidence.capture(
  590 | 			"08-B",
  591 | 			"More actions use the existing custom themed menu.",
  592 | 		);
  593 | 		await expect(
  594 | 			h.page.getByRole("option", { name: "整理网站名称", exact: true }),
  595 | 		).toHaveAttribute("aria-disabled", "true");
  596 | 		await h.page.keyboard.press("Escape");
  597 | 		await importer.getByRole("button", { name: /导入已核对的 \d+ 条/ }).click();
  598 | 		await evidence.capture(
  599 | 			"09-A",
  600 | 			"Final confirmation shows current add/update counts before KDBX write.",
  601 | 		);
  602 | 		await h.page
  603 | 			.getByRole("dialog")
  604 | 			.last()
  605 | 			.getByRole("button", { name: "确认导入", exact: true })
  606 | 			.click();
  607 | 		await expect(importer.locator(".pw-smart-receipt")).toBeVisible();
  608 | 		await evidence.capture(
  609 | 			"09-B",
  610 | 			"A successful atomic batch leaves pending candidates available in the same dialog.",
  611 | 		);
  612 | 		await h.page
  613 | 			.getByRole("combobox", { name: "导入操作菜单", exact: true })
  614 | 			.click();
  615 | 		await expect(h.page.getByRole("listbox")).toHaveCSS("width", "220px");
  616 | 		await evidence.capture(
  617 | 			"11-A",
  618 | 			"Import actions exposes model details and lock-close.",
  619 | 			undefined,
  620 | 			"-menu",
  621 | 		);
  622 | 		await h.page.getByRole("option", { name: "模型详情", exact: true }).click();
  623 | 		await evidence.capture(
  624 | 			"11-A",
  625 | 			"Model details show the configured model and endpoint.",
  626 | 			undefined,
  627 | 			"-details",
  628 | 		);
  629 | 		await h.page
  630 | 			.getByRole("dialog")
  631 | 			.last()
  632 | 			.getByRole("button", { name: "关闭", exact: true })
  633 | 			.click();
  634 | 		await lockImport(h.page);
  635 | 		await evidence.capture(
  636 | 			"10-B",
  637 | 			"Lock-close confirms clearing only this unimported draft.",
  638 | 		);
  639 | 		await h.page
  640 | 			.getByRole("dialog")
  641 | 			.last()
  642 | 			.getByRole("button", { name: "取消", exact: true })
  643 | 			.click();
  644 | 		await h.page
  645 | 			.getByRole("dialog", { name: h.t("pwSmartTitle"), exact: true })
  646 | 			.getByRole("button", { name: "关闭", exact: true })
  647 | 			.click();
  648 | 		await evidence.capture(
  649 | 			"10-A",
  650 | 			"Closing a nonempty draft requires clear-draft confirmation.",
  651 | 		);
  652 | 		await h.page
  653 | 			.getByRole("dialog")
  654 | 			.last()
  655 | 			.getByRole("button", { name: "关闭并清空", exact: true })
  656 | 			.click();
  657 | 		await h.open();
  658 | 		await expect(importer.locator("#pw-smart-source")).toHaveValue("");
  659 | 		expect(h.errors).toEqual([]);
  660 | 	} finally {
  661 | 		await h.close();
  662 | 	}
  663 | });
  664 | 
  665 | async function closeImport(page: Page, t: (key: string) => string) {
  666 | 	await page
  667 | 		.getByRole("dialog", { name: t("pwSmartTitle"), exact: true })
  668 | 		.getByRole("button", { name: /^(关闭|Close)$/, exact: true })
  669 | 		.first()
  670 | 		.click();
  671 | 	const confirm = page.getByRole("button", {
  672 | 		name: /^(关闭并清空|Close and clear)$/,
  673 | 		exact: true,
  674 | 	});
  675 | 	if (await confirm.isVisible()) await confirm.click();
  676 | 	await expect(page.locator(".password-smart-import")).toHaveCount(0);
  677 | }
  678 | async function localRecognize(
  679 | 	h: Awaited<ReturnType<typeof visualHarness>>,
  680 | 	importer: Locator,
  681 | 	source: string,
  682 | ) {
  683 | 	await importer.locator("#pw-smart-source").fill(source);
  684 | 	await importer
  685 | 		.getByRole("button", { name: h.t("pwSmartRecognize"), exact: true })
  686 | 		.click();
  687 | }
  688 | async function confirmSave(page: Page, importer: Locator) {
```