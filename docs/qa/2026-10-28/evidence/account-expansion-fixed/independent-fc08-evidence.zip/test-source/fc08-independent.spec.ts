import { expect, test, type Locator } from '@playwright/test';
import { mkdirSync,writeFileSync } from 'node:fs';
import {join} from 'node:path';
import { visualHarness, recognitionFixture } from '../tests/e2e/fixtures/password-smart-import-visual';
for(const locale of ['zh-CN','en'] as const) for(const width of [390,1280]) test(`${locale} ${width} six FC08 menu consumers`,async({browser})=>{
 test.setTimeout(120000);
 const h=await visualHarness(browser,locale,{width,height:900});
 const evidence=process.env.KEEPANY_INDEPENDENT_EVIDENCE!;mkdirSync(evidence,{recursive:true});
 const metrics:unknown[]=[];
 async function menu(trigger:Locator,name:string,value:string|RegExp){
  await expect(trigger).toBeVisible();const anchor=await trigger.boundingBox();if(!anchor)throw Error('missing anchor');await trigger.click();
  const popup=h.page.locator('.themed-select-content.pw-smart-select-menu[data-open]:visible');await expect(popup).toHaveCount(1);await expect(popup).toBeVisible();
  const geometry=await popup.evaluate(n=>{const b=n.getBoundingClientRect(),l=n.querySelector('[role="listbox"]')!;return {width:b.width,left:b.left,right:b.right,top:b.top,bottom:b.bottom,viewport:innerWidth,viewportHeight:innerHeight,overflow:l.scrollWidth>l.clientWidth,anchor:getComputedStyle(n).getPropertyValue('--anchor-width')};});
  expect(geometry.width).toBeGreaterThanOrEqual(Math.min(220,width-32)-1);expect(geometry.width).toBeLessThanOrEqual(width-32+1);expect(geometry.left).toBeGreaterThanOrEqual(0);expect(geometry.right).toBeLessThanOrEqual(width);expect(geometry.overflow).toBe(false);
  expect(Math.abs(geometry.width-Math.min(Math.max(220,anchor.width),width-32))).toBeLessThanOrEqual(1);expect(geometry.top).toBeGreaterThanOrEqual(0);expect(geometry.bottom).toBeLessThanOrEqual(geometry.viewportHeight);
  await h.page.screenshot({path:join(evidence,`${locale}-${width}-${name}-open.png`)});metrics.push({name,geometry,anchorWidth:anchor.width});
  const option=typeof value==='string'?popup.locator(`[role="option"][data-value="${value}"]`):popup.getByRole('option',{name:value});await option.click();await expect(popup).toHaveCount(0);
 }
 try{
  await h.configure();await h.createVault();await h.seedExisting({title:'FC08 existing',username:'fc08-owner@example.test',password:'Synthetic-before!42'});
  const importer=await h.open();const fixture=recognitionFixture([{title:'FC08 existing',username:'fc08-owner@example.test',password:'Synthetic-after!42'},{title:'FC08 new',username:'fc08-new@example.test',password:'Synthetic-new!42'}]);
  h.mock.responses.push(fixture.response);await importer.locator('#pw-smart-source').fill(fixture.source+'\nSynthetic standalone fragment');
  await importer.getByRole('button',{name:/^(用 AI 识别|用 .* 识别清单|Recognize with AI|Use AI|Recognize list with .*)$/,exact:true}).click();
  await h.page.getByRole('button',{name:/^(确认识别|Confirm recognition)$/,exact:true}).click();await expect(importer.locator('.pw-work-list-row')).toHaveCount(3);
  await menu(h.page.getByRole('combobox',{name:/^(其他输入方式|Other input methods)$/,exact:true}),'input-methods','mapping');await expect(importer.locator('#pw-map-field-1')).toBeVisible();
  await menu(importer.locator('#pw-map-field-1'),'mapping-field','title');await expect(importer.locator('#pw-map-field-1')).toHaveAttribute('data-value','title');
  await importer.getByRole('button',{name:h.t('pwSmartBackToReview'),exact:true}).click();
  await importer.locator('.pw-work-list-row').filter({hasText:'fc08-owner@example.test'}).click();
  const saveMethod=importer.locator('.pw-work-editor').getByRole('combobox',{name:locale==='zh-CN'?'保存方式':'Save method',exact:true});
  await menu(saveMethod,'conflict-save',locale==='zh-CN'?/^更新 /:/^Update /);await expect(saveMethod).toHaveAttribute('data-value',/^update:/);
  await menu(importer.getByRole('combobox',{name:locale==='zh-CN'?'更多':'More',exact:true}),'workspace-more','all');await expect(importer.locator('.pw-import-workspace')).toHaveAttribute('data-view','all');
  await importer.locator('.pw-work-list-row[data-source-group]').click();const form=importer.locator('.pw-work-fragment:not([hidden]) .pw-smart-fragment-form');await expect(form).toBeVisible();
  await form.getByRole('button',{name:h.t('pwSmartFragmentChangeTarget'),exact:true}).click();await menu(form.locator('[id$="-target"]'),'fragment-target',/FC08 existing/);await expect(form).not.toHaveAttribute('data-completion-target','new');await expect(form.locator('[id$="-title"]')).toHaveValue('FC08 existing');
  await menu(h.page.getByRole('combobox',{name:/^(导入操作菜单|Import actions)$/,exact:true}),'import-actions','model');
  const details=h.page.getByRole('dialog',{name:locale==='zh-CN'?'模型详情':'Model details',exact:true});await expect(details).toBeVisible();await details.getByRole('button',{name:locale==='zh-CN'?'关闭':'Close',exact:true}).click();await expect(details).toHaveCount(0);
  await h.page.screenshot({path:join(evidence,`${locale}-${width}-after-actions.png`)});expect(h.errors).toEqual([]);
 }finally{writeFileSync(join(evidence,`${locale}-${width}-metrics.json`),JSON.stringify(metrics,null,2));await h.close();}
});
