# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: account-unlink-focus.spec.ts >> zh-CN 390px filtered unlink preserves entries and visible continuation focus
- Location: tests\e2e\account-unlink-focus.spec.ts:12:3

# Error details

```
Error: expect(locator).toBeFocused() failed

Locator:  locator('.password-vault-entry-list .password-vault-entry').filter({ has: getByRole('heading', { name: 'FC07 filtered login', exact: true }) })
Expected: focused
Received: inactive
Timeout:  5000ms

Call log:
  - Expect "toBeFocused" locator('.password-vault-entry-list .password-vault-entry').filter({ has: getByRole('heading', { name: 'FC07 filtered login', exact: true }) }) with timeout 5000ms
  - waiting for locator('.password-vault-entry-list .password-vault-entry').filter({ has: getByRole('heading', { name: 'FC07 filtered login', exact: true }) })
    14 × locator resolved to <article tabindex="-1" class="task-card password-vault-entry" data-entry-id="jDCldEM6CN5x4Mzqdzv1rw==">…</article>
       - unexpected value "inactive"

```

```yaml
- article:
  - heading "FC07 filtered login" [level=2]
  - text: 修改于 10月28日 19:41
  - term: 账号
  - definition: synthetic-owner@example.test
  - definition
  - term: 密码
  - definition: ••••••••••••
  - definition
  - term: 备注
  - definition: Synthetic linked note
  - definition
  - img "关联资产"
  - link "FC07 filtered account":
    - /url: /assets/account/26961cb2-93e1-4584-a837-ff2aaeecf1bd#account-relations
  - button "解除与 FC07 filtered account 的关联": 解除关联
  - button "新增同平台账号"
  - button "编辑"
  - button "历史版本"
  - button "移入回收站"
```

# Test source

```ts
  1   | import { createHash } from "node:crypto";
  2   | import { mkdirSync, writeFileSync } from "node:fs";
  3   | import { join } from "node:path";
  4   | import { expect, test } from "@playwright/test";
  5   | import { resources } from "../../apps/web/src/i18n";
  6   | import { openVaultAccess } from "./helpers/vault-access";
  7   | 
  8   | const master = "Synthetic filtered unlink acceptance 2026!";
  9   | 
  10  | for (const language of ["zh-CN", "en"] as const) {
  11  | 	for (const width of [390, 1280]) {
  12  | 		test(`${language} ${width}px filtered unlink preserves entries and visible continuation focus`, async ({ browser }, info) => {
  13  | 			test.setTimeout(120_000);
  14  | 			const context = await browser.newContext({ locale: language, viewport: { width, height: 900 } });
  15  | 			await context.addInitScript(value => localStorage.setItem("keepany-language", value), language);
  16  | 			const page = await context.newPage();
  17  | 			const t = (key: string) => (resources[language].translation as Record<string, string>)[key] ?? key;
  18  | 			const evidence = process.env.KEEPANY_EVIDENCE_DIR ?? info.outputPath("evidence");
  19  | 			mkdirSync(evidence, { recursive: true });
  20  | 			const stem = `filtered-unlink-${language}-${width}`;
  21  | 			const observations: unknown[] = [];
  22  | 			const errors: string[] = [];
  23  | 			page.on("pageerror", error => errors.push(error.message));
  24  | 			const accountName = "FC07 filtered account";
  25  | 			const linkedTitle = "FC07 filtered login";
  26  | 			const otherTitle = "FC07 adjacent login";
  27  | 			const entries = page.locator(".password-vault-entry-list .password-vault-entry");
  28  | 			const card = (title: string) => entries.filter({ has: page.getByRole("heading", { name: title, exact: true }) });
  29  | 			async function observe(stage: string) {
  30  | 				observations.push({ stage, ...await page.evaluate(() => {
  31  | 					const active = document.activeElement as HTMLElement | null;
  32  | 					const rect = active?.getBoundingClientRect();
  33  | 					return { url: location.href, active: { tag: active?.tagName, id: active?.id, entryId: active?.closest<HTMLElement>("[data-entry-id]")?.dataset.entryId, rect: rect && { top: rect.top, bottom: rect.bottom } }, filter: !!document.querySelector(".password-vault-filter"), entryIds: [...document.querySelectorAll<HTMLElement>(".password-vault-entry-list .password-vault-entry")].map(node => node.dataset.entryId) };
  34  | 				}) });
  35  | 			}
  36  | 			async function saveEntry(title: string, notes: string) {
  37  | 				await page.locator("#password-vault-entry-title").fill(title);
  38  | 				await page.locator("#password-vault-entry-username").fill("synthetic-owner@example.test");
  39  | 				await page.locator("#password-vault-entry-password").fill("Synthetic-only-secret!42");
  40  | 				await page.locator("#password-vault-entry-notes").fill(notes);
  41  | 				await page.getByRole("dialog").getByRole("button", { name: t("pwVaultSaveEntry"), exact: true }).click();
  42  | 				await expect(page.getByRole("dialog")).toHaveCount(0);
  43  | 			}
  44  | 			try {
  45  | 				await page.goto("/accounts");
  46  | 				const html = await (await page.request.get("/")).text();
  47  | 				observations.push({ stage: "candidate-entry", origin: new URL(page.url()).origin, indexSha256: createHash("sha256").update(html).digest("hex"), scripts: [...html.matchAll(/<script[^>]*src="([^"]+)"/g)].map(match => match[1]) });
  48  | 				await page.getByRole("main").getByRole("button", { name: t("add"), exact: true }).click();
  49  | 				const accountEditor = page.getByRole("dialog");
  50  | 				await accountEditor.locator("#name").fill(accountName);
  51  | 				await accountEditor.locator("#username").fill("synthetic-account@example.test");
  52  | 				await accountEditor.getByRole("button", { name: t("save"), exact: true }).click();
  53  | 				await expect(accountEditor).toHaveCount(0);
  54  | 				await openVaultAccess(page);
  55  | 				await page.locator("#password-vault-master").fill(master);
  56  | 				await page.locator("#password-vault-master-confirm").fill(master);
  57  | 				await page.getByRole("button", { name: t("pwVaultCreate"), exact: true }).click();
  58  | 				const account = page.locator(".unified-account").filter({ hasText: accountName });
  59  | 				await expect(account).toHaveCount(1);
  60  | 				const disclosure = account.locator(".unified-account-passwords");
  61  | 				await expect(disclosure).toBeVisible();
  62  | 				if (!(await disclosure.evaluate(node => (node as HTMLDetailsElement).open))) await disclosure.locator(":scope > summary").click();
  63  | 				await disclosure.getByRole("button", { name: t("pwVaultNewEntry"), exact: true }).click();
  64  | 				await saveEntry(linkedTitle, "Synthetic linked note");
  65  | 				await expect(card(linkedTitle)).toBeVisible();
  66  | 				const linkedId = await card(linkedTitle).getAttribute("data-entry-id");
  67  | 				expect(linkedId).toBeTruthy();
  68  | 				await page.locator(".password-vault-toolbar").getByRole("button", { name: t("pwVaultNewEntry"), exact: true }).click();
  69  | 				await saveEntry(otherTitle, "Before adjacent edit");
  70  | 				await expect(entries).toHaveCount(2);
  71  | 				await account.locator("a.asset-account-card").click();
  72  | 				await expect(page.getByRole("heading", { level: 1, name: accountName, exact: true })).toBeVisible();
  73  | 				await page.getByRole("link", { name: t("accountOpenPasswords"), exact: true }).click();
  74  | 				await expect(page).toHaveURL(/#asset-/);
  75  | 				const filter = page.locator(".password-vault-filter");
  76  | 				const clearFilter = filter.getByRole("button", { name: t("pwVaultClearAssetFilter"), exact: true });
  77  | 				await expect(filter).toContainText(accountName);
  78  | 				await expect(entries).toHaveCount(1);
  79  | 				await expect(card(linkedTitle)).toHaveAttribute("data-entry-id", linkedId!);
  80  | 				await card(linkedTitle).locator(".password-vault-linked-connection").getByRole("button").click();
  81  | 				await page.getByRole("dialog").getByRole("button", { name: t("cancel"), exact: true }).click();
  82  | 				await expect(page.getByRole("dialog")).toHaveCount(0);
  83  | 				await expect(card(linkedTitle).locator(".password-vault-linked-connection")).toHaveCount(1);
> 84  | 				await expect(card(linkedTitle)).toBeFocused();
      |                                     ^ Error: expect(locator).toBeFocused() failed
  85  | 				await observe("cancel-keeps-link-and-filter");
  86  | 				await card(linkedTitle).locator(".password-vault-linked-connection").getByRole("button").click();
  87  | 				await page.getByRole("dialog").getByRole("button", { name: t("pwVaultUnlink"), exact: true }).click();
  88  | 				await expect(page.getByRole("dialog")).toHaveCount(0);
  89  | 				await expect(entries).toHaveCount(0);
  90  | 				await expect(filter).toContainText(accountName);
  91  | 				await expect(page.locator(".password-vault-empty")).toBeVisible();
  92  | 				await observe("confirmed-empty-filter");
  93  | 				await page.screenshot({ path: join(evidence, `${stem}-empty-filter.png`) });
  94  | 				await expect(clearFilter).toBeFocused();
  95  | 				await expect(clearFilter).toBeInViewport();
  96  | 				await clearFilter.click();
  97  | 				await expect(filter).toHaveCount(0);
  98  | 				await expect(entries).toHaveCount(2);
  99  | 				await expect(card(linkedTitle)).toHaveAttribute("data-entry-id", linkedId!);
  100 | 				await expect(card(linkedTitle).locator(".password-vault-linked-connection")).toHaveCount(0);
  101 | 				await card(otherTitle).getByRole("button", { name: t("pwVaultEditEntry"), exact: true }).click();
  102 | 				await page.locator("#password-vault-entry-notes").fill("After adjacent edit without delayed focus");
  103 | 				await page.getByRole("dialog").getByRole("button", { name: t("pwVaultSaveEntry"), exact: true }).click();
  104 | 				await expect(page.getByRole("dialog")).toHaveCount(0);
  105 | 				await expect(card(otherTitle)).toContainText("After adjacent edit without delayed focus");
  106 | 				await page.evaluate(() => new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
  107 | 				await expect(card(linkedTitle)).not.toBeFocused();
  108 | 				await observe("adjacent-save-no-late-focus");
  109 | 				await page.locator(".unified-account a.asset-account-card").click();
  110 | 				await page.getByRole("link", { name: t("accountOpenPasswords"), exact: true }).click();
  111 | 				await expect(entries).toHaveCount(0);
  112 | 				await page.reload();
  113 | 				await openVaultAccess(page);
  114 | 				await page.locator("#password-vault-unlock-master").fill(master);
  115 | 				await page.getByRole("button", { name: t("pwVaultUnlock"), exact: true }).click();
  116 | 				await expect(filter).toContainText(accountName);
  117 | 				await expect(entries).toHaveCount(0);
  118 | 				await expect(clearFilter).toBeVisible();
  119 | 				await clearFilter.click();
  120 | 				await expect(entries).toHaveCount(2);
  121 | 				await expect(card(linkedTitle)).toHaveAttribute("data-entry-id", linkedId!);
  122 | 				await expect(card(linkedTitle).locator(".password-vault-linked-connection")).toHaveCount(0);
  123 | 				await expect(card(otherTitle)).toContainText("After adjacent edit without delayed focus");
  124 | 				await expect(page.locator(".unified-account")).toHaveCount(1);
  125 | 				await observe("refresh-and-unlock-retains-data");
  126 | 				await page.screenshot({ path: join(evidence, `${stem}-retained.png`) });
  127 | 				expect(errors).toEqual([]);
  128 | 			} finally {
  129 | 				writeFileSync(join(evidence, `${stem}.json`), JSON.stringify({ language, width, observations, errors }, null, 2));
  130 | 				await context.close();
  131 | 			}
  132 | 		});
  133 | 	}
  134 | }
  135 | 
```