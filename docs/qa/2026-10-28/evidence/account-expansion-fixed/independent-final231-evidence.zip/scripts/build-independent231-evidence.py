from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json,hashlib
repo=Path.cwd();base=repo/'test-results/account-layout-independent/final231';folder='docs/qa/2026-10-28/evidence/account-expansion-fixed';dest=folder+'/independent-final231-evidence.zip';coveragePath=folder+'/independent-final231-state-coverage.json';sha=lambda b:hashlib.sha256(b).hexdigest();files={}
for p in base.rglob('*'):
 if p.is_file() and p.suffix in ['.json','.png','.jpg','.md','.ts','.zip','.log'] and not any(x.startswith('.playwright') for x in p.parts):files[p.relative_to(base).as_posix()]=p.read_bytes()
for n in ['run-independent231.mjs','independent231-consumers.config.ts','independent231-sw.spec.ts','independent231-sw.config.ts','fc12-independent.spec.ts','independent-fc12.config.ts','fc11-busy-65ce.spec.ts','fc11-busy-65ce-clip.spec.ts','independent-busy-65ce.config.ts','independent-busy-clip.config.ts','independent-social-final.config.ts','independent-fc11-related.config.ts','independent-fc11-four.config.ts','run-independent231-supplement.mjs','independent231-en390-frame.spec.ts','independent231-en390-frame.config.ts','independent231-recovery-two.spec.ts','independent231-recovery-two.config.ts','build-independent231-evidence.py','independent231-sw-stable.spec.ts','independent231-sw-stable.config.ts']:
 files['scripts/'+n]=(repo/'test-results'/n).read_bytes()
for n in ['fc11-consumers.spec.ts','fc11-long-four.spec.ts','fc11-related-long.spec.ts','social-final.spec.ts']:files['scripts/'+n]=(repo/'test-results/independent-fc11'/n).read_bytes()
ident=json.loads(files['package-identity.json']);candidate=ident['candidate'];archive=ident['newArchiveSha256'];index=json.loads(files['busy/zh-CN-390.json'])['steps'][0] if False else None
index=next(s['entrySha256'] for s in json.loads(files['busy/zh-CN-390.json'])['steps'] if s['stage']=='identity')
def ref(p):return {'archive':dest,'path':p,'sha256':sha(files[p])}
def checkraw(p,lang,w):
 raw=json.loads(files[p]);assert raw['language']==lang and raw['width']==w
 steps={s.get('stage',s.get('step')):s for s in raw['steps']};i=steps['identity'];assert i['entrySha256']==index and i['archiveSha256']==archive
 return steps
cases=[]
for lang in ['zh-CN','en']:
 for w in [390,768,1280,1920,2560]:
  for consumer,prefix in [('workspace','workspace-samples'),('detail','detail-restore'),('asset-filter','focused-restore')]:
   group='en390-frame' if (lang,w,consumer)==('en',390,'detail') else ('busy-region' if (lang,w,consumer)==('zh-CN',390,'detail') else 'busy');stem=f'{lang}-{w}';rawPath=f'{group}/{stem}.json';steps=checkraw(rawPath,lang,w)
   for suffix in ['before-screenshot','after-screenshot']:
    buttons=steps[prefix+'-'+suffix]['buttons'];assert buttons and all(x['disabled'] is True and x['width']>=43.99 and x['height']>=43.99 and x['left']>=-.001 and x['right']>=-.001 for x in buttons)
   assert steps[prefix]['disabledBeforeAndAfterScreenshot'];g=steps[prefix+'-recovered']['geometry'];assert g['buttons'] and all(x['disabled'] is False for x in g['buttons'])
   if consumer!='workspace':assert steps[prefix+'-entry-restored']['entryCount']==1
   recoveryGroup='recovery-two' if consumer=='detail' and (lang,w) in [('zh-CN',390),('en',2560)] else group
   supplemental=[]
   if recoveryGroup=='recovery-two':
    auxPath=f'{recoveryGroup}/{stem}.json';aux=json.loads(files[auxPath]);auxSteps={s['stage']:s for s in aux['recoverySteps']};auxIdentity=auxSteps['identity'];assert auxIdentity['entrySha256']==index and auxIdentity['archiveSha256']==archive
    cap=auxSteps[prefix+'-recovered-capture'];assert all(b['disabled'] is False for k in ['before','after'] for b in cap[k]['buttons']);supplemental=[ref(auxPath)]
   cases.append({'id':f'busy:{consumer}:{lang}:{w}','status':'passed','operation':prefix,'imageKind':'busy document-coordinate region' if group in ['busy-region','en390-frame'] else 'busy viewport','recoveryImageKind':'stable document-coordinate region with separate original raw' if recoveryGroup=='recovery-two' else ('document-coordinate region' if group=='en390-frame' else 'viewport'),'evidence':[ref(rawPath),ref(f'{group}/{stem}-{prefix}-busy.png'),ref(f'{recoveryGroup}/{stem}-{prefix}-recovered.png')]+supplemental})
  group='social';stem=f'{lang}-{w}';rawPath=f'{group}/{stem}-social.json';steps=checkraw(rawPath,lang,w);s=steps['social-populated'];assert s['entryCount']>0 and s['expanded'] and s['categoryFiltered']=='true' and s['searchCleared'] and s['refreshRestored']
  cases.append({'id':f'social-populated:{lang}:{w}','status':'passed','observed':s,'evidence':[ref(rawPath),ref(f'{group}/{stem}-social-filtered.png'),ref(f'{group}/{stem}-social-restored.png'),ref(f'{group}/{stem}-social-neighbors.png')]})
assert len(cases)==len({x['id'] for x in cases})==40
coverage={'schema':'keepany.account-state-coverage.v1','candidate':candidate,'indexSha256':index,'archiveSha256':archive,'scope':'Independent final231 real UI busy30 and populatedSocial10; integrity is separate from actual visual review. Historical65ce untouched. ZH390/EN390 detail busy use explicit document-coordinate regions; three missing recovered-toolbar views use actual stable region supplements with original provenance.','cases':cases}
for name,prefix in [('busy-30','busy:'),('social-10','social-populated:')]:files['summaries/'+name+'.json']=json.dumps({**coverage,'cases':[x for x in cases if x['id'].startswith(prefix)]},ensure_ascii=False,indent=2).encode()
manifest={'candidate':candidate,'archiveSha256':archive,'scope':'Final231 independent FC12, three consumers, long fields, busy and social states. Source-based scripts are auxiliaries; UI consumes extracted final archive.','files':{n:{'sha256':sha(b),'bytes':len(b)} for n,b in files.items()}}
files['manifest.json']=json.dumps(manifest,ensure_ascii=False,indent=2).encode()
with ZipFile(repo/dest,'w',ZIP_DEFLATED) as z:
 for n,b in files.items():z.writestr(n,b)
with ZipFile(repo/dest) as z:
 assert z.testzip() is None
 for n,m in manifest['files'].items():assert sha(z.read(n))==m['sha256']
(repo/coveragePath).write_text(json.dumps(coverage,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'zip':dest,'files':len(files),'bytes':(repo/dest).stat().st_size,'zipSha256':sha((repo/dest).read_bytes()),'coverage':coveragePath,'coverageSha256':sha((repo/coveragePath).read_bytes()),'cases':len(cases)}))
