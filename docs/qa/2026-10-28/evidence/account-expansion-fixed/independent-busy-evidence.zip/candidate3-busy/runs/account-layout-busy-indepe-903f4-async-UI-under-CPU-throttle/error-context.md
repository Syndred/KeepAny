# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: account-layout-busy-independent.spec.ts >> independent busy zh-CN 1920: AL05 AL10 real async UI under CPU throttle
- Location: tests\e2e\account-layout-busy-independent.spec.ts:9:2

# Error details

```
Error: locator.screenshot: Element is not attached to the DOM
Call log:
  - taking element screenshot
  - waiting for fonts to load...
  - fonts loaded
  - attempting scroll into view action
    - waiting for element to be stable

```

# Test source

```ts
  1  | import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
  2  | import { join } from "node:path";
  3  | import { expect, test } from "@playwright/test";
  4  | import { resources } from "../../apps/web/src/i18n";
  5  | 
  6  | const evidence=process.env.KEEPANY_INDEPENDENT_EVIDENCE??"test-results/account-layout-independent/busy";
  7  | mkdirSync(evidence,{recursive:true});
  8  | for(const language of ["zh-CN","en"] as const)for(const width of [390,768,1280,1920,2560]){
  9  |  test(`independent busy ${language} ${width}: AL05 AL10 real async UI under CPU throttle`,async({browser})=>{
  10 |   test.setTimeout(180_000);const context=await browser.newContext({viewport:{width,height:1050},locale:language});
  11 |   await context.addInitScript(locale=>localStorage.setItem("keepany-language",locale),language);
  12 |   const page=await context.newPage(),t=(key:string)=>(resources[language].translation as Record<string,string>)[key]??key;
  13 |   const cdp=await context.newCDPSession(page),steps:object[]=[],errors:string[]=[];page.on("pageerror",error=>errors.push(error.message));
  14 |   try{
  15 |    await page.goto("/settings#advanced-settings");await page.getByRole("button",{name:t("loadSample"),exact:true}).click();await expect(page.getByRole("button",{name:t("sampleLibraryPresent"),exact:true})).toBeDisabled();
  16 |    await page.goto("/accounts");await page.locator(".unified-vault-access summary").click();
  17 |    const master="Independent busy synthetic 2026!";await page.locator("#password-vault-master").fill(master);await page.locator("#password-vault-master-confirm").fill(master);
  18 |    // Performance preparation only: no product API, state injection or request interception.
  19 |    await cdp.send("Emulation.setCPUThrottlingRate",{rate:16});
  20 |    const create=page.getByRole("button",{name:t("pwVaultCreate"),exact:true});
  21 |    await create.click();await expect(create).toBeDisabled();await expect(page.locator("#password-vault-master")).toBeDisabled();
> 22 |    await page.locator(".unified-vault-access").screenshot({path:join(evidence,`${language}-${width}-create-busy.png`)});
     |                                                ^ Error: locator.screenshot: Element is not attached to the DOM
  23 |    await expect(create).toBeDisabled();
  24 |    steps.push({step:"create-real-busy",cpuThrottle:16,disabledBeforeAndAfterScreenshot:true});
  25 |    await cdp.send("Emulation.setCPUThrottlingRate",{rate:1});
  26 |    const toolbar=page.locator(".password-vault-toolbar");await expect(toolbar).toBeVisible({timeout:30_000});
  27 |    await cdp.send("Emulation.setCPUThrottlingRate",{rate:16});
  28 |    const sample=toolbar.getByRole("button",{name:t("sampleLogins"),exact:true});await sample.click();await expect(sample).toBeDisabled();
  29 |    const before=await toolbar.locator("button").evaluateAll(nodes=>nodes.map(node=>({label:node.getAttribute("aria-label")??node.textContent,disabled:(node as HTMLButtonElement).disabled})));
  30 |    expect(before.every(button=>button.disabled)).toBe(true);
  31 |    await toolbar.screenshot({path:join(evidence,`${language}-${width}-toolbar-busy.png`)});
  32 |    await expect(sample).toBeDisabled();
  33 |    steps.push({step:"sample-real-busy",cpuThrottle:16,disabledBeforeAndAfterScreenshot:true,buttons:before});
  34 |    await cdp.send("Emulation.setCPUThrottlingRate",{rate:1});
  35 |    await expect(sample).toHaveCount(0,{timeout:60_000});await expect(page.locator(".unified-account-passwords .password-vault-entry")).toHaveCount(8);
  36 |    const phone=page.locator(".unified-account").filter({has:page.locator(".asset-account-phone")});await phone.locator("summary").click();await expect(phone.locator(".password-vault-entry")).toBeVisible();
  37 |    await expect(toolbar.getByRole("button",{name:t("pwVaultNewEntry"),exact:true})).toBeEnabled();
  38 |    expect(errors).toEqual([]);steps.push({step:"completed-real-operation",entries:8,toolbarEnabled:true,result:"passed"});
  39 |   }finally{
  40 |    await cdp.send("Emulation.setCPUThrottlingRate",{rate:1}).catch(()=>{});
  41 |    const release=process.env.KEEPANY_PREVIEW_DIRECTORY?JSON.parse(readFileSync(join(process.env.KEEPANY_PREVIEW_DIRECTORY,"RELEASE.json"),"utf8")):null;
  42 |    writeFileSync(join(evidence,`${language}-${width}-busy.json`),JSON.stringify({language,width,sourceCommit:release?.sourceCommit,preparation:"CDP 16x main-thread CPU throttle; real UI operations, no internal product state writes",steps,errors},null,2));await context.close();
  43 |   }
  44 |  });
  45 | }
  46 | 
```