from pathlib import Path
import json,hashlib,zipfile,math
base=Path('test-results/independent-final-d2');out=Path('docs/qa/2026-10-28/evidence/account-expansion-fixed/independent-final-d2-evidence.zip');sha=lambda b:hashlib.sha256(b).hexdigest();index='3477691fbbe51486e4d31f1653c5900c7047d5d116e8b95b847ff5ff940a8c6f';archive='1378f155667cf077d15b3368bf22662da1c47f8c6fbecca5095dd2131b51ed3e';cases=[];selected=[]
for lang in ['zh-CN','en']:
 for width in [390,768,1280,1920,2560]:
  for consumer,operation in [('workspace','workspace-samples'),('detail','detail-restore'),('asset-filter','focused-restore')]:
   if lang=='zh-CN':
    folder='busy' if width==390 else 'busy-remaining'
    if consumer=='asset-filter' and width==390:folder='busy-focused-complement-grep-fixed'
    if consumer=='asset-filter' and width==2560:folder='busy-focused-2560-button-union'
   else:folder=('busy-english-button-union' if consumer=='workspace' else 'busy-en390-large-missing') if width==390 else 'busy-en-remaining-large'
   p=base/folder/f'{lang}-{width}.json';raw=json.loads(p.read_text(encoding='utf-8-sig'));steps=raw['steps'];stage=lambda n:next(s for s in steps if s['stage']==n)
   ident=stage('identity');assert ident['entrySha256']==index and ident['archiveSha256']==archive
   for suffix,disabled in [('before-screenshot',True),('after-screenshot',True),('recovered-before-screenshot',False),('recovered-after-screenshot',False)]:
    buttons=stage(operation+'-'+suffix)['buttons'];assert buttons and all(b['disabled'] is disabled for b in buttons)
    for b in buttons:
     for k in ['width','height','left','right']:assert isinstance(b[k],(int,float)) and math.isfinite(b[k])
     assert b['width']>=44 and b['height']>=44 and b['left']>=-1 and b['right']>=-1
   assert stage(operation)['disabledBeforeAndAfterScreenshot'] is True
   if consumer!='workspace':assert stage(operation+'-entry-restored')['entryCount']==1
   ev=[p,base/folder/f'{lang}-{width}-{operation}-busy.png',base/folder/f'{lang}-{width}-{operation}-recovered.png']
   for e in ev:assert e.is_file()
   row={'id':f'busy:{consumer}:{lang}:{width}','status':'passed','operation':operation,'imageKind':'native document-coordinate region; original full toolbar or complete button union as raw capture-method specifies','recoveryImageKind':'native stable toolbar region','evidence':[{'archive':out.as_posix(),'path':e.relative_to(base).as_posix(),'sha256':sha(e.read_bytes())}for e in ev]};cases.append(row);selected.append({'id':row['id'],'folder':folder,'operation':operation,'files':[e.as_posix()for e in ev]})
  p=base/'social'/f'{lang}-{width}-social.json';raw=json.loads(p.read_text(encoding='utf-8-sig'));ident=next(s for s in raw['steps']if s.get('stage')=='identity');s=next(s for s in raw['steps']if s.get('stage')=='social-populated');assert ident['entrySha256']==index and ident['archiveSha256']==archive;assert s['entryCount']>0 and s['expanded'] and s['searchCleared'] and s['refreshRestored'];ev=[p]+list((base/'social').glob(f'{lang}-{width}-social-*.png'));cases.append({'id':f'social-populated:{lang}:{width}','status':'passed','evidence':[{'archive':out.as_posix(),'path':e.relative_to(base).as_posix(),'sha256':sha(e.read_bytes())}for e in ev]})
assert len(cases)==40 and len({c['id']for c in cases})==40
(base/'selected-busy-evidence.json').write_text(json.dumps(selected,indent=2))
items={}
for p in base.rglob('*'):
 if not p.is_file() or p.suffix.lower() in ['.kdbx','.ka1'] or 'runs' in p.relative_to(base).parts:continue
 if p.suffix.lower() not in ['.json','.png','.ts','.log','.err','.mjs','.py','.md']:continue
 items[p.relative_to(base).as_posix()]=p.read_bytes()
# Original failed trace evidence stays separate from valid selected frames, preserving timing/preparation facts.
for folder in ['busy','busy-remaining','busy-english-button-union']:
 for p in (base/folder/'runs').rglob('*'):
  if p.is_file() and p.suffix.lower() in ['.zip','.png','.md']:items[p.relative_to(base).as_posix()]=p.read_bytes()
manifest={'schema':'keepany.independent-evidence-manifest.v1','files':[{'path':k,'size':len(v),'sha256':sha(v)}for k,v in sorted(items.items())]};items['manifest.json']=json.dumps(manifest,indent=2).encode()
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for k,v in sorted(items.items()):z.writestr(k,v)
with zipfile.ZipFile(out)as z:
 assert z.testzip()is None
 for r in manifest['files']:assert sha(z.read(r['path']))==r['sha256']
coverage={'schema':'keepany.account-state-coverage.v1','candidate':'d2fdbdee264b524219ae091ca78b120c6428ff61','indexSha256':index,'archiveSha256':archive,'scope':'Independent actual d2 real UI busy30 and populatedSocial10. Per-consumer selection preserves earlier valid states and separates incomplete capture windows; no failed frame relabelled. Auxiliary real UI imported 200-entry fixture applies only to final English restore states. Human visual separately recorded.','cases':cases}
cp=out.parent/'independent-final-d2-state-coverage.json';cp.write_text(json.dumps(coverage,indent=2))
receipt={'path':out.as_posix(),'size':out.stat().st_size,'sha256':sha(out.read_bytes()),'entries':len(items),'manifestFiles':len(manifest['files']),'crc':'passed','manifestHashes':'passed','coverage':cp.as_posix(),'coverageSha256':sha(cp.read_bytes())};out.with_suffix('.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
