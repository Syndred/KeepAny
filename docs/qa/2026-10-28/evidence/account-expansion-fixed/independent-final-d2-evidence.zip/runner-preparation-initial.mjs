import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync,mkdirSync,copyFileSync} from 'node:fs';
import {resolve,basename} from 'node:path';
import {createHash} from 'node:crypto';
const sha=b=>createHash('sha256').update(b).digest('hex');
const archive=resolve('dist/preview/KeepAny-0.1.0-preview.d2fdbdee264b.dirty-portable.zip');
const suiteDefs=[['fc18','test-results/independent-d2-fc18.config.ts','tests/e2e/password-history-version.spec.ts'],['fc12','test-results/independent-fc12.config.ts','test-results/fc12-independent.spec.ts'],['consumers','test-results/independent231-consumers.config.ts','test-results/independent-fc11/fc11-consumers.spec.ts'],['long-four','test-results/independent-fc11-four.config.ts','test-results/independent-fc11/fc11-long-four.spec.ts'],['related-long','test-results/independent-fc11-related.config.ts','test-results/independent-fc11/fc11-related-long.spec.ts'],['busy','test-results/independent-d2-busy.config.ts','test-results/independent-d2-busy.spec.ts'],['social','test-results/independent-social-final.config.ts','test-results/independent-fc11/social-final.spec.ts']];
for(const [name,config,source]of suiteDefs){
 const dir=resolve(`test-results/independent-final-d2/${name}`);mkdirSync(dir+'/inputs',{recursive:true});
 // Record actual source/config bytes before execution; no running input is changed.
 const inputs=[config,source].map(p=>{const b=readFileSync(p);copyFileSync(p,dir+'/inputs/'+basename(p));return {path:p,sha256:sha(b)}});
 const receipt={candidate:'d2fdbdee264b',archive,archiveSha256:sha(readFileSync(archive)),inputs,started:new Date().toISOString(),status:'running',serviceWorkers:'default; no fault injection'};
 writeFileSync(dir+'/process.json',JSON.stringify(receipt,null,2));
 const env={...process.env,KEEPANY_RELEASE_TEST_PORT:'4241',KEEPANY_PREVIEW_ARCHIVE:archive,KEEPANY_INDEPENDENT_EVIDENCE:dir,KEEPANY_EVIDENCE_DIR:dir+'/evidence'};
 console.log('START',name,receipt.started);
 const result=spawnSync(process.execPath,['node_modules/@playwright/test/cli.js','test','--config',config,'--max-failures','1'],{env,encoding:'utf8',maxBuffer:30*1024*1024});
 writeFileSync(dir+'/run.log',result.stdout??'');writeFileSync(dir+'/run.err',result.stderr??'');
 Object.assign(receipt,{status:result.status===0?'passed':'failed',exitCode:result.status,error:result.error?.message,finished:new Date().toISOString()});writeFileSync(dir+'/process.json',JSON.stringify(receipt,null,2));
 console.log('END',name,JSON.stringify({status:result.status,error:result.error?.message}),String(result.stdout).slice(-900));
 if(result.status!==0)process.exit(result.status??1);
}

