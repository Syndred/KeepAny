# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: fc11-busy-65ce.spec.ts >> zh-CN 390 real busy across applicable toolbar consumers
- Location: test-results\fc11-busy-65ce.spec.ts:5:91

# Error details

```
Error: expect(locator).toBeDisabled() failed

Locator:  locator('.password-vault-toolbar').getByRole('button', { name: '导出备份', exact: true })
Expected: disabled
Received: enabled
Timeout:  5000ms

Call log:
  - Expect "toBeDisabled" locator('.password-vault-toolbar').getByRole('button', { name: '导出备份', exact: true }) with timeout 5000ms
  - waiting for locator('.password-vault-toolbar').getByRole('button', { name: '导出备份', exact: true })
    13 × locator resolved to <button tabindex="0" title="导出备份" type="button" aria-label="导出备份" data-slot="button" class="button inline-flex shrink-0 items-center justify-center gap-2 rounded-full border-2 font-semibold outline-offset-2 disabled:cursor-not-allowed disabled:opacity-60 ghost icon password-vault-icon">…</button>
       - unexpected value "enabled"

```

```yaml
- button "导出备份"
```

# Test source

```ts
  1  | import {test,expect,type Locator} from '@playwright/test';
  2  | import {mkdirSync,readFileSync,writeFileSync} from 'node:fs';import{join}from'node:path';import{createHash}from'node:crypto';
  3  | import{resources}from'../apps/web/src/i18n';
  4  | const evidence=process.env.KEEPANY_INDEPENDENT_EVIDENCE!;mkdirSync(evidence,{recursive:true});
  5  | for(const language of ['zh-CN','en'] as const)for(const width of [390,768,1280,1920,2560])test(`${language} ${width} real busy across applicable toolbar consumers`,async({browser})=>{
  6  |  test.setTimeout(180000);const context=await browser.newContext({locale:language,viewport:{width,height:1050}});await context.addInitScript(v=>localStorage.setItem('keepany-language',v),language);const page=await context.newPage(),cdp=await context.newCDPSession(page),t=(k:string)=>(resources[language].translation as Record<string,string>)[k]??k,steps:any[]=[],errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));const toolbar=page.locator('.password-vault-toolbar');
  7  |  async function geometry(stage:string){const g=await toolbar.evaluate(n=>{const r=n.getBoundingClientRect();return{left:r.left,right:r.right,viewport:innerWidth,buttons:[...n.querySelectorAll<HTMLButtonElement>('button')].map(b=>{const q=b.getBoundingClientRect();return{label:b.getAttribute('aria-label')??b.textContent,disabled:b.disabled,left:q.left,right:q.right,top:q.top,bottom:q.bottom,width:q.width,height:q.height}}),search:[...n.querySelectorAll<HTMLInputElement>('input')].map(x=>x.getBoundingClientRect().width)}});expect(g.left).toBeGreaterThanOrEqual(0);expect(g.right).toBeLessThanOrEqual(g.viewport+1);expect(g.buttons.length).toBeGreaterThan(5);for(const b of g.buttons){expect(+b.width.toFixed(3)).toBeGreaterThanOrEqual(44);expect(+b.height.toFixed(3)).toBeGreaterThanOrEqual(44);expect(b.left).toBeGreaterThanOrEqual(g.left-1);expect(b.right).toBeLessThanOrEqual(g.right+1);expect(b.top).toBeGreaterThanOrEqual(0);expect(b.bottom).toBeLessThanOrEqual(1050)}for(const w of g.search)expect(w).toBeGreaterThanOrEqual(150);steps.push({stage,geometry:g});return g;}
> 8  |  async function busy(stage:string,button:Locator,download=false){await toolbar.scrollIntoViewIfNeeded();await geometry(stage+'-before');await expect(button).toBeEnabled();await cdp.send('Emulation.setCPUThrottlingRate',{rate:16});const saved=download?page.waitForEvent('download'):null;await button.click();await expect(button).toBeDisabled();const before=await toolbar.locator('button').evaluateAll(ns=>ns.map(x=>({label:x.getAttribute('aria-label')??x.textContent,disabled:(x as HTMLButtonElement).disabled})));expect(before.every(x=>x.disabled)).toBe(true);const shot=await cdp.send('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});writeFileSync(join(evidence,`${language}-${width}-${stage}-busy.png`),Buffer.from(shot.data,'base64'));await expect(button).toBeDisabled();steps.push({stage,cpuThrottle:16,disabledBeforeAndAfterScreenshot:true,buttons:before});await geometry(stage+'-busy');await cdp.send('Emulation.setCPUThrottlingRate',{rate:1});if(saved){const d=await saved;expect(await d.failure()).toBeNull();steps.push({stage:stage+'-download',filename:d.suggestedFilename()})}if(stage==='workspace-samples')await expect(button).toHaveCount(0,{timeout:60000});else await expect(button).toBeEnabled({timeout:30000});await expect(toolbar.getByRole('button',{name:t('pwVaultNewEntry'),exact:true})).toBeEnabled();await geometry(stage+'-recovered');await page.screenshot({path:join(evidence,`${language}-${width}-${stage}-recovered.png`)});}
     |                                                                                                                                                                                                                                                                                                                                         ^ Error: expect(locator).toBeDisabled() failed
  9  |  try{await page.goto('/settings#advanced-settings');await page.getByRole('button',{name:t('loadSample'),exact:true}).click();await expect(page.getByRole('button',{name:t('sampleLibraryPresent'),exact:true})).toBeDisabled();await page.goto('/accounts');await page.locator('.unified-vault-access summary').click();await page.locator('#password-vault-master').fill('Independent busy synthetic 2026!');await page.locator('#password-vault-master-confirm').fill('Independent busy synthetic 2026!');await page.getByRole('button',{name:t('pwVaultCreate'),exact:true}).click();await expect(toolbar).toBeVisible();steps.push({stage:'identity',archiveSha256:createHash('sha256').update(readFileSync(process.env.KEEPANY_PREVIEW_ARCHIVE!)).digest('hex'),entrySha256:createHash('sha256').update(await(await page.request.get('/')).body()).digest('hex')});
  10 |  await busy('workspace-samples',toolbar.getByRole('button',{name:t('sampleLogins'),exact:true}));await expect(page.locator('.unified-account-passwords .password-vault-entry')).toHaveCount(8);const phone=page.locator('.unified-account').filter({has:page.locator('.asset-account-phone')});await phone.locator('summary').click();await expect(phone.locator('.password-vault-entry')).toBeVisible();await phone.locator('a.asset-account-card').click();await page.getByRole('button',{name:t('workspaceShowPasswords'),exact:true}).click();await expect(toolbar).toBeVisible();await expect(toolbar.getByRole('button',{name:t('sampleLogins'),exact:true})).toHaveCount(0);steps.push({stage:'detail-samples-not-applicable',reason:'Detail receives no sampleAccounts; no sample-completion action exists'});await busy('detail-export',toolbar.getByRole('button',{name:t('pwVaultExport'),exact:true}),true);await page.getByRole('link',{name:t('accountOpenPasswords'),exact:true}).click();await expect(page.locator('.password-vault-filter')).toBeVisible();await busy('focused-export',toolbar.getByRole('button',{name:t('pwVaultExport'),exact:true}),true);await expect(page.locator('.password-vault-entry')).toHaveCount(1);expect(errors).toEqual([]);
  11 |  }finally{await cdp.send('Emulation.setCPUThrottlingRate',{rate:1}).catch(()=>{});writeFileSync(join(evidence,`${language}-${width}.json`),JSON.stringify({language,width,steps,errors},null,2));await context.close()}
  12 | });
  13 | 
```