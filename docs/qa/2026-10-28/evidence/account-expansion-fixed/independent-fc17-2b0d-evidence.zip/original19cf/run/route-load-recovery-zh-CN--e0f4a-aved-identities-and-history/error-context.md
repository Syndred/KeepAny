# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: route-load-recovery.spec.ts >> zh-CN 390 FC17 two manual recoveries preserve saved identities and history
- Location: tests\e2e\route-load-recovery.spec.ts:237:2

# Error details

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 44
Received:    36
```

# Test source

```ts
  25  | // Test author is independent of the product implementation. All writes below
  26  | // are real UI operations on synthetic data. Read-only KDBX/backup decryption is
  27  | // auxiliary observation, not a claim that it is itself a user interaction.
  28  | const widths = [390, 563, 768, 1280, 1920, 2560] as const;
  29  | const languages = ["zh-CN", "en"] as const;
  30  | type Language = (typeof languages)[number];
  31  | const evidence = process.env.KEEPANY_EVIDENCE_DIR ?? "test-results/route-load-recovery/evidence";
  32  | const syntheticPassword = "Synthetic-FC17-entry!42";
  33  | const updatedPassword = "Synthetic-FC17-entry-updated!42";
  34  | const backupPassword = "Synthetic-FC17-backup!42";
  35  | const titles = ["Gmail FC17", "GitHub FC17"];
  36  | const sha = (bytes: string | Uint8Array) => createHash("sha256").update(bytes).digest("hex");
  37  | 
  38  | type Release = {
  39  | 	sourceCommit: string;
  40  | 	sourceDirty: boolean;
  41  | 	webFiles: { path: string; sha256: string }[];
  42  | 	applicationRoutes: { paths: string[] };
  43  | };
  44  | function packageIdentity() {
  45  | 	const archive = process.env.KEEPANY_PREVIEW_ARCHIVE;
  46  | 	const directory = process.env.KEEPANY_PREVIEW_DIRECTORY;
  47  | 	if (archive) {
  48  | 		const bytes = readFileSync(archive);
  49  | 		const archiveSha256 = sha(bytes);
  50  | 		expect(archiveSha256).toBe(readFileSync(`${archive}.sha256`, "utf8").trim().split(/\s+/)[0]);
  51  | 		const files = unzipSync(bytes);
  52  | 		const names = Object.keys(files).filter((name) => name.endsWith("/RELEASE.json") && name.split("/").length === 2);
  53  | 		expect(names).toHaveLength(1);
  54  | 		return { release: JSON.parse(strFromU8(files[names[0]])) as Release, archiveSha256 };
  55  | 	}
  56  | 	if (directory) return { release: JSON.parse(readFileSync(join(directory, "RELEASE.json"), "utf8")) as Release, archiveSha256: null };
  57  | 	throw Error("FC17 requires an actual portable candidate, never development source");
  58  | }
  59  | async function servedIdentity(request: APIRequestContext) {
  60  | 	const candidate = packageIdentity();
  61  | 	const html = await (await request.get("/")).body();
  62  | 	const indexSha256 = sha(html);
  63  | 	expect(indexSha256).toBe(candidate.release.webFiles.find((row) => row.path === "index.html")?.sha256);
  64  | 	return { candidate: candidate.release.sourceCommit, sourceDirty: candidate.release.sourceDirty, archiveSha256: candidate.archiveSha256, indexSha256 };
  65  | }
  66  | function modulePath(release: Release, prefix: string) {
  67  | 	const files = release.webFiles.filter((row) => row.path.startsWith(`assets/${prefix}-`) && row.path.endsWith(".js"));
  68  | 	expect(files, `One actual compiled module for ${prefix}`).toHaveLength(1);
  69  | 	return `/${files[0].path}`;
  70  | }
  71  | async function harness(browser: Browser, language: Language, width: number, baseURL: string) {
  72  | 	const context = await browser.newContext({ baseURL, locale: language === "en" ? "en-US" : language, viewport: { width, height: 1000 }, serviceWorkers: "block" });
  73  | 	// Only language is initialized outside UI. SW blocking is explicit fault preparation.
  74  | 	await context.addInitScript((value) => localStorage.setItem("keepany-language", value), language);
  75  | 	const page = await context.newPage();
  76  | 	page.setDefaultTimeout(15_000);
  77  | 	return { context, page, t: visualCopy(language) };
  78  | }
  79  | function copy(language: Language) {
  80  | 	return language === "zh-CN" ? {
  81  | 		title: "暂时无法打开这个页面", hint: "请重新加载后再试，已保存的资料会保留。", reload: "重新加载", createBackup: "创建备份", saveBackup: "保存备份文件",
  82  | 	} : {
  83  | 		title: "This page could not be opened", hint: "Reload to try again. Your saved records will be kept.", reload: "Reload page", createBackup: "Create backup", saveBackup: "Save backup file",
  84  | 	};
  85  | }
  86  | type Journal = { stage: string; [key: string]: unknown }[];
  87  | async function capture(page: Page, folder: string, name: string, steps: Journal, sectionOnly = false) {
  88  | 	const path = join(folder, `${name}.png`);
  89  | 	if (sectionOnly) await page.getByTestId("route-load-error").screenshot({ path });
  90  | 	else await page.screenshot({ path });
  91  | 	steps.push({ stage: "screenshot", name, path, sha256: sha(readFileSync(path)), visualVerdict: "not-reviewed" });
  92  | }
  93  | async function errorControls(page: Page, language: Language, width: number, steps: Journal) {
  94  | 	const section = page.getByTestId("route-load-error");
  95  | 	const text = copy(language);
  96  | 	await expect(section).toBeVisible();
  97  | 	await expect(section).toHaveAttribute("data-error-kind", "module-load");
  98  | 	await expect(page.locator("main").filter({ has: section })).toHaveCount(1);
  99  | 	const heading = section.getByRole("heading", { name: text.title, exact: true, level: 1 });
  100 | 	await expect(heading).toHaveAttribute("tabindex", "-1");
  101 | 	await expect(heading).toBeFocused();
  102 | 	await expect(section.getByText(text.hint, { exact: true })).toBeVisible();
  103 | 	const button = section.getByRole("button", { name: text.reload, exact: true });
  104 | 	await expect(section.getByRole("button")).toHaveCount(1);
  105 | 	await expect(button).toBeEnabled();
  106 | 	await expect(section).not.toContainText(/TypeError|https?:\/\/|node_modules|Show Error|\.js\b|Synthetic-FC17/);
  107 | 	if (width < 768) await expect(page.locator(".mobile-menu")).toBeVisible();
  108 | 	else await expect(page.locator(".sidebar")).toBeVisible();
  109 | 	const geometry = await section.evaluate((node) => {
  110 | 		const bounds = node.getBoundingClientRect();
  111 | 		const button = node.querySelector("button")?.getBoundingClientRect();
  112 | 		const heading = node.querySelector("h1")?.getBoundingClientRect();
  113 | 		return {
  114 | 			section: { left: bounds.left, right: bounds.right, top: bounds.top, bottom: bounds.bottom, scrollWidth: node.scrollWidth, clientWidth: node.clientWidth },
  115 | 			button: button && { left: button.left, right: button.right, top: button.top, bottom: button.bottom, width: button.width, height: button.height },
  116 | 			heading: heading && { top: heading.top, bottom: heading.bottom }, viewport: { width: innerWidth, height: innerHeight },
  117 | 			pageOverflow: document.documentElement.scrollWidth > innerWidth,
  118 | 		};
  119 | 	});
  120 | 	expect(geometry.pageOverflow).toBe(false);
  121 | 	expect(geometry.section.left).toBeGreaterThanOrEqual(-1);
  122 | 	expect(geometry.section.right).toBeLessThanOrEqual(width + 1);
  123 | 	expect(geometry.section.scrollWidth).toBeLessThanOrEqual(geometry.section.clientWidth + 1);
  124 | 	expect(geometry.button?.width).toBeGreaterThanOrEqual(44);
> 125 | 	expect(geometry.button?.height).toBeGreaterThanOrEqual(44);
      |                                  ^ Error: expect(received).toBeGreaterThanOrEqual(expected)
  126 | 	expect(geometry.button?.top).toBeGreaterThanOrEqual(0);
  127 | 	expect(geometry.button?.bottom).toBeLessThanOrEqual(geometry.viewport.height + 1);
  128 | 	expect(geometry.heading?.top).toBeGreaterThanOrEqual(0);
  129 | 	expect(geometry.heading?.bottom).toBeLessThanOrEqual(geometry.viewport.height + 1);
  130 | 	steps.push({ stage: "error-controls", geometry, classification: "module-load", loadingDisabled: "N/A: reload is a hard navigation, no in-page saving/busy operation" });
  131 | 	return { section, heading, button };
  132 | }
  133 | async function visibleStates(page: Page, folder: string, name: string, button: Locator, steps: Journal) {
  134 | 	await capture(page, folder, `${name}-default`, steps);
  135 | 	await button.hover();
  136 | 	await capture(page, folder, `${name}-hover`, steps, true);
  137 | 	await page.keyboard.press("Tab");
  138 | 	await expect(button).toBeFocused();
  139 | 	await capture(page, folder, `${name}-focus`, steps, true);
  140 | 	const rect = await button.boundingBox();
  141 | 	if (!rect) throw Error("FC17 reload button bounds missing");
  142 | 	await page.mouse.move(rect.x + rect.width / 2, rect.y + rect.height / 2);
  143 | 	await page.mouse.down();
  144 | 	await capture(page, folder, `${name}-pressed`, steps, true);
  145 | 	// Cancel this pointer gesture outside the button. Recovery is a separate,
  146 | 	// actual keyboard/click action; capturing a pressed frame is not a reload.
  147 | 	await page.mouse.move(0, 0);
  148 | 	await page.mouse.up();
  149 | }
  150 | async function unlock(page: Page, t: ReturnType<typeof visualCopy>, requireLocked: boolean) {
  151 | 	await openVaultAccess(page);
  152 | 	const input = page.locator("#password-vault-unlock-master");
  153 | 	if (requireLocked) await expect(input).toBeVisible();
  154 | 	if (await input.isVisible()) {
  155 | 		await input.fill(visualMaster);
  156 | 		await page.getByRole("button", { name: t("pwVaultUnlock"), exact: true }).click();
  157 | 	}
  158 | 	await expect(page.locator(".password-vault-toolbar")).toBeVisible();
  159 | 	await revealPasswordEntries(page);
  160 | }
  161 | async function seedSavedData(page: Page, t: ReturnType<typeof visualCopy>) {
  162 | 	await page.goto("/accounts");
  163 | 	await openVaultAccess(page);
  164 | 	await page.locator("#password-vault-master").fill(visualMaster);
  165 | 	await page.locator("#password-vault-master-confirm").fill(visualMaster);
  166 | 	await page.getByRole("button", { name: t("pwVaultCreate"), exact: true }).click();
  167 | 	await expect(page.locator(".password-vault-toolbar")).toBeVisible();
  168 | 	for (const [index, title] of titles.entries()) {
  169 | 		await page.getByRole("button", { name: t("pwVaultNewEntry"), exact: true }).click();
  170 | 		await page.locator("#password-vault-entry-title").fill(title);
  171 | 		await page.locator("#password-vault-entry-username").fill("fc17.owner@gmail.com");
  172 | 		await page.locator("#password-vault-entry-password").fill(syntheticPassword);
  173 | 		const addUrl = page.getByRole("button", { name: t("pwVaultAddUrl"), exact: true });
  174 | 		if (await addUrl.isVisible()) await addUrl.click();
  175 | 		await page.locator("#password-vault-entry-url").fill(index ? "https://github.com/" : "https://mail.google.com/");
  176 | 		await page.locator("#password-vault-entry-notes").fill(`Synthetic saved FC17 note ${index}. ${"Long saved text stays local. ".repeat(5)}`);
  177 | 		await page.getByRole("dialog").getByRole("button", { name: t("pwVaultSaveEntry"), exact: true }).click();
  178 | 		await expect(page.getByRole("dialog")).toHaveCount(0);
  179 | 	}
  180 | 	const first = page.locator(".password-vault-entry").filter({ has: page.getByRole("heading", { name: titles[0], exact: true }) });
  181 | 	await first.getByRole("button", { name: t("pwVaultEditEntry"), exact: true }).click();
  182 | 	await page.locator("#password-vault-entry-password").fill(updatedPassword);
  183 | 	await page.getByRole("dialog").getByRole("button", { name: t("pwVaultSaveEntry"), exact: true }).click();
  184 | 	await expect(page.getByRole("dialog")).toHaveCount(0);
  185 | 	await page.getByRole("button", { name: t("pwConnectTitle"), exact: true }).click();
  186 | 	const dialog = page.locator(".vault-connect-dialog");
  187 | 	await expect(dialog.locator(".vault-connect-account")).toHaveCount(2);
  188 | 	await expect(dialog.locator(".vault-connect-conflict")).toHaveCount(0);
  189 | 	await dialog.getByRole("button", { name: t("pwConnectSelectAll"), exact: true }).click();
  190 | 	await dialog.getByRole("button", { name: t("pwConnectLocal"), exact: true }).click();
  191 | 	await dialog.getByRole("button", { name: t("pwConnectSave"), exact: true }).click();
  192 | 	await expect(dialog).toBeHidden();
  193 | 	await expect(page.locator(".asset-account-card")).toHaveCount(2);
  194 | 	await revealPasswordEntries(page);
  195 | }
  196 | async function exportedKdbx(page: Page, t: ReturnType<typeof visualCopy>, info: TestInfo, name: string) {
  197 | 	await page.goto("/accounts");
  198 | 	await unlock(page, t, false);
  199 | 	const downloading = page.waitForEvent("download");
  200 | 	await page.getByRole("button", { name: t("pwVaultExport"), exact: true }).click();
  201 | 	const download = await downloading;
  202 | 	const file = info.outputPath(`${name}.kdbx`);
  203 | 	await download.saveAs(file);
  204 | 	try {
  205 | 		const entries = (await inspectVisualKdbx(file)).sort((left, right) => left.draft.title.localeCompare(right.draft.title));
  206 | 		expect(entries).toHaveLength(2);
  207 | 		expect(entries.every((entry) => entry.draft.id && entry.draft.linkedAssetIds.length === 1)).toBe(true);
  208 | 		expect(new Set(entries.map((entry) => entry.draft.id)).size).toBe(2);
  209 | 		expect(entries.find((entry) => entry.draft.title === titles[0])?.history.length).toBeGreaterThan(0);
  210 | 		return { digest: sha(JSON.stringify(entries)), entries: entries.map((entry) => ({ id: entry.draft.id, linkedAssetIds: entry.draft.linkedAssetIds, passwordSha256: sha(entry.draft.password), historyCount: entry.history.length, historySha256: sha(JSON.stringify(entry.history)) })) };
  211 | 	} finally { await download.delete(); }
  212 | }
  213 | async function exportedBackup(page: Page, language: Language, info: TestInfo, name: string) {
  214 | 	await page.goto("/intake");
  215 | 	await page.locator("#backup-password").fill(backupPassword);
  216 | 	await page.getByRole("button", { name: copy(language).createBackup, exact: true }).click();
  217 | 	const downloading = page.waitForEvent("download");
  218 | 	await page.getByRole("link", { name: copy(language).saveBackup, exact: true }).click();
  219 | 	const download = await downloading;
  220 | 	const file = info.outputPath(`${name}.ka1`);
  221 | 	await download.saveAs(file);
  222 | 	try {
  223 | 		const archive = unzipSync(await decryptBackup(new Uint8Array(readFileSync(file)), backupPassword));
  224 | 		const rows = JSON.parse(strFromU8(archive["records.json"])) as { type: string; id?: string; payload: string }[];
  225 | 		const assets = rows.filter((row) => row.type === "asset").map((row) => JSON.parse(row.payload) as { id: string; deleted?: boolean });
```