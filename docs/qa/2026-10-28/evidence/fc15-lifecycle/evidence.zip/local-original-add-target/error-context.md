# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: account-graph-readability.spec.ts >> zh-CN 1536px multi-source identities preserve connection purposes across reload and edits
- Location: tests\e2e\account-graph-readability.spec.ts:1433:3

# Error details

```
TimeoutError: locator.fill: Timeout 15000ms exceeded.
Call log:
  - waiting for getByRole('dialog').locator('#name')

```

# Test source

```ts
  148 | 	{ from: "docs", to: "mail", purpose: "recoveryEmail", verified: false },
  149 | 	{ from: "code", to: "phoneA", purpose: "phone", verified: true },
  150 | 	{ from: "design", to: "phoneB", purpose: "recoveryPhone", verified: true },
  151 | 	{ from: "mail", to: "phoneA", purpose: "recoveryPhone", verified: true },
  152 | 	{ from: "phoneA", to: "code", purpose: "linkedAccount", verified: false },
  153 | 	{ from: "mail", to: "docs", purpose: "linkedAccount", verified: true },
  154 | ];
  155 | 
  156 | function account(key: AccountKey) {
  157 | 	const record = accounts.find((item) => item.key === key);
  158 | 	if (!record && /^extra-\d+$/.test(key))
  159 | 		return {
  160 | 			key,
  161 | 			name: `QA Additional Service ${key.slice(6)}`,
  162 | 			username: `graph.owner.${key}.username`,
  163 | 			category: "other" as const,
  164 | 		};
  165 | 	if (!record) throw Error(`Missing graph scenario account: ${key}`);
  166 | 	// These scenarios enter every purpose manually. Shared primary/alias auto-linking
  167 | 	// is covered by account-shared-identity.spec.ts; keep long service usernames here.
  168 | 	return record.category === "other"
  169 | 		? { ...record, username: `graph.owner.${key}.username` }
  170 | 		: record;
  171 | }
  172 | function copy(locale: string) {
  173 | 	return locale === "zh-CN"
  174 | 		? {
  175 | 				add: "新增",
  176 | 				save: "保存",
  177 | 				addConnection: "添加关联",
  178 | 				target: "关联至",
  179 | 				label: "关联用途",
  180 | 				verifiedAt: "最近核验",
  181 | 				remove: "删除关系",
  182 | 				direct: "直接关联",
  183 | 				family: "完整关系",
  184 | 				backup: "创建备份",
  185 | 				download: "保存备份文件",
  186 | 				duplicate: "这条同方向、同用途的关系已存在。",
  187 | 				selection: "关联详情",
  188 | 				close: "关闭",
  189 | 				fit: "适应画布",
  190 | 				center: "回到当前",
  191 | 				expand: "全屏查看",
  192 | 				verified: "已核实",
  193 | 				mixed: "含待核实关系",
  194 | 				pending: "待核实",
  195 | 				purposes: {
  196 | 					email: "登录邮箱",
  197 | 					recoveryEmail: "找回邮箱",
  198 | 					phone: "登录手机号",
  199 | 					recoveryPhone: "找回手机号",
  200 | 					linkedAccount: "关联账号",
  201 | 				},
  202 | 			}
  203 | 		: {
  204 | 				add: "Add",
  205 | 				save: "Save",
  206 | 				addConnection: "Add connection",
  207 | 				target: "Connect to",
  208 | 				label: "Connection label",
  209 | 				verifiedAt: "Last verified",
  210 | 				remove: "Delete connection",
  211 | 				direct: "Direct",
  212 | 				family: "All connections",
  213 | 				backup: "Create backup",
  214 | 				download: "Save backup file",
  215 | 				duplicate: "A connection with this direction and label already exists.",
  216 | 				selection: "Connection details",
  217 | 				close: "Close",
  218 | 				fit: "Fit all",
  219 | 				center: "Back to current",
  220 | 				expand: "Expand graph",
  221 | 				verified: "Verified",
  222 | 				mixed: "Includes connections to verify",
  223 | 				pending: "To verify",
  224 | 				purposes: {
  225 | 					email: "Login email",
  226 | 					recoveryEmail: "Recovery email",
  227 | 					phone: "Login phone",
  228 | 					recoveryPhone: "Recovery phone",
  229 | 					linkedAccount: "Linked account",
  230 | 				},
  231 | 			};
  232 | }
  233 | type Copy = ReturnType<typeof copy>;
  234 | 
  235 | async function createScenarioAccount(page: Page, key: AccountKey, text: Copy) {
  236 | 	const record = account(key);
  237 | 	const back = page.locator('.topbar-back-link[href="/assets/account"]');
  238 | 	if (await back.count()) await back.click();
  239 | 	else if (new URL(page.url()).pathname !== "/assets/account") {
  240 | 		// Retain the first cold startup and entries from other sections such as Intake.
  241 | 		await page.goto("/assets/account");
  242 | 	}
  243 | 	await page
  244 | 		.getByRole("main")
  245 | 		.getByRole("button", { name: text.add, exact: true })
  246 | 		.click();
  247 | 	const editor = page.getByRole("dialog");
> 248 | 	await editor.locator("#name").fill(record.name);
      |                                ^ TimeoutError: locator.fill: Timeout 15000ms exceeded.
  249 | 	await selectChoice(editor.locator("#category"), record.category);
  250 | 	await editor.locator("#username").fill(record.username);
  251 | 	await editor.getByRole("button", { name: text.save, exact: true }).click();
  252 | 	await expect(editor).toBeHidden();
  253 | 	const card = page
  254 | 		.locator(".asset-account-card")
  255 | 		.filter({ has: page.getByText(record.name, { exact: true }) });
  256 | 	await expect(card).toBeVisible();
  257 | 	const href = await card.getAttribute("href");
  258 | 	if (!href)
  259 | 		throw Error(`Scenario account has no details link: ${record.name}`);
  260 | 	return href;
  261 | }
  262 | function detailsHref(hrefs: Map<AccountKey, string>, key: AccountKey) {
  263 | 	const href = hrefs.get(key);
  264 | 	if (!href) throw Error(`Missing scenario details URL: ${key}`);
  265 | 	return href;
  266 | }
  267 | function accountId(hrefs: Map<AccountKey, string>, key: AccountKey) {
  268 | 	const id = new URL(
  269 | 		detailsHref(hrefs, key),
  270 | 		"http://scenario.invalid",
  271 | 	).pathname
  272 | 		.split("/")
  273 | 		.filter(Boolean)
  274 | 		.at(-1);
  275 | 	if (!id) throw Error(`Missing scenario account ID: ${key}`);
  276 | 	return id;
  277 | }
  278 | function connectionRow(connection: Connection, text: Copy) {
  279 | 	const endpoints = [
  280 | 		account(connection.from).name,
  281 | 		account(connection.to).name,
  282 | 	];
  283 | 	return {
  284 | 		endpoints,
  285 | 		path: endpoints.join(" → "),
  286 | 		purpose: text.purposes[connection.purpose],
  287 | 	};
  288 | }
  289 | async function addScenarioConnection(
  290 | 	page: Page,
  291 | 	hrefs: Map<AccountKey, string>,
  292 | 	connection: Connection,
  293 | 	text: Copy,
  294 | ) {
  295 | 	await page.goto(detailsHref(hrefs, connection.from));
  296 | 	await page
  297 | 		.getByRole("button", { name: text.addConnection, exact: true })
  298 | 		.click();
  299 | 	const editor = page.getByRole("dialog");
  300 | 	await selectChoice(editor.getByLabel(text.target, { exact: true }), {
  301 | 		label: account(connection.to).name,
  302 | 	});
  303 | 	await editor
  304 | 		.getByLabel(text.label, { exact: true })
  305 | 		.fill(text.purposes[connection.purpose]);
  306 | 	if (connection.verified)
  307 | 		await editor
  308 | 			.getByLabel(text.verifiedAt, { exact: true })
  309 | 			.fill("2026-10-22");
  310 | 	await editor.getByRole("button", { name: text.save, exact: true }).click();
  311 | 	await expect(editor).toBeHidden();
  312 | 	const expected = connectionRow(connection, text);
  313 | 	const row = page
  314 | 		.locator(".relation-list .relation-row")
  315 | 		.filter({
  316 | 			has: page
  317 | 				.locator(".relation-endpoints")
  318 | 				.filter({ hasText: expected.path }),
  319 | 		})
  320 | 		.filter({
  321 | 			has: page
  322 | 				.locator(".relation-purpose")
  323 | 				.filter({ hasText: expected.purpose }),
  324 | 		});
  325 | 	await expect(row).toHaveCount(1);
  326 | 	await expect(row.locator(".relation-endpoints")).toHaveText(expected.path);
  327 | 	await expect(row.locator(".relation-info strong")).toHaveText(
  328 | 		expected.endpoints,
  329 | 	);
  330 | 	await expect(row.locator(".relation-purpose")).toHaveText(expected.purpose);
  331 | }
  332 | 
  333 | async function fullFamily(page: Page, expected: Connection[], text: Copy) {
  334 | 	const details = page.locator("details.account-relation-details");
  335 | 	await expect(details).toHaveCount(1);
  336 | 	const detailsOpen = await details.evaluate(
  337 | 		(element) => (element as HTMLDetailsElement).open,
  338 | 	);
  339 | 	await page.getByRole("button", { name: text.family, exact: true }).click();
  340 | 	await expect(details).toHaveJSProperty("open", detailsOpen);
  341 | 	const pairCount = new Set(
  342 | 		expected.map((connection) => `${connection.from}:${connection.to}`),
  343 | 	).size;
  344 | 	const nodeCount = new Set(expected.flatMap((edge) => [edge.from, edge.to]))
  345 | 		.size;
  346 | 	await waitForAccountGraphLayout(page, { nodes: nodeCount, edges: pairCount });
  347 | 	// A scope toggle can retain the user's overview camera. Request reading focus
  348 | 	// explicitly before checking centered, readable text; selection checks still
```