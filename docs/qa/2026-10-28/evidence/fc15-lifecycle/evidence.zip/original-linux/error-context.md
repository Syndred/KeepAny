# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: account-lifecycle-release.spec.ts >> en 1536px imports, links, deletes, restores, purges and reimports the same account family
- Location: tests/e2e/account-lifecycle-release.spec.ts:99:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 3
Received: 0
```

# Test source

```ts
  201 | 					})
  202 | 					.click();
  203 | 				await page
  204 | 					.getByRole("dialog")
  205 | 					.last()
  206 | 					.getByRole("button", {
  207 | 						name: /^(确认导入|Confirm import)$/,
  208 | 						exact: true,
  209 | 					})
  210 | 					.click();
  211 | 				await expect(importer.locator(".pw-smart-receipt")).toBeVisible();
  212 | 				const savedDialog = page.locator(".password-smart-import-dialog");
  213 | 				if (count === 1) {
  214 | 					await expect(importer.locator(".pw-work-list-row")).toHaveCount(3);
  215 | 					await savedDialog
  216 | 						.locator(":scope > header")
  217 | 						.getByRole("button", { name: /^(关闭|Close)$/, exact: true })
  218 | 						.click();
  219 | 					await page
  220 | 						.getByRole("dialog")
  221 | 						.last()
  222 | 						.getByRole("button", {
  223 | 							name: /^(关闭并清空|Close and clear)$/,
  224 | 							exact: true,
  225 | 						})
  226 | 						.click();
  227 | 					await expect(importer).toBeHidden();
  228 | 					await expect(entries).toHaveCount(4);
  229 | 					return;
  230 | 				}
  231 | 				await expect(
  232 | 					savedDialog.getByRole("button", {
  233 | 						name: /^(关闭|Close)$/,
  234 | 						exact: true,
  235 | 					}),
  236 | 				).toHaveCount(1);
  237 | 				await expect(
  238 | 					savedDialog.getByRole("combobox", {
  239 | 						name: /^(其他输入方式|Other input methods)$/,
  240 | 					}),
  241 | 				).toHaveCount(0);
  242 | 				await screenshot("import-complete");
  243 | 				await savedDialog
  244 | 					.getByRole("button", { name: t("pwConnectTitle"), exact: true })
  245 | 					.click();
  246 | 				await expect(importer).toBeHidden();
  247 | 				await expect(page.locator(".vault-connect-dialog")).toBeVisible();
  248 | 				await expect(page.getByRole("dialog")).toHaveCount(1);
  249 | 				await expect(
  250 | 					page
  251 | 						.locator(".vault-connect-dialog")
  252 | 						.getByRole("heading", { name: t("pwConnectTitle"), exact: true }),
  253 | 				).toBeFocused();
  254 | 				await expect(entries).toHaveCount(4);
  255 | 			}
  256 | 			async function linkAll() {
  257 | 				const dialog = page.locator(".vault-connect-dialog");
  258 | 				if (!(await dialog.isVisible())) {
  259 | 					await vault();
  260 | 					await page
  261 | 						.getByRole("button", { name: t("pwConnectTitle"), exact: true })
  262 | 						.click();
  263 | 				}
  264 | 				await expect(dialog.locator(".vault-connect-conflict")).toHaveCount(0);
  265 | 				await expect(dialog.locator(".vault-connect-account")).toHaveCount(4);
  266 | 				await dialog
  267 | 					.getByRole("button", { name: t("pwConnectSelectAll"), exact: true })
  268 | 					.click();
  269 | 				await dialog
  270 | 					.getByRole("button", { name: t("pwConnectLocal"), exact: true })
  271 | 					.click();
  272 | 				await dialog
  273 | 					.getByRole("button", { name: t("pwConnectSave"), exact: true })
  274 | 					.click();
  275 | 				await expect(dialog).toBeHidden();
  276 | 			}
  277 | 			async function graph(
  278 | 				title: string,
  279 | 				nodes: number,
  280 | 				edges: number,
  281 | 				stage: string,
  282 | 			) {
  283 | 				await vault();
  284 | 				await entry(title).locator(".password-vault-linked-asset").click();
  285 | 				await waitForAccountGraphLayout(page, { nodes, edges });
  286 | 				await expectAccountGraphGeometry(page);
  287 | 				await expectReadableAccountGraph(page, {
  288 | 					all: width > 600,
  289 | 					centered: false,
  290 | 				});
  291 | 				const graph = activeAccountGraph(page);
  292 | 				const value = await graph.evaluate((element) => ({
  293 | 					nodes: [...element.querySelectorAll<HTMLElement>(".react-flow__node")]
  294 | 						.map((node) => node.dataset.id ?? "")
  295 | 						.sort(),
  296 | 					edges: [...element.querySelectorAll<HTMLElement>(".react-flow__edge")]
  297 | 						.map((edge) => edge.dataset.id ?? "")
  298 | 						.sort(),
  299 | 				}));
  300 | 				expect(new Set(value.nodes).size).toBe(nodes);
> 301 | 				expect(new Set(value.edges).size).toBe(edges);
      |                                       ^ Error: expect(received).toBe(expected) // Object.is equality
  302 | 				expect(
  303 | 					await page.evaluate(
  304 | 						() => document.documentElement.scrollWidth <= innerWidth,
  305 | 					),
  306 | 				).toBe(true);
  307 | 				snapshots.push({ stage, ...value });
  308 | 				return value;
  309 | 			}
  310 | 			async function trashAccount(title: string) {
  311 | 				await vault();
  312 | 				await entry(title).locator(".password-vault-linked-asset").click();
  313 | 				await page
  314 | 					.locator(".page-header")
  315 | 					.getByRole("button", { name: trash, exact: true })
  316 | 					.click();
  317 | 				await page
  318 | 					.getByRole("dialog")
  319 | 					.getByRole("button", { name: cancel, exact: true })
  320 | 					.click();
  321 | 				await expect(
  322 | 					page.getByRole("heading", { name: title, exact: true }).first(),
  323 | 				).toBeVisible();
  324 | 				await page
  325 | 					.locator(".page-header")
  326 | 					.getByRole("button", { name: trash, exact: true })
  327 | 					.click();
  328 | 				await page
  329 | 					.getByRole("dialog")
  330 | 					.getByRole("button", { name: trash, exact: true })
  331 | 					.click();
  332 | 				await expect(page.getByRole("dialog")).toBeHidden();
  333 | 			}
  334 | 			async function restoreAccount(title: string) {
  335 | 				await page.goto("/trash");
  336 | 				const row = page
  337 | 					.locator(".trash-row[data-asset-id]")
  338 | 					.filter({ has: page.getByText(title, { exact: true }) });
  339 | 				await expect(row).toHaveCount(1);
  340 | 				await row.getByRole("button", { name: restore, exact: true }).click();
  341 | 				await expect(row).toHaveCount(0);
  342 | 			}
  343 | 			async function purgeAccount(title: string) {
  344 | 				await page.goto("/trash");
  345 | 				const row = page
  346 | 					.locator(".trash-row[data-asset-id]")
  347 | 					.filter({ has: page.getByText(title, { exact: true }) });
  348 | 				await row.getByRole("button", { name: purge, exact: true }).click();
  349 | 				await page
  350 | 					.getByRole("dialog")
  351 | 					.getByRole("button", { name: cancel, exact: true })
  352 | 					.click();
  353 | 				await expect(row).toHaveCount(1);
  354 | 				await row.getByRole("button", { name: purge, exact: true }).click();
  355 | 				await page
  356 | 					.getByRole("dialog")
  357 | 					.getByRole("button", { name: purge, exact: true })
  358 | 					.click();
  359 | 				await expect(row).toHaveCount(0);
  360 | 			}
  361 | 			async function removeNotebookLine() {
  362 | 				await graph(titles[0], 4, 3, "before-line-delete");
  363 | 				const details = await setAccountRelationDetailsOpen(page);
  364 | 				const row = details
  365 | 					.locator(".relation-row")
  366 | 					.filter({ hasText: titles[2] });
  367 | 				await row
  368 | 					.getByRole("button", { name: /^(删除关系|Delete connection) ·/ })
  369 | 					.click();
  370 | 				await page
  371 | 					.getByRole("dialog")
  372 | 					.getByRole("button", {
  373 | 						name: zh ? "删除关系" : "Delete connection",
  374 | 						exact: true,
  375 | 					})
  376 | 					.click();
  377 | 				await waitForAccountGraphLayout(page, { nodes: 3, edges: 2 });
  378 | 			}
  379 | 			try {
  380 | 				await page.goto("/assets/vault");
  381 | 				await prepareVaultWorkspace(page);
  382 | 				await h.createVault();
  383 | 				await importPasswords(4);
  384 | 				await linkAll();
  385 | 				const initial = await graph(titles[0], 4, 3, "initial");
  386 | 				await screenshot("initial-family");
  387 | 				await linkAll();
  388 | 				expect(await graph(titles[0], 4, 3, "repeat-link")).toEqual(initial);
  389 | 
  390 | 				await removeNotebookLine();
  391 | 				await page.goto("/trash");
  392 | 				await page
  393 | 					.locator(".trash-row[data-relation-id]")
  394 | 					.getByRole("button", { name: restore, exact: true })
  395 | 					.click();
  396 | 				await expect(page.locator(".trash-row[data-relation-id]")).toHaveCount(
  397 | 					0,
  398 | 				);
  399 | 				expect(await graph(titles[0], 4, 3, "line-restored")).toEqual(initial);
  400 | 				await removeNotebookLine();
  401 | 				await page.goto("/trash");
```