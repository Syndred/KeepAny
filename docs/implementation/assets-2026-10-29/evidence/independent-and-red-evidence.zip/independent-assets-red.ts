import { chromium, expect } from '@playwright/test';
import { mkdirSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { restoreCompletionArchive } from '../tests/e2e/helpers/completion-archive';
import { assetFixturePassword } from '../tests/e2e/helpers/assets-workbench-fixture';
import { selectChoice } from '../tests/e2e/helpers/select-choice';
const directory=resolve('test-results/independent-assets-07bf');mkdirSync(directory,{recursive:true});
const browser=await chromium.launch({headless:true});const context=await browser.newContext({baseURL:'http://127.0.0.1:4395',viewport:{width:1280,height:1000}});const page=await context.newPage();await page.clock.setFixedTime(new Date('2026-10-29T04:00:00Z'));
const rows:any[]=[];const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
try {
await page.goto('/intake');await restoreCompletionArchive(page,assetFixturePassword,resolve('test-results/assets-workbench/fixture/fixture.ka1'));
await page.goto('/assets/physical');await page.getByRole('button',{name:'卡片',exact:true}).click();
await selectChoice(page.getByRole('combobox',{name:'物品状态',exact:true}),'loaned');await expect(page.locator('.assets-catalog-grid > a')).toHaveCount(1);
await page.screenshot({path:resolve(directory,'physical-loaned-before.png'),fullPage:true});
await page.locator('.assets-catalog-grid > a').click();await expect(page.getByRole('heading',{name:'AS Loaned camera',exact:true})).toBeVisible();
await page.locator('.topbar-back-link').click();await expect(page).toHaveURL(/assets\/physical$/);
const status=await page.getByRole('combobox',{name:'物品状态',exact:true}).getAttribute('data-value');const count=await page.locator('.assets-catalog-grid > a').count();
rows.push({id:'IND-AS01-return-filter',steps:'实物→状态借出→唯一camera卡→详情顶栏返回',expected:{status:'loaned',count:1},actual:{status,count},verdict:status==='loaned'&&count===1?'pass':'fail'});
await page.screenshot({path:resolve(directory,'physical-return-filter-lost.png'),fullPage:true});
await page.goto('/assets/online');await page.locator('.assets-category-pills').getByRole('button',{name:/^域名/}).click();await expect(page.locator('.assets-catalog-grid > a')).toHaveCount(2);await page.locator('.assets-catalog-grid > a').filter({hasText:'pine.example'}).first().click();await expect(page.getByRole('heading',{name:'AS Pine project',exact:true})).toBeVisible();
await page.goto('/assets/project');await expect(page.locator('.assets-catalog-grid')).toBeVisible();const selected=await page.locator('.assets-category-pills button[aria-pressed="true"]').innerText();
rows.push({id:'IND-AS04-legacy-project',steps:'线上→域名筛选→域名详情→公开原项目入口/assets/project',expected:'项目分类2个项目',actual:{selected,grid:await page.locator('.assets-catalog-grid').innerText()},verdict:selected.startsWith('项目')?'pass':'fail'});
await page.screenshot({path:resolve(directory,'legacy-project-shows-domains.png'),fullPage:true});
writeFileSync(resolve(directory,'results.json'),JSON.stringify({candidate:'07bf0d56548c',port:4395,rows,errors},null,2));console.log(JSON.stringify({rows,errors},null,2));
} finally { await context.close();await browser.close(); }
