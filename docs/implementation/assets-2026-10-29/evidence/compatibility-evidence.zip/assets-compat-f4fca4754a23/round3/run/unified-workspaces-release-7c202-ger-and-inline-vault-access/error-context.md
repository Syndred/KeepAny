# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: unified-workspaces-release.spec.ts >> zh-CN 390px built merged workspace preserves sample records, ledger and inline vault access
- Location: tests\e2e\unified-workspaces-release.spec.ts:9:2

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('.assets-catalog-grid .asset-library-card').nth(1)
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('.assets-catalog-grid .asset-library-card').nth(1) with timeout 5000ms
  - waiting for locator('.assets-catalog-grid .asset-library-card').nth(1)

```

```yaml
- complementary:
  - strong: KeepAny
  - text: 个人资产工作台
  - button "关闭"
  - button "个人工作区":
    - strong: 个人工作区
  - text: 工作空间
  - navigation "导航":
    - button "概览 按住拖动排序"
    - link "概览":
      - /url: /
    - button "账号 按住拖动排序"
    - link "账号":
      - /url: /accounts
    - button "资产 按住拖动排序"
    - link "资产":
      - /url: /assets
    - button "待办 按住拖动排序"
    - link "待办 5":
      - /url: /tasks
    - status
  - link "回收站":
    - /url: /trash
  - text: 我的分类
  - link "工作室资料":
    - /url: /collections/cf1a07d1-38ab-4d57-99a4-8013511269b8
  - link "自定义侧边栏":
    - /url: /collections
  - button "我 我的工作区 仅自己可见":
    - text: 我
    - strong: 我的工作区
    - text: 仅自己可见
- banner:
  - button "导航"
  - link "返回概览":
    - /url: /
  - button "搜索全部资料"
  - link "待办提醒":
    - /url: /tasks
  - button "AI 助手与授权"
  - link "收录与备份":
    - /url: /intake
- complementary "需要留意的提醒":
  - strong: 1 项提醒
  - link "确认素材使用范围":
    - /url: /tasks#task-ee45cd6a-444b-4e15-a96a-7e0905c8c5f6
- main:
  - heading "资产" [level=1]
  - paragraph: 管理实物与使用状态，查看购入和维护支出。
  - link "费用账本":
    - /url: /finance
  - button "新增资产"
  - navigation "资产":
    - link "总览":
      - /url: /assets
    - link "线上资产":
      - /url: /assets/online
    - link "实物资产":
      - /url: /assets/physical
  - button "全部 6"
  - button "数码设备 5"
  - button "家用电器 0"
  - button "家具 0"
  - button "其他 1"
  - button "新增分类"
  - button "管理"
  - text: 实物资产
  - strong: 6 件
  - text: 实物购入额
  - strong: ¥8,999.00
  - text: 购入价 本月支出
  - strong: 暂无已记录支出
  - text: 已记录支出 保修期内
  - strong: 1 件
  - searchbox "搜索实物资产（名称、品牌、存放位置等）"
  - combobox "按标签筛选": 全部标签
  - combobox "物品状态": 全部使用状态
  - combobox "位置": 全部存放位置
  - group "资产视图":
    - button "紧凑列表" [pressed]
    - button "卡片"
  - 'link "数码设备 示例 | 工作笔记本 购入价: ¥8,999.00 使用中 购买日期 2026年5月2日 位置: 工作室 · 书桌 保修到期: 2027年5月2日"':
    - /url: /assets/item/01e4d60e-e720-40e1-93aa-0f97ca530bf7
    - text: 数码设备
    - strong: 示例 | 工作笔记本
    - text: "购入价: ¥8,999.00 使用中 购买日期 2026年5月2日 位置: 工作室 · 书桌 保修到期: 2027年5月2日"
  - 'link "数码设备 示例 | 维修中的绘图板 购入价: 未记录金额 维修中 保修到期: 2026年8月30日"':
    - /url: /assets/item/172dba3b-1c5e-4a21-b4bc-6650d8bd009a
    - text: 数码设备
    - strong: 示例 | 维修中的绘图板
    - text: "购入价: 未记录金额 维修中 保修到期: 2026年8月30日"
  - 'link "其他 示例 | 旅行转换插头 购入价: 未记录金额 使用中"':
    - /url: /assets/item/460847f4-2a5c-4dbf-ae99-9d573c3f4457
    - text: 其他
    - strong: 示例 | 旅行转换插头
    - text: "购入价: 未记录金额 使用中"
  - 'link "数码设备 示例 | 工作室相机与备用镜头及收音配件套装 购入价: 未记录金额 使用中 购买日期 2025年9月24日 位置: 工作室 · 书桌"':
    - /url: /assets/item/6c1bd953-42eb-42a6-83e5-a865f07d0a89
    - text: 数码设备
    - strong: 示例 | 工作室相机与备用镜头及收音配件套装
    - text: "购入价: 未记录金额 使用中 购买日期 2025年9月24日 位置: 工作室 · 书桌"
  - 'link "数码设备 示例 | 外拍器材背包 购入价: 未记录金额 已借出 借用人: 小林（示例） · 2026年11月5日"':
    - /url: /assets/item/928be328-4e03-4466-abe0-2a5094972337
    - text: 数码设备
    - strong: 示例 | 外拍器材背包
    - text: "购入价: 未记录金额 已借出 借用人: 小林（示例） · 2026年11月5日"
  - 'link "数码设备 示例 | 已转售显示器 购入价: 未记录金额 已转卖 购买日期 2024年11月28日"':
    - /url: /assets/item/fb20f9ea-2bfd-4b94-9b60-b55934f7aa6a
    - text: 数码设备
    - strong: 示例 | 已转售显示器
    - text: "购入价: 未记录金额 已转卖 购买日期 2024年11月28日"
  - paragraph: 6 项
  - heading "近期维护" [level=2]
  - link "查看全部":
    - /url: /tasks
  - link "每季度清理工作设备 · 2026年11月12日":
    - /url: /tasks#task-0c7fbb16-9e51-4685-bdb1-653df50445db
```

# Test source

```ts
  1  | import { mkdirSync } from "node:fs";
  2  | import { join } from "node:path";
  3  | import { expect, test } from "@playwright/test";
  4  | 
  5  | const evidence = process.env.KEEPANY_EVIDENCE_DIR ?? "/tmp/keepany-unified-built";
  6  | mkdirSync(evidence, { recursive: true });
  7  | 
  8  | for (const locale of ["zh-CN", "en-US"] as const) for (const width of [390, 1280]) {
  9  | 	test(`${locale} ${width}px built merged workspace preserves sample records, ledger and inline vault access`, async ({ browser }) => {
  10 | 		const context = await browser.newContext({ locale, viewport: { width, height: 950 } });
  11 | 		const page = await context.newPage();
  12 | 		const errors: string[] = [];
  13 | 		page.on("pageerror", (error) => errors.push(error.message));
  14 | 		const zh = locale === "zh-CN";
  15 | 		try {
  16 | 			await page.goto("/");
  17 | 			await page.getByRole("link", { name: zh ? "用示例资料开始" : "Start with sample records", exact: true }).click();
  18 | 			const add = page.getByRole("button", { name: zh ? "加入示例资料" : "Add sample records", exact: true });
  19 | 			await add.click();
  20 | 			await expect(add).toBeDisabled();
  21 | 			await expect(page.getByRole("button", { name: zh ? "完整示例资料已加入" : "Full sample records already added", exact: true })).toBeDisabled();
  22 | 			await page.goto("/assets");
  23 | 			await expect(page.getByRole("heading", { name: zh ? "资产" : "Assets", exact: true })).toBeVisible();
  24 | 			// AS01/AS02: the approved asset landing page is the expense overview.
  25 | 			// Keep catalog coverage by entering both catalogs through their visible tabs.
  26 | 			await expect(page.locator(".assets-section-nav").getByRole("link", { name: zh ? "总览" : "Overview", exact: true })).toHaveAttribute("aria-current", "page");
  27 | 			await expect(page.locator(".assets-metrics > section")).toHaveCount(4);
  28 | 			await expect(page.locator(".assets-ledger")).toBeVisible();
  29 | 			await expect(page.locator(".assets-breakdown")).toBeVisible();
  30 | 			await expect(page.locator(".assets-renewals")).toBeVisible();
  31 | 			await expect(page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).resolves.toBe(true);
  32 | 			await page.screenshot({ path: join(evidence, `built-assets-${zh ? "zh" : "en"}-${width}.png`), fullPage: true });
  33 | 			await page.locator(".assets-section-nav").getByRole("link", { name: zh ? "线上资产" : "Online assets", exact: true }).click();
  34 | 			await expect(page.locator(".assets-catalog-grid .asset-project-card").first()).toBeVisible();
  35 | 			expect(await page.locator(".assets-catalog-grid .asset-library-card").count()).toBeGreaterThanOrEqual(2);
  36 | 			await page.locator(".assets-section-nav").getByRole("link", { name: zh ? "实物资产" : "Physical assets", exact: true }).click();
  37 | 			await expect(page).toHaveURL(/\/assets\/physical$/);
> 38 | 			await expect(page.locator(".assets-catalog-grid .asset-library-card").nth(1)).toBeVisible();
     |                                                                                  ^ Error: expect(locator).toBeVisible() failed
  39 | 			expect(await page.locator(".assets-catalog-grid .asset-library-card").count()).toBeGreaterThanOrEqual(2);
  40 | 			await expect(page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).resolves.toBe(true);
  41 | 			await page.locator("main > .page-header").getByRole("link", { name: zh ? "费用账本" : "Ledger", exact: true }).click();
  42 | 			await expect(page.locator(".finance-summary > section")).toHaveCount(2);
  43 | 			await expect(page.getByRole("heading", { name: zh ? "费用账本" : "Expense ledger", exact: true })).toBeVisible();
  44 | 			await expect(page.locator("#finance-filter-type")).toHaveCount(0);
  45 | 			await page.goto("/accounts");
  46 | 			await expect(page.getByRole("heading", { name: zh ? "账号" : "Accounts", exact: true })).toBeVisible();
  47 | 			await expect(page.locator(".asset-account-card").first()).toBeVisible();
  48 | 			await page.screenshot({ path: join(evidence, `built-accounts-${zh ? "zh" : "en"}-${width}.png`), fullPage: true });
  49 | 			await page.locator(".asset-account-card").first().click();
  50 | 			await page.getByRole("button", { name: zh ? "在此查看密码" : "View passwords here", exact: true }).click();
  51 | 			const passwords = page.locator(".account-passwords-section");
  52 | 			await expect(passwords.locator("#password-vault-master")).toBeVisible();
  53 | 			await expect(passwords.getByRole("status").filter({ hasText: zh ? "正在打开密码库" : "Opening the password vault" })).toHaveCount(0);
  54 | 			await expect(passwords).toBeFocused();
  55 | 			await expect(passwords).toBeInViewport();
  56 | 			await expect.poll(() => passwords.evaluate((section) => {
  57 | 				const facts = document.querySelector(".account-facts-grid");
  58 | 				if (!facts) return false;
  59 | 				const panel = section.getBoundingClientRect();
  60 | 				const source = facts.getBoundingClientRect();
  61 | 				return panel.top >= source.bottom - 1 && panel.width >= source.width - 1 && panel.top >= 0 && panel.top < innerHeight - 100;
  62 | 			})).toBe(true);
  63 | 			await page.screenshot({ path: join(evidence, `built-inline-open-${zh ? "zh" : "en"}-${width}.png`), fullPage: false });
  64 | 			await expect(page.locator(".account-passwords-section #password-vault-master")).toBeVisible();
  65 | 			await expect(page.getByRole("heading", { level: 1 })).toHaveCount(1);
  66 | 			await expect(page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).resolves.toBe(true);
  67 | 			const syntheticMaster = "Synthetic FC12 persistence 2026!";
  68 | 			await passwords.locator("#password-vault-master").fill(syntheticMaster);
  69 | 			await passwords.locator("#password-vault-master-confirm").fill(syntheticMaster);
  70 | 			await passwords.getByRole("button", { name: zh ? "创建密码库" : "Create vault", exact: true }).click();
  71 | 			await expect(passwords.locator(".password-vault-toolbar")).toBeVisible();
  72 | 			await page.reload();
  73 | 			await expect(page.getByRole("button", { name: zh ? "在此查看密码" : "View passwords here", exact: true })).toBeVisible();
  74 | 			await page.getByRole("button", { name: zh ? "在此查看密码" : "View passwords here", exact: true }).click();
  75 | 			await expect(passwords.locator("#password-vault-unlock-master")).toBeVisible();
  76 | 			await expect(passwords.locator("#password-vault-master-confirm")).toHaveCount(0);
  77 | 			await expect(passwords).toBeFocused();
  78 | 			// Verify settled layout after the persisted vault and browser scroll anchoring finish.
  79 | 			await page.waitForTimeout(500);
  80 | 			await expect(passwords).toBeFocused();
  81 | 			await expect.poll(() => passwords.evaluate((section) => section.getBoundingClientRect().top)).toBeGreaterThanOrEqual(0);
  82 | 			await expect.poll(() => passwords.evaluate((section) => section.getBoundingClientRect().top)).toBeLessThan(200);
  83 | 			await page.screenshot({ path: join(evidence, `built-inline-persisted-${zh ? "zh" : "en"}-${width}.png`), fullPage: false });
  84 | 			await passwords.locator("#password-vault-unlock-master").fill(syntheticMaster);
  85 | 			await passwords.getByRole("button", { name: zh ? "解锁密码库" : "Unlock vault", exact: true }).click();
  86 | 			await expect(passwords.locator(".password-vault-toolbar")).toBeVisible();
  87 | 			await page.getByRole("button", { name: zh ? "收起密码" : "Hide passwords", exact: true }).click();
  88 | 			await expect(passwords).toHaveCount(0);
  89 | 			expect(errors).toEqual([]);
  90 | 		} finally { await context.close(); }
  91 | 	});
  92 | }
  93 | 
```