# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: unified-workspaces-release.spec.ts >> zh-CN 1280px built merged workspace preserves sample records, ledger and inline vault access
- Location: tests\e2e\unified-workspaces-release.spec.ts:9:2

# Error details

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 2
Received:    0
```

# Test source

```ts
  1  | import { mkdirSync } from "node:fs";
  2  | import { join } from "node:path";
  3  | import { expect, test } from "@playwright/test";
  4  | 
  5  | const evidence = process.env.KEEPANY_EVIDENCE_DIR ?? "/tmp/keepany-unified-built";
  6  | mkdirSync(evidence, { recursive: true });
  7  | 
  8  | for (const locale of ["zh-CN", "en-US"] as const) for (const width of [390, 1280]) {
  9  | 	test(`${locale} ${width}px built merged workspace preserves sample records, ledger and inline vault access`, async ({ browser }) => {
  10 | 		const context = await browser.newContext({ locale, viewport: { width, height: 950 } });
  11 | 		const page = await context.newPage();
  12 | 		const errors: string[] = [];
  13 | 		page.on("pageerror", (error) => errors.push(error.message));
  14 | 		const zh = locale === "zh-CN";
  15 | 		try {
  16 | 			await page.goto("/");
  17 | 			await page.getByRole("link", { name: zh ? "用示例资料开始" : "Start with sample records", exact: true }).click();
  18 | 			const add = page.getByRole("button", { name: zh ? "加入示例资料" : "Add sample records", exact: true });
  19 | 			await add.click();
  20 | 			await expect(add).toBeDisabled();
  21 | 			await expect(page.getByRole("button", { name: zh ? "完整示例资料已加入" : "Full sample records already added", exact: true })).toBeDisabled();
  22 | 			await page.goto("/assets");
  23 | 			await expect(page.getByRole("heading", { name: zh ? "资产" : "Assets", exact: true })).toBeVisible();
  24 | 			// AS01/AS02: the approved asset landing page is the expense overview.
  25 | 			// Keep catalog coverage by entering both catalogs through their visible tabs.
  26 | 			await expect(page.locator(".assets-section-nav").getByRole("link", { name: zh ? "总览" : "Overview", exact: true })).toHaveAttribute("aria-current", "page");
  27 | 			await expect(page.locator(".assets-metrics > section")).toHaveCount(4);
  28 | 			await expect(page.locator(".assets-ledger")).toBeVisible();
  29 | 			await expect(page.locator(".assets-breakdown")).toBeVisible();
  30 | 			await expect(page.locator(".assets-renewals")).toBeVisible();
  31 | 			await expect(page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).resolves.toBe(true);
  32 | 			await page.screenshot({ path: join(evidence, `built-assets-${zh ? "zh" : "en"}-${width}.png`), fullPage: true });
  33 | 			await page.locator(".assets-section-nav").getByRole("link", { name: zh ? "线上资产" : "Online assets", exact: true }).click();
  34 | 			await expect(page.locator(".assets-catalog-grid .asset-project-card").first()).toBeVisible();
  35 | 			expect(await page.locator(".assets-catalog-grid .asset-library-card").count()).toBeGreaterThanOrEqual(2);
  36 | 			await page.locator(".assets-section-nav").getByRole("link", { name: zh ? "实物资产" : "Physical assets", exact: true }).click();
> 37 | 			expect(await page.locator(".assets-catalog-grid .asset-library-card").count()).toBeGreaterThanOrEqual(2);
     |                                                                                   ^ Error: expect(received).toBeGreaterThanOrEqual(expected)
  38 | 			await expect(page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).resolves.toBe(true);
  39 | 			await page.locator("main > .page-header").getByRole("link", { name: zh ? "费用账本" : "Ledger", exact: true }).click();
  40 | 			await expect(page.locator(".finance-summary > section")).toHaveCount(2);
  41 | 			await expect(page.getByRole("heading", { name: zh ? "费用账本" : "Expense ledger", exact: true })).toBeVisible();
  42 | 			await expect(page.locator("#finance-filter-type")).toHaveCount(0);
  43 | 			await page.goto("/accounts");
  44 | 			await expect(page.getByRole("heading", { name: zh ? "账号" : "Accounts", exact: true })).toBeVisible();
  45 | 			await expect(page.locator(".asset-account-card").first()).toBeVisible();
  46 | 			await page.screenshot({ path: join(evidence, `built-accounts-${zh ? "zh" : "en"}-${width}.png`), fullPage: true });
  47 | 			await page.locator(".asset-account-card").first().click();
  48 | 			await page.getByRole("button", { name: zh ? "在此查看密码" : "View passwords here", exact: true }).click();
  49 | 			const passwords = page.locator(".account-passwords-section");
  50 | 			await expect(passwords.locator("#password-vault-master")).toBeVisible();
  51 | 			await expect(passwords.getByRole("status").filter({ hasText: zh ? "正在打开密码库" : "Opening the password vault" })).toHaveCount(0);
  52 | 			await expect(passwords).toBeFocused();
  53 | 			await expect(passwords).toBeInViewport();
  54 | 			await expect.poll(() => passwords.evaluate((section) => {
  55 | 				const facts = document.querySelector(".account-facts-grid");
  56 | 				if (!facts) return false;
  57 | 				const panel = section.getBoundingClientRect();
  58 | 				const source = facts.getBoundingClientRect();
  59 | 				return panel.top >= source.bottom - 1 && panel.width >= source.width - 1 && panel.top >= 0 && panel.top < innerHeight - 100;
  60 | 			})).toBe(true);
  61 | 			await page.screenshot({ path: join(evidence, `built-inline-open-${zh ? "zh" : "en"}-${width}.png`), fullPage: false });
  62 | 			await expect(page.locator(".account-passwords-section #password-vault-master")).toBeVisible();
  63 | 			await expect(page.getByRole("heading", { level: 1 })).toHaveCount(1);
  64 | 			await expect(page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).resolves.toBe(true);
  65 | 			const syntheticMaster = "Synthetic FC12 persistence 2026!";
  66 | 			await passwords.locator("#password-vault-master").fill(syntheticMaster);
  67 | 			await passwords.locator("#password-vault-master-confirm").fill(syntheticMaster);
  68 | 			await passwords.getByRole("button", { name: zh ? "创建密码库" : "Create vault", exact: true }).click();
  69 | 			await expect(passwords.locator(".password-vault-toolbar")).toBeVisible();
  70 | 			await page.reload();
  71 | 			await expect(page.getByRole("button", { name: zh ? "在此查看密码" : "View passwords here", exact: true })).toBeVisible();
  72 | 			await page.getByRole("button", { name: zh ? "在此查看密码" : "View passwords here", exact: true }).click();
  73 | 			await expect(passwords.locator("#password-vault-unlock-master")).toBeVisible();
  74 | 			await expect(passwords.locator("#password-vault-master-confirm")).toHaveCount(0);
  75 | 			await expect(passwords).toBeFocused();
  76 | 			// Verify settled layout after the persisted vault and browser scroll anchoring finish.
  77 | 			await page.waitForTimeout(500);
  78 | 			await expect(passwords).toBeFocused();
  79 | 			await expect.poll(() => passwords.evaluate((section) => section.getBoundingClientRect().top)).toBeGreaterThanOrEqual(0);
  80 | 			await expect.poll(() => passwords.evaluate((section) => section.getBoundingClientRect().top)).toBeLessThan(200);
  81 | 			await page.screenshot({ path: join(evidence, `built-inline-persisted-${zh ? "zh" : "en"}-${width}.png`), fullPage: false });
  82 | 			await passwords.locator("#password-vault-unlock-master").fill(syntheticMaster);
  83 | 			await passwords.getByRole("button", { name: zh ? "解锁密码库" : "Unlock vault", exact: true }).click();
  84 | 			await expect(passwords.locator(".password-vault-toolbar")).toBeVisible();
  85 | 			await page.getByRole("button", { name: zh ? "收起密码" : "Hide passwords", exact: true }).click();
  86 | 			await expect(passwords).toHaveCount(0);
  87 | 			expect(errors).toEqual([]);
  88 | 		} finally { await context.close(); }
  89 | 	});
  90 | }
  91 | 
```