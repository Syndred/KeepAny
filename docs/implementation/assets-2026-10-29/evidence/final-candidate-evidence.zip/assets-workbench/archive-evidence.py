from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess
import zipfile
from datetime import datetime, timezone

root = Path.cwd()
results = root / 'test-results'
out = root / 'docs/implementation/assets-2026-10-29/evidence'
out.mkdir(parents=True, exist_ok=True)
product = 'f4fca4754a238421d2ea10d130aacd118a5fb9f1'
zip_sha = 'd48705345a6737360ac505a823589195979d71d2429ed02f5037d76421c27521'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

notes = {
    'overview': '双币独立、共享分布正确，表格内滚动，无页面横溢，指标与看板可读。',
    'online-cards': 'Cards选中与网格一致；长名/网址截断清楚，未知金额有明确标记，操作对齐。',
    'online-expanded-filters': '分类展开、数量、管理入口完整；小屏换行，无控件覆盖。',
    'create-dialog': '类型、标题、继续/取消/关闭在视口内；遮罩按真实视口检查。',
    'physical-cards': '状态、位置、价格与保修可读，卡片排列和长内容无叠压。',
    'physical-state-menu': '选中与focus清楚，菜单完整可达，触控行间距正常。',
    'ledger-fields': '长多归属区自带滚动，字段及底部保存/取消可达。',
    'ledger-error': '零金额错误在表单前部可见，未被固定操作栏覆盖，草稿与取消出口保留。',
}
rows = []
for path in sorted((results / 'assets-workbench/evidence-finalf4-stable').glob('zh-CN-*.png')):
    match = re.fullmatch(r'zh-CN-(\d+)-(.+)\.png', path.name)
    assert match and match[2] in notes, path
    rows.append({'path': path.relative_to(results).as_posix(), 'sha256': sha(path),
                 'locale': 'zh-CN', 'width': int(match[1]), 'state': match[2],
                 'openedBy': '主控本人，逐张view_image实际打开；非自动图审',
                 'actual': notes[match[2]], 'result': 'passed', 'candidate': product})
assert len(rows) == 40
assert sorted({r['width'] for r in rows}) == [390, 768, 1280, 1920, 2560]
write_json(results / 'assets-workbench/owner/visual-review.json', {
    'kind': 'manual-visual-review-record', 'candidate': product,
    'zipSha256': zip_sha, 'scope': '中文最终稳定图；英文逐图复核另见独立记录', 'rows': rows})

changes = subprocess.check_output(['git', 'diff', '--name-only', product, 'HEAD'], text=True).splitlines()
expected = ['tests/e2e/assets-workbench.spec.ts', 'tests/e2e/finance-ledger-release.spec.ts',
            'tests/e2e/unified-workspaces-release.spec.ts']
assert sorted(changes) == sorted(expected), changes
write_json(out / 'source-equivalence.json', {
    'productCommit': product, 'testSupportCommit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'changedTrackedPathsSinceProduct': changes, 'productAppsPackagesBuildConfigurationUnchanged': True,
    'command': 'git diff --name-only f4fca4754a238421d2ea10d130aacd118a5fb9f1 HEAD',
    'note': '后续文档/证据提交不重建产品；434源码文件匹配证据在final-candidate-evidence.zip的execution.json。'})
write_json(out / 'cleanup.json', {
    'recordedAt': datetime.now(timezone.utc).isoformat(), 'candidate': product,
    'observation': 'PowerShell Get-NetTCPConnection确认仅原4180监听；4255/4256/4394/4395/4396均无监听；原目录git status --short空。',
    'ownerBrowser': '自建page2先转同源sw.js退出应用连接，逐库删除IndexedDB，剩余[]；注销SW、删除caches并清空localStorage/sessionStorage，然后关闭page2，仅余原about:blank。',
    'deletedOwnerDatabases': ['keepany-files-v1', 'rxdb-dexie-keepany-v1--0--_rxdb_internal', 'rxdb-dexie-keepany-v1--0--records'],
    'serviceStop': '4256包内公开stop；4255核命令行为本任务vite preview后结束；4394/4395/4396由各测试责任者正常关闭。',
    'temporaryCopiesRemoved': ['C:/Users/Administrator/Desktop/project/KeepAny/output/assets-workbench-owner/fixture.ka1',
                              'C:/Users/Administrator/.codex/visualizations/2026/10/29/01a18695-ed64-7a41-8cee-ff59596712ec/assets-fixture.ka1'],
    'original4180': {'address': '127.0.0.1', 'pidObserved': 14268, 'changedOrStopped': False},
    'retained': '本工作区test-results中的合成测试证据和最终dist便携ZIP；没有对原用户库执行测试。'})

allowed = {'.json', '.png', '.log', '.txt', '.patch', '.diff', '.md', '.mjs', '.ts', '.py'}
def safe_files(directory, recursive=True):
    paths = directory.rglob('*') if recursive else directory.iterdir()
    return [p for p in paths if p.is_file() and p.suffix in allowed
            and not ({'package', 'candidate', 'node_modules', 'legacy-transactions-fixture', '.keepany-preview'} & set(p.relative_to(directory).parts))]

final_files = safe_files(results / 'assets-workbench/evidence-finalf4-stable')
for name in ['finalf4-stable.log', 'results-finalf4-stable.json', 'typecheck-final.log',
             'typecheck-final-support.log', 'unit-final.log', 'verify-archive-finalf4.log', 'verify-finalf4.log',
             'write-execution-f4-stable.mjs', 'probe-evidence-f4-stable.mjs', 'archive-evidence.py']:
    final_files.append(results / 'assets-workbench' / name)
final_files += safe_files(results / 'assets-workbench/owner')

independent_files = []
for name in ['independent-assets-07bf', 'independent-assets-4542', 'independent-assets-4542-replay',
             'independent-assets-final382', 'independent-assets-final49', 'independent-assets-finalf4']:
    independent_files += safe_files(results / name, recursive=False)
independent_files += [p for p in results.glob('independent-assets*') if p.is_file() and p.suffix in allowed]
for evidence_dir in ['evidence-first', 'evidence-final382', 'evidence-finalf4']:
    directory = results / 'assets-workbench' / evidence_dir
    # 保留版本及关键过渡/旧文案帧；全部原目录仍保留，避免归档重复整套80图。
    independent_files += [p for p in directory.glob('*') if p.is_file() and (
        p.suffix == '.json' or p.name in ['en-390-online-cards.png', 'en-1280-overview.png'])]
for p in (results / 'assets-workbench').iterdir():
    if p.is_file() and p.suffix in {'.log', '.json'} and p.name not in {f.name for f in final_files}:
        independent_files.append(p)

compat_files = safe_files(results / 'assets-compat-f4fca4754a23')
archives = []
for name, files in [('final-candidate-evidence.zip', final_files),
                    ('independent-and-red-evidence.zip', independent_files),
                    ('compatibility-evidence.zip', compat_files)]:
    unique = sorted(set(files))
    entries = []
    archive = out / name
    # 仅重生成派生归档；不修改原始测试文件和排他写入receipt。
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in unique:
            arcname = path.relative_to(results).as_posix()
            assert path.is_file() and path.suffix != '.ka1'
            z.write(path, arcname)
            entries.append({'path': arcname, 'sha256': sha(path), 'bytes': path.stat().st_size})
        z.writestr('ARCHIVE-CONTENTS.json', json.dumps(entries, ensure_ascii=False, indent=2))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for entry in entries:
            assert hashlib.sha256(z.read(entry['path'])).hexdigest() == entry['sha256']
    archives.append({'path': name, 'sha256': sha(archive), 'bytes': archive.stat().st_size,
                     'files': len(entries), 'eachEntrySha256VerifiedAfterExtraction': True})

screenshots = out.parent / 'screenshots'
screenshots.mkdir(exist_ok=True)
for page in ['overview', 'online-cards', 'physical-cards']:
    shutil.copyfile(results / f'assets-workbench/evidence-finalf4-stable/zh-CN-1280-{page}.png', screenshots / f'{page}.png')
write_json(out / 'index.json', {'scope': '资产三页；人工与机器证据分别判定', 'candidate': product, 'zipSha256': zip_sha,
    'archives': archives, 'excluded': '重复产品包/源码、数据库、运行状态、KA1、视频和trace；原始测试目录未删除。',
    'manualRecords': ['../主控体验与视觉.md', '../独立复核.md'],
    'primaryVisualHashes': 'final-candidate-evidence.zip: assets-workbench/owner/visual-review.json',
    'independentVisualHashes': 'independent-and-red-evidence.zip: independent-assets-finalf4/visual-review.json'})
print(json.dumps(archives, ensure_ascii=False))
