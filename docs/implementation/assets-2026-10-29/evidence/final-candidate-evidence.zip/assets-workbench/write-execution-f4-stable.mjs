import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { resolve, join } from 'node:path';
const evidence = resolve('test-results/assets-workbench/evidence-finalf4-stable');
const candidate = resolve('dist/preview/KeepAny-0.1.0-preview.f4fca4754a23-portable');
const release = JSON.parse(readFileSync(join(candidate,'RELEASE.json'),'utf8'));
const report = JSON.parse(readFileSync('test-results/assets-workbench/results-finalf4-stable.json','utf8'));
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const sourceFiles = release.sourceFiles.map(file => ({path:file.path,expected:file.sha256,actual:hash(readFileSync(file.path))})).map(row => ({...row,pass:row.expected===row.actual}));
const supportPaths = ['tests/e2e/assets-workbench.spec.ts','tests/e2e/helpers/assets-workbench-fixture.ts','playwright.assets-workbench.config.ts','scripts/verify-assets-workbench-evidence.mjs','.github/workflows/verify.yml'];
const support = supportPaths.map(path => ({path,sha256:hash(readFileSync(path)),sameAsCandidateCommit:readFileSync(path,'utf8').replaceAll('\r\n','\n')===execFileSync('git',['show',`${release.sourceCommit}:${path}`],{encoding:'utf8'}).replaceAll('\r\n','\n')}));
const supportDiff = execFileSync('git',['diff',release.sourceCommit,'--',...supportPaths],{encoding:'utf8'});
writeFileSync(join(evidence,'executed-support-diff.patch'),supportDiff);
const files = ['../finalf4-stable.log','../results-finalf4-stable.json','AS01-AS09-machine-results.json','http-web-hashes.json','integrity-probes.json','receipt-overwrite-probe.json','executed-support-diff.patch'];
const record = {
  candidate:{directory:candidate,sourceCommit:release.sourceCommit,sourceDirty:release.sourceDirty,zipSha256:hash(readFileSync(candidate+'.zip'))},
  invocation:{command:'pnpm exec playwright test --config playwright.assets-workbench.config.ts',environment:{KEEPANY_PREVIEW_DIRECTORY:candidate,KEEPANY_RELEASE_TEST_PORT:'4394',KEEPANY_EVIDENCE_DIR:'test-results/assets-workbench/evidence-finalf4-stable',KEEPANY_ASSETS_RESULTS:'test-results/assets-workbench/run-finalf4-stable',KEEPANY_ASSETS_REPORT:'test-results/assets-workbench/results-finalf4-stable.json'},exitCode:0,workers:1,retries:0,stats:report.stats},
  evidence:files.map(path=>({path,sha256:hash(readFileSync(resolve(evidence,path)))})),
  sourceFiles,support,
  supportVersionNote:'Product byte identity remains f4fca4754a23. After packaging, only the asset test added independent API GET requests with Accept:text/html and animations disabled for stable screenshots, alongside existing browser goto/reload assertions; executed support hashes and diff are bound here. This support-only addition does not change product bytes.',
  actualByContract:{
    AS01:'四条路由各以独立API Accept:text/html、浏览器goto、reload确认HTTP200及对应三页选中；域名分类选中；筛选上下文返回、旧项目入口正确。',
    AS02:'空库无虚构费用；本月CNY19.00/USD3.00五笔支出；2025-12历史999.00；固定费用与30天预计续费分列。',
    AS03:'修正续费2.00、共同2.00去重、双币分开；未来/隐藏/退款/余额不入实际合计；线上卡1011.00不包含未来500.00。',
    AS04:'全部6项含2域名；域名搜索/无匹配、软件服务分类+标签、卡片/列表及详情返回。',
    AS05:'实物4项分类/借出/位置筛选；位置编辑回读；借出缺借人错误→保存→刷新→归还；维护空内容错误→保存→刷新历史。',
    AS06:'资产新增取消/刷新无写入；非法金额与非法日期保留、纠正保存；空库单条金额未知保存刷新。',
    AS07:'支出账本共同归属新增、错误、取消、保存刷新、编辑、删除取消/确认；合计随账单变化；公开下载KA1证明退款/余额原记录不变。',
    AS08:'双语×390/768/1280/1920/2560，共80当前图；三页/展开分类/创建弹窗/状态菜单/账单字段/错误；Cards pressed且非dense，长表单错误完整可见且不与actions交叠。图审另记。',
    AS09:'共享侧栏4项顺序、2账号、维护待办入口及旧项目路由。KDBX解锁展开不是此机器专项覆盖。',
  },
  gates:{positive:'AS01-AS09-machine-results.json',negative:'integrity-probes.json（错候选、缺结果、缺合同ID、缺截图均拒绝）',immutableReceipt:'receipt-overwrite-probe.json（重复写入被EEXIST拒绝，正receipt SHA前后相同）',cloud:'verify.yml配置已增加显式候选专项和产物保存；本记录没有云端运行结论'},
  limitations:['机器结果不替代人工视觉、主控体验、独立复核。','借还/维护为直接提交原生表单，无专用取消按钮；弹窗取消在新增及费用路径覆盖。','旧全项目套件未因本专项运行变为通过。'],
  lifecycle:{browser:'测试隔离context由运行器关闭，无自建用户页签',server:'4394测试服务终态自动停止；本轮HTTP校验在测试服务运行期间完成',evidence:'虚构KA1/截图保留验收，不包含用户秘密'},
};
if(sourceFiles.some(row=>!row.pass))throw Error('product-source-drift');
if(support.filter(row=>!row.sameAsCandidateCommit).some(row=>row.path!=='tests/e2e/assets-workbench.spec.ts'))throw Error('unexpected-support-drift');
writeFileSync(join(evidence,'execution.json'),JSON.stringify(record,null,2));
console.log(JSON.stringify({sourceFiles:sourceFiles.length,productSourceMatches:true,tests:report.stats.expected,elapsedMs:report.stats.duration,exitCode:0}));
