import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { spawnSync } from 'node:child_process';
const original = resolve('test-results/assets-workbench/evidence-finalf4-stable');
const report = JSON.parse(readFileSync('test-results/assets-workbench/results-finalf4-stable.json','utf8'));
const identity = JSON.parse(readFileSync(join(original,'candidate.json'),'utf8'));
const candidate = resolve('dist/preview/KeepAny-0.1.0-preview.f4fca4754a23-portable');
const specs = [
  { name:'wrong-candidate', mutateIdentity: value => value.sourceCommit='0'.repeat(40), expected:'candidate identity mismatch' },
  { name:'incomplete-report', mutateReport: value => value.stats.expected=7, expected:'report is incomplete' },
  { name:'missing-contract-id', mutateReport: value => value.suites[0].specs[0].title=value.suites[0].specs[0].title.replace('AS09','AS99'), expected:'Missing asset case' },
  { name:'missing-screenshot', expected:'ENOENT' },
];
const results=[];
for (const spec of specs) {
  const dir=resolve('test-results/assets-workbench/integrity-probes-f4-stable',spec.name); mkdirSync(dir,{recursive:true});
  const raw=structuredClone(identity), altered=structuredClone(report);
  spec.mutateIdentity?.(raw);spec.mutateReport?.(altered);
  writeFileSync(join(dir,'candidate.json'),JSON.stringify(raw));writeFileSync(join(dir,'results.json'),JSON.stringify(altered));
  const result=spawnSync(process.execPath,['scripts/verify-assets-workbench-evidence.mjs'],{encoding:'utf8',env:{...process.env,KEEPANY_PREVIEW_DIRECTORY:candidate,KEEPANY_PREVIEW_ARCHIVE:'',KEEPANY_EVIDENCE_DIR:dir,KEEPANY_ASSETS_REPORT:join(dir,'results.json')}});
  const message=(result.stderr??'')+(result.stdout??'');
  results.push({name:spec.name,expected:spec.expected,exitCode:result.status,rejected:result.status!==0&&message.includes(spec.expected),message});
}
writeFileSync(join(original,'integrity-probes.json'),JSON.stringify(results,null,2));
console.log(JSON.stringify(results.map(({name,exitCode,rejected})=>({name,exitCode,rejected}))));
if(results.some(row=>!row.rejected))process.exitCode=1;
